# Security Specification — Princegoldsocialhub

## 1. Data Invariants
1. **Identity Integrity**: Every user-owned document (`orders`, `payments`, `users/{uid}`, `wishlist`, `notifications`, `feedback`) must enforce `userId == request.auth.uid` on create and read (unless `isAdmin()`).
2. **No Self-Assigned Privileges**: Users cannot write `/admins/{uid}` or add `role`/`isAdmin` fields to `/users/{uid}`. Admin access is determined strictly by `/admins/{uid}` existence or `request.auth.token.email == 'tomisin582@gmail.com' && request.auth.token.email_verified == true`.
3. **Catalog & Storefront Integrity**: Only admins can create, update, or delete `/products`, `/categories`, `/sku_index`, `/store_config`, `/promotions`, `/faqs`, `/policies`, `/import_logs`, `/import_snapshots`, `/scan_history`, `/scan_diagnostics`, and `/audit_logs`.
4. **PII Isolation**: `/users/{uid}`, `/orders/{orderId}`, `/payments/{paymentId}`, `/notifications/{id}`, and `/feedback/{id}` are never publicly readable or listable by non-owners. Public order tracking reads `/order_tracking_public/{orderNumber}` by exact `get` only (no `list`), containing zero PII (no email, phone, or shipping address).
5. **Immutable Ownership & Timestamps**: `userId` and `createdAt` cannot be modified on update. `createdAt == request.time` on create; `updatedAt == request.time` on update where applicable.
6. **Strict Key & Size Guards**: Every `create` validates `keys().hasAll(...)` and `keys().hasOnly(...)`; every `update` validates `affectedKeys().hasOnly(...)` and invokes `isValid[Entity](incoming())`. Every string enforces `.size()` and every ID enforces `isValidId()`.

## 2. Dirty Dozen Adversarial Payloads (Must Return PERMISSION_DENIED)
1. **Shadow Admin Escalation**: Authenticated user writes `{ uid: auth.uid, email: 'attacker@x.com', isAdmin: true, role: 'admin' }` to `/users/{auth.uid}` -> Blocked by `hasOnly(...)`.
2. **Self-Admin Insertion**: Authenticated non-admin creates `/admins/{auth.uid}` -> Blocked by `allow write: if false`.
3. **Spoofed Order Owner**: Authenticated user A creates `/orders/ord1` with `userId: 'userB'` -> Blocked by `incoming().userId == request.auth.uid`.
4. **Fake Verified Payment**: Customer creates `/orders/ord2` with `paymentStatus: 'verified_paid'` or `status: 'Completed'` -> Blocked by client order creation rule requiring initial `paymentStatus in ['unpaid', 'test_pending']` and `status == 'Awaiting Payment'`.
5. **Cross-User Order Scraping**: User A queries `collection('orders')` without `userId == auth.uid` -> Blocked by `allow list: if isAdmin() || (isSignedIn() && resource.data.userId == request.auth.uid)`.
6. **PII Leak via Tracking Collection**: Unauthenticated user runs `list` on `/order_tracking_public` -> Blocked by `allow list: if false`.
7. **Unverified Admin Email Spoof**: User with email `tomisin582@gmail.com` and `email_verified: false` tries to create a product -> Blocked by `request.auth.token.email_verified == true`.
8. **ID Poisoning**: Attacker writes `/products/` with a 500-char ID or invalid characters `../admin` -> Blocked by `isValidId(productId)`.
9. **Catalog Tampering by Customer**: Authenticated non-admin updates `/products/p1` price to `1` -> Blocked by `isAdmin()`.
10. **Terminal State Bypass on Order**: Customer updates their own order `/orders/ord1` status from `'Awaiting Payment'` to `'Completed'` -> Blocked by update action checks (`isAdmin()` required for status fulfillment transitions).
11. **Oversized String DoW**: Attacker submits feedback message with 10,000 characters -> Blocked by `message.size() <= 1000`.
12. **Audit Log Forgery**: Non-admin inserts fake entry into `/audit_logs` -> Blocked by `isAdmin()`.
