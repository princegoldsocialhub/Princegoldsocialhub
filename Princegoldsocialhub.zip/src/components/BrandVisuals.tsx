import React from 'react';
import { Phone, Share2, Package, Sparkles } from 'lucide-react';
import { CategoryGroup } from '../types';

export const BrandLogoMark: React.FC<{ logoUrl?: string; size?: 'sm' | 'md' | 'lg' }> = ({
  logoUrl,
  size = 'md',
}) => {
  const dims = size === 'sm' ? 'w-8 h-8 rounded-xl' : size === 'lg' ? 'w-14 h-14 rounded-2xl' : 'w-9 h-9 rounded-xl';
  if (logoUrl) {
    return (
      <img
        src={logoUrl}
        alt="Princegoldsocialhub logo"
        referrerPolicy="no-referrer"
        className={`${dims} object-cover border border-slate-200 bg-white shrink-0`}
      />
    );
  }
  return (
    <div
      className={`${dims} bg-gradient-to-br from-[#0B4F5B] to-[#063139] flex items-center justify-center shrink-0 shadow-sm`}
    >
      <svg viewBox="0 0 64 64" className="w-5 h-5" aria-hidden="true">
        <path
          d="M14 42 L18 22 L28 30 L32 16 L36 30 L46 22 L50 42 Z"
          fill="none"
          stroke="#FF6A00"
          strokeWidth="4.5"
          strokeLinejoin="round"
          strokeLinecap="round"
        />
        <line x1="16" y1="49" x2="48" y2="49" stroke="#FFFFFF" strokeWidth="4" strokeLinecap="round" />
        <circle cx="32" cy="14" r="3" fill="#FF6A00" />
      </svg>
    </div>
  );
};

export const ProductVisual: React.FC<{
  imageUrl?: string;
  title: string;
  group: CategoryGroup;
  className?: string;
}> = ({ imageUrl, title, group, className = 'w-full h-44' }) => {
  const [imgError, setImgError] = React.useState(false);

  if (imageUrl && !imgError) {
    return (
      <img
        src={imageUrl}
        alt={title}
        referrerPolicy="no-referrer"
        onError={() => setImgError(true)}
        className={`${className} object-cover bg-slate-100`}
      />
    );
  }

  const palette =
    group === 'phone_services'
      ? 'from-[#0B4F5B]/10 via-[#0B4F5B]/5 to-orange-50 text-[#0B4F5B]'
      : group === 'social_media'
      ? 'from-[#FF6A00]/15 via-orange-50 to-teal-50 text-[#FF6A00]'
      : 'from-slate-100 via-orange-50/60 to-teal-50/60 text-[#0B4F5B]';

  const Icon =
    group === 'phone_services' ? Phone : group === 'social_media' ? Share2 : Package;

  return (
    <div
      className={`${className} bg-gradient-to-br ${palette} flex flex-col items-center justify-center p-4 text-center`}
    >
      <div className="w-12 h-12 rounded-2xl bg-white/90 shadow-sm flex items-center justify-center mb-2">
        <Icon className="w-6 h-6" />
      </div>
      <span className="text-xs font-medium text-slate-600 line-clamp-1 max-w-[180px]">
        {title}
      </span>
    </div>
  );
};

export const PushNotificationIllustration: React.FC = () => (
  <div className="w-full rounded-2xl bg-gradient-to-br from-[#0B4F5B] via-[#0B4F5B] to-[#083B44] p-5 text-white relative overflow-hidden">
    <div className="flex items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-[#FF6A00] flex items-center justify-center shadow-lg">
          <Sparkles className="w-6 h-6 text-white" />
        </div>
        <div>
          <div className="text-xs font-medium text-teal-100">Princegoldsocialhub Alerts</div>
          <div className="text-sm font-bold text-white mt-0.5">Order #PGH-2048 Completed</div>
        </div>
      </div>
      <span className="text-xs font-mono-tabular bg-white/15 px-2.5 py-1 rounded-lg text-white">
        Live
      </span>
    </div>
  </div>
);
