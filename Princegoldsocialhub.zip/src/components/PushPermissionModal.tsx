import React, { useState } from 'react';
import { Bell, CheckCircle2, X } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { initializeFCMAndGetToken } from '../lib/firebase';
import { PushNotificationIllustration } from './BrandVisuals';

export const PushPermissionModal: React.FC = () => {
  const { pushModalOpen, setPushModalOpen, saveFcmToken, showToast } = useApp();
  const [loading, setLoading] = useState(false);

  if (!pushModalOpen) return null;

  const handleEnable = async () => {
    setLoading(true);
    try {
      const result = await initializeFCMAndGetToken();
      if (result.status === 'granted' || result.status === 'vapid_missing') {
        await saveFcmToken(result.token, true);
        showToast(result.message, result.status === 'granted' ? 'success' : 'info');
        setPushModalOpen(false);
      } else {
        showToast(result.message, 'info');
        setPushModalOpen(false);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="push-modal-title"
    >
      <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-xl border border-slate-100">
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-orange-50 text-[#FF6A00] flex items-center justify-center">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 id="push-modal-title" className="text-lg font-bold text-slate-900">
                Real-Time Princegoldsocialhub Alerts
              </h3>
              <p className="text-xs text-slate-500">Instant order status &amp; delivery tracking</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setPushModalOpen(false)}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100"
            aria-label="Close alerts prompt"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <PushNotificationIllustration />

        <div className="mt-4 space-y-2.5 text-sm text-slate-600">
          <p className="leading-relaxed">
            Stay updated the moment your Princegoldsocialhub order moves from payment verification to
            provisioning and delivery:
          </p>
          <ul className="space-y-1.5 text-xs text-slate-700">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#0B4F5B] shrink-0" />
              <span>Instant alerts when payments are verified or services start processing</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#0B4F5B] shrink-0" />
              <span>Direct jump to your Order Timeline and tracking details</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#0B4F5B] shrink-0" />
              <span>Zero marketing spam — order &amp; fulfillment updates only</span>
            </li>
          </ul>
        </div>

        <div className="mt-6 flex items-center gap-3">
          <button
            type="button"
            onClick={() => setPushModalOpen(false)}
            className="flex-1 py-2.5 px-4 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50"
          >
            Maybe Later
          </button>
          <button
            type="button"
            onClick={handleEnable}
            disabled={loading}
            className="flex-1 py-2.5 px-4 rounded-xl bg-[#FF6A00] text-white text-sm font-semibold hover:bg-[#e55f00] disabled:opacity-60 transition-colors"
          >
            {loading ? 'Enabling...' : 'Enable Alerts'}
          </button>
        </div>
      </div>
    </div>
  );
};
