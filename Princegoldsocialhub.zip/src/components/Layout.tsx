import React, { useState } from 'react';
import {
  Bell,
  Home,
  Menu,
  Phone,
  Share2,
  ShoppingBag,
  ShoppingCart,
  User,
  Package,
  CreditCard,
  HelpCircle,
  ShieldCheck,
  X,
  Headphones,
  MessageSquarePlus,
  Mail,
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { BrandLogoMark } from './BrandVisuals';
import { OfflineIndicator, PWAInstallButton } from './PWAInstallButton';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    user,
    isAdmin,
    storeConfig,
    unreadCount,
    cart,
    currentPage,
    setCurrentPage,
    setCatalogGroupFilter,
    setFeedbackModalOpen,
    toast,
  } = useApp();

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const navigateTo = (page: typeof currentPage, group?: 'all' | 'phone_services' | 'social_media') => {
    if (group) setCatalogGroupFilter(group);
    setCurrentPage(page);
    setDrawerOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navItems: {
    id: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    active: boolean;
    onClick: () => void;
    badge?: number;
  }[] = [
    {
      id: 'home',
      label: 'Home',
      icon: Home,
      active: currentPage === 'home',
      onClick: () => navigateTo('home', 'all'),
    },
    {
      id: 'catalog',
      label: 'Catalog',
      icon: ShoppingBag,
      active: currentPage === 'catalog' || currentPage === 'product',
      onClick: () => navigateTo('catalog', 'all'),
    },
    {
      id: 'phones',
      label: 'Phone Services',
      icon: Phone,
      active: false,
      onClick: () => navigateTo('catalog', 'phone_services'),
    },
    {
      id: 'social',
      label: 'Social Media',
      icon: Share2,
      active: false,
      onClick: () => navigateTo('catalog', 'social_media'),
    },
    {
      id: 'orders',
      label: 'Orders & Tracking',
      icon: Package,
      active: currentPage === 'orders',
      onClick: () => navigateTo('orders'),
    },
    {
      id: 'transactions',
      label: 'Transactions',
      icon: CreditCard,
      active: currentPage === 'transactions',
      onClick: () => navigateTo('transactions'),
    },
    {
      id: 'notifications',
      label: 'Notifications',
      icon: Bell,
      active: currentPage === 'notifications',
      onClick: () => navigateTo('notifications'),
      badge: unreadCount,
    },
    {
      id: 'profile',
      label: 'Profile & Help',
      icon: HelpCircle,
      active: currentPage === 'profile',
      onClick: () => navigateTo('profile'),
    },
  ];

  return (
    <div className="min-h-screen bg-[#F7F8FA] text-slate-900 flex flex-col">
      {/* Top White Header + Thin Orange Divider */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-14 flex items-center justify-between gap-3">
          {/* Left: Hamburger Menu */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setDrawerOpen(true)}
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-700 hover:bg-slate-100 transition-colors"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="hidden lg:block">
              <PWAInstallButton variant="compact" />
            </div>
          </div>

          {/* Center: Brand Logo & Name */}
          <button
            type="button"
            onClick={() => navigateTo('home', 'all')}
            className="flex items-center gap-2 min-w-0 focus-visible:outline-none"
          >
            <BrandLogoMark logoUrl={storeConfig.logoUrl} size="sm" />
            <span className="font-display font-bold text-base sm:text-lg tracking-tight text-[#0B4F5B] truncate">
              {storeConfig.storeName}
            </span>
          </button>

          {/* Right: Notification Bell, Cart, Profile */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => navigateTo('notifications')}
              className="relative min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-700 hover:bg-slate-100 transition-colors"
              aria-label="Notification Center"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-2 right-2 min-w-[17px] h-[17px] px-1 rounded-full bg-[#FF6A00] text-white text-[10px] font-bold flex items-center justify-center tabular-nums">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => navigateTo('checkout')}
              className="relative min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-700 hover:bg-slate-100 transition-colors"
              aria-label="Shopping Cart"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute top-2 right-1.5 min-w-[17px] h-[17px] px-1 rounded-full bg-[#0B4F5B] text-white text-[10px] font-bold flex items-center justify-center tabular-nums">
                  {cartCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => navigateTo('profile')}
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-700 hover:bg-slate-100 transition-colors"
              aria-label="Account Profile"
            >
              {user?.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName || 'Profile'}
                  referrerPolicy="no-referrer"
                  className="w-7 h-7 rounded-full object-cover border border-slate-200"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-[#0B4F5B]">
                  <User className="w-4 h-4" />
                </div>
              )}
            </button>
          </div>
        </div>
        {/* Thin Orange Brand Divider */}
        <div className="h-[2px] w-full bg-[#FF6A00]" />
      </header>

      {/* Main Content + Desktop Sidebar */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex">
        <aside className="hidden lg:flex lg:flex-col lg:w-64 shrink-0 py-6 pr-6 pl-4">
          <nav className="bg-white rounded-3xl border border-slate-200/80 shadow-xs p-3 space-y-1 sticky top-20">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={item.onClick}
                  className={`w-full flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-2xl text-sm font-medium transition-colors whitespace-nowrap ${
                    item.active
                      ? 'bg-[#FF6A00]/10 text-[#FF6A00] font-semibold'
                      : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <span className="flex items-center gap-3">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </span>
                  {item.badge && item.badge > 0 ? (
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-[#FF6A00] text-white tabular-nums">
                      {item.badge}
                    </span>
                  ) : null}
                </button>
              );
            })}

            {isAdmin && (
              <div className="pt-2 mt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => navigateTo('admin')}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm font-semibold transition-colors whitespace-nowrap ${
                    currentPage === 'admin'
                      ? 'bg-[#0B4F5B] text-white'
                      : 'text-[#0B4F5B] bg-teal-50/70 hover:bg-teal-50'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  <span>Owner Admin Panel</span>
                </button>
              </div>
            )}
          </nav>
        </aside>

        <main className="flex-1 min-w-0 px-4 sm:px-6 py-5 pb-28 lg:pb-12">{children}</main>
      </div>

      {/* Mobile Slide-Out Hamburger Drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-xs"
            onClick={() => setDrawerOpen(false)}
          />
          <div className="relative w-72 max-w-[85vw] bg-white h-full shadow-2xl flex flex-col z-10">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <BrandLogoMark logoUrl={storeConfig.logoUrl} size="sm" />
                <span className="font-display font-bold text-base text-[#0B4F5B] truncate">
                  {storeConfig.storeName}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100"
                aria-label="Close navigation menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={item.onClick}
                    className={`w-full flex items-center justify-between gap-3 px-3.5 py-3 rounded-2xl text-sm font-medium transition-colors ${
                      item.active
                        ? 'bg-[#FF6A00]/10 text-[#FF6A00] font-semibold'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <Icon className="w-4 h-4 shrink-0" />
                      <span>{item.label}</span>
                    </span>
                    {item.badge && item.badge > 0 ? (
                      <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-[#FF6A00] text-white tabular-nums">
                        {item.badge}
                      </span>
                    ) : null}
                  </button>
                );
              })}

              {isAdmin && (
                <div className="pt-3 mt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => navigateTo('admin')}
                    className="w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl text-sm font-semibold bg-[#0B4F5B] text-white"
                  >
                    <ShieldCheck className="w-4 h-4 shrink-0" />
                    <span>Owner Admin Panel</span>
                  </button>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-100 flex items-center justify-between">
              <PWAInstallButton variant="compact" />
              <span className="text-xs text-slate-400">
                {user ? user.email?.split('@')[0] : 'Guest'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Fixed Pill-Shaped Bottom Navigation */}
      <nav
        aria-label="Mobile Bottom Navigation"
        className="lg:hidden fixed bottom-3 left-3 right-3 z-40 max-w-md mx-auto"
      >
        <div className="bg-white/95 backdrop-blur-md rounded-full shadow-lg border border-slate-200/90 px-2 h-14 grid grid-cols-5 items-center">
          <button
            type="button"
            onClick={() => navigateTo('home', 'all')}
            className={`flex flex-col items-center justify-center py-1 rounded-full ${
              currentPage === 'home' ? 'text-[#FF6A00]' : 'text-slate-500'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] font-semibold mt-0.5 leading-none">Home</span>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('catalog', 'phone_services')}
            className="flex flex-col items-center justify-center py-1 rounded-full text-slate-500 hover:text-[#0B4F5B]"
          >
            <Phone className="w-5 h-5" />
            <span className="text-[10px] font-semibold mt-0.5 leading-none">Phones</span>
          </button>

          {/* Raised Central Catalog Button */}
          <div className="flex flex-col items-center justify-center relative">
            <button
              type="button"
              onClick={() => navigateTo('catalog', 'all')}
              className="-mt-6 w-12 h-12 rounded-full bg-[#FF6A00] text-white shadow-md shadow-[#FF6A00]/30 flex items-center justify-center hover:bg-[#e55f00] active:scale-95 transition-transform"
              aria-label="Open Catalog"
            >
              <ShoppingBag className="w-5 h-5" />
            </button>
            <span className="text-[10px] font-bold text-[#0B4F5B] mt-0.5 leading-none">
              Catalog
            </span>
          </div>

          <button
            type="button"
            onClick={() => navigateTo('catalog', 'social_media')}
            className="flex flex-col items-center justify-center py-1 rounded-full text-slate-500 hover:text-[#FF6A00]"
          >
            <Share2 className="w-5 h-5" />
            <span className="text-[10px] font-semibold mt-0.5 leading-none">Social</span>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('orders')}
            className={`flex flex-col items-center justify-center py-1 rounded-full ${
              currentPage === 'orders' || currentPage === 'transactions'
                ? 'text-[#0B4F5B]'
                : 'text-slate-500'
            }`}
          >
            <Package className="w-5 h-5" />
            <span className="text-[10px] font-semibold mt-0.5 leading-none">Orders</span>
          </button>
        </div>
      </nav>

      {/* Floating Support Button */}
      <div className="fixed bottom-20 right-4 lg:bottom-6 lg:right-6 z-30">
        {supportOpen && (
          <div className="mb-2 w-64 rounded-2xl bg-white shadow-xl border border-slate-200 p-3 space-y-1.5">
            <div className="px-2 py-1 text-xs font-bold text-[#0B4F5B]">
              Princegoldsocialhub Support
            </div>
            <a
              href={`mailto:${storeConfig.supportEmail}`}
              className="flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-xs font-medium text-slate-700 hover:bg-slate-50"
            >
              <Mail className="w-4 h-4 text-[#FF6A00]" />
              <span className="truncate">{storeConfig.supportEmail}</span>
            </a>
            <button
              type="button"
              onClick={() => {
                setSupportOpen(false);
                setFeedbackModalOpen(true);
              }}
              className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-xs font-semibold text-[#0B4F5B] hover:bg-teal-50"
            >
              <MessageSquarePlus className="w-4 h-4 text-[#FF6A00]" />
              <span>Send Feedback / Report Issue</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setSupportOpen(false);
                navigateTo('profile');
              }}
              className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-xs font-medium text-slate-700 hover:bg-slate-50"
            >
              <HelpCircle className="w-4 h-4 text-[#0B4F5B]" />
              <span>FAQs &amp; Store Policies</span>
            </button>
          </div>
        )}
        <button
          type="button"
          onClick={() => setSupportOpen((s) => !s)}
          className="w-12 h-12 rounded-full bg-[#0B4F5B] text-white shadow-lg flex items-center justify-center hover:bg-[#093f49] active:scale-95 transition-transform"
          aria-label="Customer Support"
        >
          {supportOpen ? <X className="w-5 h-5" /> : <Headphones className="w-5 h-5" />}
        </button>
      </div>

      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-16 right-4 z-50 max-w-sm">
          <div
            className={`px-4 py-3 rounded-2xl shadow-lg border text-sm font-medium ${
              toast.type === 'error'
                ? 'bg-red-50 border-red-200 text-red-800'
                : toast.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-white border-slate-200 text-slate-800'
            }`}
          >
            {toast.message}
          </div>
        </div>
      )}

      <OfflineIndicator />
    </div>
  );
};
