import React, { useState } from 'react';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { Star, X, MessageSquareHeart } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useApp } from '../contexts/AppContext';

export const FeedbackModal: React.FC = () => {
  const { user, feedbackModalOpen, setFeedbackModalOpen, showToast, setCurrentPage } = useApp();
  const [rating, setRating] = useState(5);
  const [category, setCategory] = useState('Suggestion');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!feedbackModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!user) {
      setFeedbackModalOpen(false);
      showToast('Please sign in first to submit feedback.', 'info');
      setCurrentPage('profile');
      return;
    }
    const trimmed = message.trim();
    if (!trimmed) {
      setError('Please enter your suggestion or issue details.');
      return;
    }
    if (trimmed.length > 1000) {
      setError('Feedback message must be 1000 characters or fewer.');
      return;
    }

    setSubmitting(true);
    try {
      await addDoc(collection(db, 'feedback'), {
        userId: user.uid,
        userEmail: (user.email || 'customer@princegoldsocialhub.com').slice(0, 160),
        rating,
        category: category.slice(0, 60),
        message: trimmed,
        createdAt: serverTimestamp(),
      });
      setMessage('');
      setRating(5);
      setFeedbackModalOpen(false);
      showToast('Thank you! Your feedback has been submitted.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'feedback');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="feedback-modal-title"
    >
      <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-xl border border-slate-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-orange-50 text-[#FF6A00] flex items-center justify-center">
              <MessageSquareHeart className="w-5 h-5" />
            </div>
            <div>
              <h3 id="feedback-modal-title" className="text-lg font-bold text-slate-900">
                Share Feedback
              </h3>
              <p className="text-xs text-slate-500">Help us improve Princegoldsocialhub</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setFeedbackModalOpen(false)}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100"
            aria-label="Close feedback modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">
              Your Experience Rating
            </label>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  className="min-w-[44px] min-h-[44px] rounded-xl border border-slate-200 flex items-center justify-center hover:border-[#FF6A00] transition-colors"
                  aria-label={`Rate ${star} out of 5`}
                >
                  <Star
                    className={`w-5 h-5 ${
                      star <= rating ? 'fill-[#FF6A00] text-[#FF6A00]' : 'text-slate-300'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label htmlFor="feedback-category" className="block text-xs font-semibold text-slate-700 mb-1.5">
              Feedback Type
            </label>
            <select
              id="feedback-category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#FF6A00]/30 focus:border-[#FF6A00]"
            >
              <option value="Suggestion">Feature Suggestion</option>
              <option value="Order Support">Order or Delivery Inquiry</option>
              <option value="Bug Report">Report an Issue</option>
              <option value="Compliment">Service Compliment</option>
            </select>
          </div>

          <div>
            <label htmlFor="feedback-message" className="block text-xs font-semibold text-slate-700 mb-1.5">
              Details
            </label>
            <textarea
              id="feedback-message"
              rows={4}
              maxLength={1000}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell us what worked well or what issue you encountered..."
              className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#FF6A00]/30 focus:border-[#FF6A00]"
            />
            <div className="mt-1 text-right text-xs text-slate-400 tabular-nums">
              {message.length}/1000
            </div>
          </div>

          {error && (
            <p className="text-xs font-medium text-red-600 bg-red-50 px-3 py-2 rounded-xl">
              {error}
            </p>
          )}

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setFeedbackModalOpen(false)}
              className="px-4 py-2.5 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2.5 rounded-xl bg-[#FF6A00] text-white text-sm font-semibold hover:bg-[#e55f00] disabled:opacity-60 transition-colors"
            >
              {submitting ? 'Submitting...' : 'Submit Feedback'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
