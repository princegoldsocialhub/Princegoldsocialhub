import React from 'react';
import { X, ShoppingBag, Trash2 } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { formatCurrency } from '../lib/storeDefaults';
import { ProductVisual } from './BrandVisuals';

export const ProductComparisonModal: React.FC = () => {
  const {
    products,
    categories,
    compareIds,
    compareModalOpen,
    setCompareModalOpen,
    toggleCompare,
    clearCompare,
    addToCart,
    storeConfig,
  } = useApp();

  if (!compareModalOpen) return null;

  const selected = products.filter((p) => compareIds.includes(p.id));
  const getCatName = (catId: string) =>
    categories.find((c) => c.id === catId)?.name || 'Service';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="compare-modal-title"
    >
      <div className="w-full max-w-4xl max-h-[90vh] flex flex-col rounded-3xl bg-white shadow-xl border border-slate-100 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <div>
            <h3 id="compare-modal-title" className="text-lg font-bold text-slate-900">
              Compare Services &amp; Products ({selected.length}/3)
            </h3>
            <p className="text-xs text-slate-500">
              Side-by-side pricing, SKUs, delivery estimates, and terms
            </p>
          </div>
          <div className="flex items-center gap-2">
            {selected.length > 0 && (
              <button
                type="button"
                onClick={clearCompare}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Clear All
              </button>
            )}
            <button
              type="button"
              onClick={() => setCompareModalOpen(false)}
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100"
              aria-label="Close comparison modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-auto">
          {selected.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-sm text-slate-500">
                Select up to 3 products from the Catalog to compare them side by side.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[560px]">
                <thead>
                  <tr className="border-b border-slate-100">
                    <th className="py-3 pr-4 text-xs font-semibold text-slate-500 w-36 align-top">
                      Attribute
                    </th>
                    {selected.map((p) => (
                      <th key={p.id} className="py-3 px-3 align-top min-w-[180px]">
                        <div className="rounded-2xl overflow-hidden border border-slate-100 mb-2">
                          <ProductVisual
                            imageUrl={p.imageUrl}
                            title={p.title}
                            group={p.categoryGroup}
                            className="w-full h-28"
                          />
                        </div>
                        <div className="flex items-start justify-between gap-2">
                          <div className="text-sm font-bold text-slate-900">{p.title}</div>
                          <button
                            type="button"
                            onClick={() => toggleCompare(p.id)}
                            className="p-1 text-slate-400 hover:text-red-500"
                            title="Remove from comparison"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  <tr>
                    <td className="py-3 pr-4 text-xs font-semibold text-slate-500">Price</td>
                    {selected.map((p) => (
                      <td key={p.id} className="py-3 px-3 font-bold text-[#0B4F5B] tabular-nums">
                        {formatCurrency(p.price, storeConfig.currencySymbol)}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 text-xs font-semibold text-slate-500">Inventory SKU</td>
                    {selected.map((p) => (
                      <td key={p.id} className="py-3 px-3 font-mono-tabular text-xs text-slate-700">
                        {p.sku}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 text-xs font-semibold text-slate-500">Category</td>
                    {selected.map((p) => (
                      <td key={p.id} className="py-3 px-3 text-slate-700">
                        {getCatName(p.categoryId)}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 text-xs font-semibold text-slate-500">Fulfillment</td>
                    {selected.map((p) => (
                      <td key={p.id} className="py-3 px-3 text-slate-700 capitalize">
                        {p.fulfillmentMethod.replace('_', ' ')}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 text-xs font-semibold text-slate-500">Delivery Est.</td>
                    {selected.map((p) => (
                      <td key={p.id} className="py-3 px-3 text-slate-700">
                        {p.deliveryEstimate || 'Confirmed upon checkout'}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 text-xs font-semibold text-slate-500">Availability</td>
                    {selected.map((p) => (
                      <td key={p.id} className="py-3 px-3">
                        {p.available && (!p.trackStock || p.stock > 0) ? (
                          <span className="text-xs font-semibold text-emerald-700">
                            Available {p.trackStock ? `(${p.stock} left)` : ''}
                          </span>
                        ) : (
                          <span className="text-xs font-semibold text-red-600">Out of Stock</span>
                        )}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 text-xs font-semibold text-slate-500">Terms</td>
                    {selected.map((p) => (
                      <td key={p.id} className="py-3 px-3 text-xs text-slate-600">
                        {p.terms || 'Standard lawful service terms apply.'}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 text-xs font-semibold text-slate-500">Action</td>
                    {selected.map((p) => (
                      <td key={p.id} className="py-3 px-3">
                        <button
                          type="button"
                          onClick={() => addToCart(p, 1)}
                          disabled={!p.available || (p.trackStock && p.stock <= 0)}
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold hover:bg-[#e55f00] disabled:opacity-50"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          Add to Cart
                        </button>
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
