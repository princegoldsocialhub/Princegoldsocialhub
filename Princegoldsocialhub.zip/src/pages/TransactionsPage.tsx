import React from 'react';
import { CreditCard, ShieldCheck, ArrowUpRight } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { formatCurrency, formatDateTime } from '../lib/storeDefaults';

export const TransactionsPage: React.FC = () => {
  const {
    user,
    customerPayments,
    customerOrders,
    storeConfig,
    setCurrentPage,
    openOrderTracking,
  } = useApp();

  const verifiedTotal = customerOrders
    .filter((o) => o.paymentStatus === 'verified_paid')
    .reduce((sum, o) => sum + (o.totalAmount || 0), 0);

  return (
    <div className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-br from-[#0B4F5B] to-[#07363f] p-6 text-white shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-medium text-teal-200">
              Verified Direct Checkout Summary
            </div>
            <div className="mt-1 text-2xl sm:text-3xl font-bold tabular-nums">
              {formatCurrency(verifiedTotal, storeConfig.currencySymbol)}
            </div>
            <p className="mt-1 text-xs text-teal-100 max-w-xl">
              Princegoldsocialhub processes orders through secure direct checkout (Paystack /
              Flutterwave) with server-side verification rather than holding unverified stored wallet
              balances.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs bg-white/10 px-3.5 py-2 rounded-xl shrink-0">
            <ShieldCheck className="w-4 h-4 text-[#FF6A00]" />
            <span>Genuine Confirmed Records Only</span>
          </div>
        </div>
      </div>

      <section className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-bold text-slate-900">Transaction History</h1>
          <span className="text-xs text-slate-400 tabular-nums">
            {customerPayments.length} record{customerPayments.length === 1 ? '' : 's'}
          </span>
        </div>

        {!user ? (
          <div className="py-10 text-center space-y-3">
            <CreditCard className="w-9 h-9 text-slate-300 mx-auto" />
            <p className="text-sm text-slate-600">
              Sign in to view your genuine payment and transaction history.
            </p>
            <button
              type="button"
              onClick={() => setCurrentPage('profile')}
              className="px-4 py-2 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold"
            >
              Sign In
            </button>
          </div>
        ) : customerPayments.length === 0 ? (
          <div className="py-10 text-center space-y-3">
            <CreditCard className="w-9 h-9 text-slate-300 mx-auto" />
            <p className="text-sm text-slate-600">No payment transactions recorded yet.</p>
            <button
              type="button"
              onClick={() => setCurrentPage('catalog')}
              className="px-4 py-2 rounded-xl bg-[#0B4F5B] text-white text-xs font-semibold"
            >
              Browse Catalog
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {customerPayments.map((payment) => (
              <div
                key={payment.id}
                className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-0.5">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="font-mono-tabular font-bold text-slate-900">
                      {payment.reference}
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="uppercase font-semibold text-[#0B4F5B]">
                      {payment.provider.replace('_', ' ')}
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="text-slate-500">{formatDateTime(payment.createdAt)}</span>
                  </div>
                  <div className="text-xs text-slate-600">
                    Order <strong className="font-mono-tabular">{payment.orderNumber}</strong> ·{' '}
                    Status:{' '}
                    <strong
                      className={
                        payment.status === 'verified'
                          ? 'text-emerald-700'
                          : payment.status === 'failed'
                          ? 'text-red-600'
                          : 'text-amber-700'
                      }
                    >
                      {payment.status}
                    </strong>
                    {payment.verifiedServerSide ? ' (Server Verified)' : ''}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-sm font-bold text-slate-900 tabular-nums">
                    {formatCurrency(payment.amount, storeConfig.currencySymbol)}
                  </span>
                  <button
                    type="button"
                    onClick={() => openOrderTracking(payment.orderNumber)}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-[#FF6A00] hover:underline"
                  >
                    Order <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
