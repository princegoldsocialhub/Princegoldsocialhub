import React, { useState } from 'react';
import {
  ArrowRight,
  CreditCard,
  Megaphone,
  Package,
  Phone,
  Share2,
  ShieldCheck,
  Sparkles,
  X,
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { formatCurrency } from '../lib/storeDefaults';
import { ProductVisual } from '../components/BrandVisuals';
import { PWAInstallButton } from '../components/PWAInstallButton';

export const HomePage: React.FC = () => {
  const {
    user,
    isAdmin,
    storeConfig,
    categories,
    products,
    customerOrders,
    setCurrentPage,
    setCatalogGroupFilter,
    openProductDetail,
  } = useApp();

  const dismissKey = `pgh_banner_dismissed_${storeConfig.announcementVersion || 'v1'}`;
  const [bannerDismissed, setBannerDismissed] = useState<boolean>(() => {
    try {
      return localStorage.getItem(dismissKey) === '1';
    } catch {
      return false;
    }
  });

  const handleDismissBanner = () => {
    setBannerDismissed(true);
    try {
      localStorage.setItem(dismissKey, '1');
    } catch {
      // ignore
    }
  };

  // Only genuine confirmed spending from verified paid orders (no fake wallet balances)
  const confirmedTotalSpend = customerOrders
    .filter((o) => o.paymentStatus === 'verified_paid')
    .reduce((sum, o) => sum + (o.totalAmount || 0), 0);

  const enabledCategories = categories.filter((c) => c.enabled);
  const featuredProducts = products.filter((p) => p.published).slice(0, 4);

  return (
    <div className="space-y-5">
      {/* Dismissible Persistent Admin Announcement Banner */}
      {storeConfig.announcementEnabled &&
        storeConfig.announcementText &&
        !bannerDismissed && (
          <div className="rounded-2xl bg-[#0B4F5B] text-white px-4 py-3 flex items-start justify-between gap-3 shadow-xs">
            <div className="flex items-start gap-2.5 text-sm">
              <Megaphone className="w-4 h-4 text-[#FF6A00] mt-0.5 shrink-0" />
              <p className="leading-snug">{storeConfig.announcementText}</p>
            </div>
            <button
              type="button"
              onClick={handleDismissBanner}
              className="min-w-[32px] min-h-[32px] flex items-center justify-center rounded-lg hover:bg-white/10 text-teal-100 shrink-0"
              aria-label="Dismiss announcement"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

      {/* Welcome & Trust Header */}
      <section className="bg-white rounded-3xl p-5 sm:p-6 shadow-xs border border-slate-100">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              {storeConfig.welcomeTitle}
            </h1>
            <p className="text-sm text-slate-600 leading-relaxed">
              {storeConfig.welcomeSubtitle}
            </p>
            <div className="pt-1 flex items-center gap-2 text-xs font-medium text-[#0B4F5B]">
              <ShieldCheck className="w-4 h-4 text-[#FF6A00] shrink-0" />
              <span>{storeConfig.trustBannerText}</span>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <PWAInstallButton variant="card" />
            {isAdmin && (
              <button
                type="button"
                onClick={() => setCurrentPage('admin')}
                className="px-4 py-2.5 rounded-xl border border-[#0B4F5B]/30 text-[#0B4F5B] text-sm font-semibold hover:bg-teal-50 transition-colors"
              >
                Open Admin Panel
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Subtle Warm Orange Gradient Feature / Account Summary Card */}
      <section className="rounded-3xl bg-gradient-to-br from-[#FF6A00] via-[#FF7D1F] to-[#E55300] p-5 sm:p-6 text-white shadow-md shadow-[#FF6A00]/15">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-medium text-orange-100">
              {user ? `Signed in as ${user.displayName || user.email}` : 'Direct Checkout Account Summary'}
            </div>
            <div className="mt-1.5 flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-bold tabular-nums">
                {formatCurrency(confirmedTotalSpend, storeConfig.currencySymbol)}
              </span>
              <span className="text-xs text-orange-100">Confirmed Spend</span>
            </div>
            <p className="mt-1 text-xs text-orange-50">
              {user
                ? `${customerOrders.length} total order${customerOrders.length === 1 ? '' : 's'} · Direct checkout verified by provider`
                : 'Sign in to view your confirmed transactions and track orders in real time.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => setCurrentPage('transactions')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-[#0B4F5B] text-xs sm:text-sm font-bold hover:bg-orange-50 transition-colors"
            >
              <CreditCard className="w-4 h-4" />
              Transactions
            </button>
            <button
              type="button"
              onClick={() => setCurrentPage('orders')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#0B4F5B] text-white text-xs sm:text-sm font-bold hover:bg-[#083c45] transition-colors"
            >
              <Package className="w-4 h-4" />
              Track Order
            </button>
          </div>
        </div>
      </section>

      {/* Catalog Category Shortcut Cards */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base sm:text-lg font-bold text-slate-900">Browse Categories</h2>
          <button
            type="button"
            onClick={() => {
              setCatalogGroupFilter('all');
              setCurrentPage('catalog');
            }}
            className="text-xs font-semibold text-[#FF6A00] hover:underline inline-flex items-center gap-1"
          >
            View All Catalog <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {enabledCategories.map((cat) => {
            const Icon =
              cat.group === 'phone_services'
                ? Phone
                : cat.group === 'social_media'
                ? Share2
                : Sparkles;
            const itemCount = products.filter(
              (p) => p.published && (p.categoryId === cat.id || p.categoryGroup === cat.group)
            ).length;

            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => {
                  setCatalogGroupFilter(cat.group);
                  setCurrentPage('catalog');
                }}
                className="text-left bg-white rounded-3xl p-5 border border-slate-100 shadow-xs hover:shadow-md hover:border-[#FF6A00]/40 transition-all group"
              >
                <div className="flex items-start justify-between gap-3">
                  <div
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center ${
                      cat.group === 'phone_services'
                        ? 'bg-teal-50 text-[#0B4F5B]'
                        : 'bg-orange-50 text-[#FF6A00]'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-medium text-slate-400 tabular-nums">
                    {itemCount} {itemCount === 1 ? 'listing' : 'listings'}
                  </span>
                </div>
                <h3 className="mt-4 text-base font-bold text-slate-900 group-hover:text-[#FF6A00] transition-colors">
                  {cat.name}
                </h3>
                <p className="mt-1 text-xs text-slate-600 line-clamp-2 leading-relaxed">
                  {cat.description}
                </p>
              </button>
            );
          })}
        </div>
      </section>

      {/* Catalog Preview or Helpful Empty State */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base sm:text-lg font-bold text-slate-900">Storefront Listings</h2>
          <button
            type="button"
            onClick={() => setCurrentPage('catalog')}
            className="text-xs font-semibold text-[#0B4F5B] hover:underline"
          >
            Explore Catalog
          </button>
        </div>

        {featuredProducts.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-100 shadow-xs">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 text-[#0B4F5B] flex items-center justify-center mx-auto mb-3">
              <Package className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Catalog Ready for Real Listings</h3>
            <p className="mt-1.5 text-sm text-slate-600 max-w-md mx-auto">
              No products or services have been published yet. Once the store owner adds listings from
              the Admin Panel, they will appear here automatically.
            </p>
            <div className="mt-4 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => setCurrentPage('catalog')}
                className="px-4 py-2 rounded-xl bg-slate-100 text-slate-800 text-xs font-semibold hover:bg-slate-200"
              >
                Open Catalog
              </button>
              {isAdmin && (
                <button
                  type="button"
                  onClick={() => setCurrentPage('admin')}
                  className="px-4 py-2 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold hover:bg-[#e55f00]"
                >
                  Add First Listing
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {featuredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-3xl overflow-hidden border border-slate-100 shadow-xs flex flex-col"
              >
                <ProductVisual
                  imageUrl={product.imageUrl}
                  title={product.title}
                  group={product.categoryGroup}
                  className="w-full h-36"
                />
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="text-xs font-mono-tabular text-slate-400">
                      SKU: {product.sku}
                    </div>
                    <h3 className="mt-1 text-sm font-bold text-slate-900 line-clamp-1">
                      {product.title}
                    </h3>
                    <p className="mt-1 text-xs text-slate-600 line-clamp-2">
                      {product.description}
                    </p>
                  </div>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-sm font-bold text-[#0B4F5B] tabular-nums">
                      {formatCurrency(product.price, storeConfig.currencySymbol)}
                    </span>
                    <button
                      type="button"
                      onClick={() => openProductDetail(product.id)}
                      className="px-3 py-1.5 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold hover:bg-[#e55f00]"
                    >
                      Details
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
