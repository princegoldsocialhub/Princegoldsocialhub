import React, { useState } from 'react';
import {
  Bell,
  Heart,
  HelpCircle,
  LogOut,
  Mail,
  MessageSquarePlus,
  Phone,
  ShieldCheck,
  ShoppingBag,
  User as UserIcon,
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { formatCurrency } from '../lib/storeDefaults';
import { ProductVisual } from '../components/BrandVisuals';

export const ProfileHelpPage: React.FC = () => {
  const {
    user,
    isAdmin,
    userProfile,
    storeConfig,
    products,
    wishlistIds,
    toggleWishlist,
    faqs,
    policies,
    signInWithGoogle,
    signInEmail,
    signUpEmail,
    resetPassword,
    signOut,
    openProductDetail,
    addToCart,
    setCurrentPage,
    setFeedbackModalOpen,
    setPushModalOpen,
    showToast,
  } = useApp();

  const [tab, setTab] = useState<'account' | 'wishlist' | 'help'>('account');
  const [authMode, setAuthMode] = useState<'signin' | 'signup' | 'forgot'>('signin');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState('');

  const wishlistProducts = products.filter((p) => wishlistIds.includes(p.id));

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthLoading(true);
    try {
      if (authMode === 'forgot') {
        if (!email.trim()) throw new Error('Enter your account email address.');
        await resetPassword(email);
        setAuthMode('signin');
      } else if (authMode === 'signup') {
        if (password.length < 6) throw new Error('Password must be at least 6 characters.');
        await signUpEmail(name, email, password);
      } else {
        await signInEmail(email, password);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Authentication error.';
      if (msg.includes('operation-not-allowed')) {
        setAuthError(
          'Email/Password sign-in is not yet enabled in Firebase Console -> Authentication -> Sign-in method. Please use Google Sign-In or enable Email/Password in Firebase Console.'
        );
      } else {
        setAuthError(msg);
      }
    } finally {
      setAuthLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Segmented Tabs */}
      <div className="bg-white rounded-2xl p-1.5 border border-slate-100 shadow-xs inline-flex flex-wrap gap-1">
        {(
          [
            { id: 'account', label: 'Account & Security' },
            { id: 'wishlist', label: `Wishlist (${wishlistProducts.length})` },
            { id: 'help', label: 'Help, FAQs & Policies' },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
              tab === t.id
                ? 'bg-[#0B4F5B] text-white'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'account' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {!user ? (
            <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs space-y-4">
              <div>
                <h1 className="text-xl font-bold text-slate-900">
                  {authMode === 'signup'
                    ? 'Create Customer Account'
                    : authMode === 'forgot'
                    ? 'Reset Password'
                    : 'Sign In to Princegoldsocialhub'}
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Manage orders, saved wishlist items, and real-time status notifications
                </p>
              </div>

              <button
                type="button"
                onClick={async () => {
                  setAuthError('');
                  try {
                    await signInWithGoogle();
                  } catch (err) {
                    setAuthError(err instanceof Error ? err.message : 'Google Sign-In failed.');
                  }
                }}
                className="w-full py-2.5 px-4 rounded-xl border border-slate-300 bg-white text-slate-800 text-sm font-semibold hover:bg-slate-50 flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4 h-4 text-[#FF6A00]" />
                Continue with Google
              </button>

              <div className="relative flex py-1 items-center">
                <div className="flex-grow border-t border-slate-200" />
                <span className="shrink mx-3 text-xs text-slate-400">or email</span>
                <div className="flex-grow border-t border-slate-200" />
              </div>

              <form onSubmit={handleEmailAuth} className="space-y-3">
                {authMode === 'signup' && (
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Full Name"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-[#FF6A00]"
                  />
                )}
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email address"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-[#FF6A00]"
                />
                {authMode !== 'forgot' && (
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-[#FF6A00]"
                  />
                )}

                {authError && (
                  <div className="rounded-xl bg-red-50 text-red-700 px-3 py-2 text-xs">
                    {authError}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={authLoading}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#FF6A00] text-white text-sm font-bold hover:bg-[#e55f00] disabled:opacity-60"
                >
                  {authLoading
                    ? 'Please wait...'
                    : authMode === 'signup'
                    ? 'Create Account'
                    : authMode === 'forgot'
                    ? 'Send Reset Link'
                    : 'Sign In'}
                </button>
              </form>

              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 pt-1">
                {authMode === 'signin' ? (
                  <>
                    <button
                      type="button"
                      onClick={() => setAuthMode('forgot')}
                      className="text-[#0B4F5B] font-semibold hover:underline"
                    >
                      Forgot password?
                    </button>
                    <button
                      type="button"
                      onClick={() => setAuthMode('signup')}
                      className="text-[#FF6A00] font-semibold hover:underline"
                    >
                      Create an account
                    </button>
                  </>
                ) : (
                  <button
                    type="button"
                    onClick={() => setAuthMode('signin')}
                    className="text-[#0B4F5B] font-semibold hover:underline"
                  >
                    Back to Sign In
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs space-y-5">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-teal-50 text-[#0B4F5B] flex items-center justify-center">
                  <UserIcon className="w-6 h-6" />
                </div>
                <div>
                  <h1 className="text-lg font-bold text-slate-900">
                    {userProfile?.displayName || user.displayName || 'Customer Account'}
                  </h1>
                  <p className="text-xs text-slate-500">{user.email}</p>
                </div>
              </div>

              <div className="space-y-2.5 text-sm">
                <button
                  type="button"
                  onClick={() => setCurrentPage('orders')}
                  className="w-full flex items-center justify-between px-4 py-3 rounded-2xl bg-slate-50 hover:bg-slate-100 font-medium text-slate-800"
                >
                  <span>View My Orders &amp; Tracking</span>
                  <span className="text-xs text-[#FF6A00] font-semibold">Open</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPushModalOpen(true)}
                  className="w-full flex items-center justify-between px-4 py-3 rounded-2xl bg-slate-50 hover:bg-slate-100 font-medium text-slate-800"
                >
                  <span className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-[#FF6A00]" />
                    Order Status Push Notifications
                  </span>
                  <span className="text-xs font-semibold text-[#0B4F5B]">
                    {userProfile?.notificationsEnabled ? 'Configured' : 'Enable'}
                  </span>
                </button>

                {isAdmin && (
                  <button
                    type="button"
                    onClick={() => setCurrentPage('admin')}
                    className="w-full flex items-center justify-between px-4 py-3 rounded-2xl bg-[#0B4F5B] text-white font-semibold"
                  >
                    <span className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-[#FF6A00]" />
                      Owner Admin Panel
                    </span>
                    <span className="text-xs">Manage Store</span>
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={signOut}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          )}

          {/* Direct Support Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900">Contact &amp; Support</h2>
            <p className="text-xs text-slate-600 leading-relaxed">
              Need assistance with a service package, business phone number provisioning, or order
              tracking? Reach out directly or submit feedback.
            </p>
            <div className="space-y-2.5 text-sm">
              <a
                href={`mailto:${storeConfig.supportEmail}`}
                className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50 hover:bg-orange-50 text-slate-800"
              >
                <Mail className="w-4 h-4 text-[#FF6A00]" />
                <span>{storeConfig.supportEmail}</span>
              </a>
              <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50 text-slate-800">
                <Phone className="w-4 h-4 text-[#0B4F5B]" />
                <span>{storeConfig.supportPhone}</span>
              </div>
              <button
                type="button"
                onClick={() => setFeedbackModalOpen(true)}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#FF6A00] text-white text-sm font-bold hover:bg-[#e55f00]"
              >
                <MessageSquarePlus className="w-4 h-4" />
                Submit Feedback or Report an Issue
              </button>
            </div>
          </div>
        </div>
      )}

      {tab === 'wishlist' && (
        <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900">Saved Wishlist</h2>
            <span className="text-xs text-slate-400 tabular-nums">
              {wishlistProducts.length} saved
            </span>
          </div>

          {wishlistProducts.length === 0 ? (
            <div className="py-10 text-center space-y-3">
              <Heart className="w-9 h-9 text-slate-300 mx-auto" />
              <p className="text-sm text-slate-600">
                {user
                  ? 'You have not saved any products to your wishlist yet.'
                  : 'Sign in and tap the heart icon on any catalog listing to save it here.'}
              </p>
              <button
                type="button"
                onClick={() => setCurrentPage('catalog')}
                className="px-4 py-2 rounded-xl bg-[#0B4F5B] text-white text-xs font-semibold"
              >
                Browse Catalog
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {wishlistProducts.map((p) => (
                <div
                  key={p.id}
                  className="rounded-2xl border border-slate-100 overflow-hidden flex flex-col"
                >
                  <ProductVisual
                    imageUrl={p.imageUrl}
                    title={p.title}
                    group={p.categoryGroup}
                    className="w-full h-36"
                  />
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="text-xs font-mono-tabular text-slate-400">{p.sku}</div>
                      <h3 className="text-sm font-bold text-slate-900">{p.title}</h3>
                      <div className="text-sm font-bold text-[#0B4F5B] mt-1 tabular-nums">
                        {formatCurrency(p.price, storeConfig.currencySymbol)}
                      </div>
                    </div>
                    <div className="mt-3 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => openProductDetail(p.id)}
                        className="flex-1 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700"
                      >
                        View
                      </button>
                      <button
                        type="button"
                        onClick={() => addToCart(p, 1)}
                        className="py-2 px-3 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold inline-flex items-center gap-1"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        Add
                      </button>
                      <button
                        type="button"
                        onClick={() => toggleWishlist(p.id)}
                        className="py-2 px-2.5 rounded-xl bg-slate-100 text-slate-600 text-xs font-semibold"
                        title="Remove from wishlist"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'help' && (
        <div className="space-y-5">
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-[#FF6A00]" />
                <h2 className="text-lg font-bold text-slate-900">Frequently Asked Questions</h2>
              </div>
              <button
                type="button"
                onClick={() => setFeedbackModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold hover:bg-[#e55f00]"
              >
                <MessageSquarePlus className="w-3.5 h-3.5" />
                Give Feedback
              </button>
            </div>
            <div className="divide-y divide-slate-100">
              {faqs.map((f) => (
                <div key={f.id} className="py-3.5">
                  <h3 className="text-sm font-bold text-slate-900">{f.question}</h3>
                  <p className="mt-1 text-xs text-slate-600 leading-relaxed">{f.answer}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs space-y-4">
            <h2 className="text-lg font-bold text-slate-900">Store Policies &amp; Compliance</h2>
            <div className="space-y-4">
              {policies.map((pol) => (
                <div key={pol.id} className="rounded-2xl bg-slate-50 p-4 border border-slate-100">
                  <h3 className="text-sm font-bold text-[#0B4F5B]">{pol.title}</h3>
                  <p className="mt-1 text-xs text-slate-600 leading-relaxed whitespace-pre-line">
                    {pol.content}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
