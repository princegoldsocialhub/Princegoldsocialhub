import React, { useMemo, useState } from 'react';
import {
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Download,
  History,
  Search,
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { downloadCsvFile, formatDateTime, toDateObj } from '../../lib/storeDefaults';
import { AuditLog } from '../../types';

const PAGE_SIZE = 10;

export const AdminAuditLogsTab: React.FC<{
  auditLogs: AuditLog[];
}> = ({ auditLogs }) => {
  const { showToast } = useApp();

  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState('ALL');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [sortAsc, setSortAsc] = useState(false);
  const [page, setPage] = useState(1);

  const actionTypes = useMemo(() => {
    const set = new Set<string>();
    auditLogs.forEach((l) => set.add(l.actionType));
    return Array.from(set).sort();
  }, [auditLogs]);

  const filteredLogs = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = auditLogs.filter((log) => {
      if (actionFilter !== 'ALL' && log.actionType !== actionFilter) return false;
      const d = toDateObj(log.createdAt);
      const dayStr = d.toISOString().slice(0, 10);
      if (fromDate && dayStr < fromDate) return false;
      if (toDate && dayStr > toDate) return false;
      if (!q) return true;
      return (
        log.summary.toLowerCase().includes(q) ||
        log.entityLabel.toLowerCase().includes(q) ||
        log.actionType.toLowerCase().includes(q) ||
        log.actorEmail.toLowerCase().includes(q)
      );
    });

    return list.sort((a, b) => {
      const ta = toDateObj(a.createdAt).getTime();
      const tb = toDateObj(b.createdAt).getTime();
      return sortAsc ? ta - tb : tb - ta;
    });
  }, [auditLogs, actionFilter, fromDate, toDate, search, sortAsc]);

  const totalPages = Math.max(1, Math.ceil(filteredLogs.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageItems = filteredLogs.slice(
    (safePage - 1) * PAGE_SIZE,
    safePage * PAGE_SIZE
  );

  const handleExportCsv = () => {
    if (filteredLogs.length === 0) {
      showToast('No audit logs match your current filters.', 'info');
      return;
    }
    const headers = [
      'Timestamp',
      'ActionType',
      'EntityType',
      'EntityLabel',
      'ActorEmail',
      'Summary',
      'FieldDiffs',
    ];
    const rows = filteredLogs.map((l) => [
      formatDateTime(l.createdAt),
      l.actionType,
      l.entityType,
      l.entityLabel,
      l.actorEmail,
      l.summary,
      (l.changes || [])
        .map((c) => `${c.field}: ${c.oldValue} -> ${c.newValue}`)
        .join('; '),
    ]);
    downloadCsvFile(
      `princegoldsocialhub-audit-logs-${new Date().toISOString().slice(0, 10)}.csv`,
      headers,
      rows
    );
    showToast(`Exported ${filteredLogs.length} audit entries.`, 'success');
  };

  return (
    <div className="space-y-5">
      <div className="rounded-3xl bg-white p-5 sm:p-6 shadow-sm border border-gray-100 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-teal-50 text-[#0B4F5B] flex items-center justify-center">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-display font-bold text-lg text-gray-900">
                Admin Audit Trail
              </h2>
              <p className="text-xs text-gray-500">
                Immutable activity record for catalog edits, order status updates, and store settings.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 rounded-xl border border-gray-200 px-3.5 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50"
          >
            <Download className="w-4 h-4" />
            Export to CSV
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Search summary or target..."
              className="w-full rounded-xl border border-gray-200 pl-9 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
            />
          </div>

          <select
            value={actionFilter}
            onChange={(e) => {
              setActionFilter(e.target.value);
              setPage(1);
            }}
            className="rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm"
          >
            <option value="ALL">All Action Types</option>
            {actionTypes.map((at) => (
              <option key={at} value={at}>
                {at}
              </option>
            ))}
          </select>

          <input
            type="date"
            value={fromDate}
            onChange={(e) => {
              setFromDate(e.target.value);
              setPage(1);
            }}
            aria-label="From date"
            className="rounded-xl border border-gray-200 px-3 py-2 text-sm"
          />

          <input
            type="date"
            value={toDate}
            onChange={(e) => {
              setToDate(e.target.value);
              setPage(1);
            }}
            aria-label="To date"
            className="rounded-xl border border-gray-200 px-3 py-2 text-sm"
          />
        </div>
      </div>

      <div className="rounded-3xl bg-white shadow-sm border border-gray-100 overflow-hidden">
        {pageItems.length === 0 ? (
          <div className="p-10 text-center text-sm text-gray-500">
            No audit log entries match the selected filters.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50 text-xs font-semibold text-gray-500 uppercase">
                  <th className="py-3 px-4">
                    <button
                      type="button"
                      onClick={() => setSortAsc(!sortAsc)}
                      className="inline-flex items-center gap-1 hover:text-gray-800"
                    >
                      Time
                      <ArrowUpDown className="w-3.5 h-3.5" />
                    </button>
                  </th>
                  <th className="py-3 px-4">Action</th>
                  <th className="py-3 px-4">Target</th>
                  <th className="py-3 px-4">Summary & Diffs</th>
                  <th className="py-3 px-4">Actor</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {pageItems.map((log) => (
                  <tr key={log.id} className="align-top hover:bg-gray-50/70">
                    <td className="py-3.5 px-4 text-xs text-gray-500 whitespace-nowrap">
                      {formatDateTime(log.createdAt)}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-mono-tabular text-xs font-semibold bg-gray-100 text-gray-800 px-2 py-0.5 rounded">
                        {log.actionType}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-medium text-gray-900 text-xs">
                        {log.entityLabel || log.entityId}
                      </div>
                      <div className="text-[11px] text-gray-400">{log.entityType}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <p className="text-xs text-gray-800 font-medium">{log.summary}</p>
                      {log.changes && log.changes.length > 0 && (
                        <div className="mt-1.5 space-y-1">
                          {log.changes.map((c, idx) => (
                            <div
                              key={`${c.field}-${idx}`}
                              className="text-[11px] font-mono-tabular bg-gray-50 rounded px-2 py-1 text-gray-600"
                            >
                              <span className="font-semibold text-gray-800">{c.field}:</span>{' '}
                              <span className="line-through text-red-600">{c.oldValue}</span>{' '}
                              → <span className="text-emerald-700 font-semibold">{c.newValue}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-gray-600">{log.actorEmail}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-gray-100 px-5 py-3 text-xs text-gray-600">
          <span>
            Showing {(safePage - 1) * PAGE_SIZE + (pageItems.length ? 1 : 0)}–
            {(safePage - 1) * PAGE_SIZE + pageItems.length} of {filteredLogs.length}
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={safePage <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              className="p-1.5 rounded-lg border border-gray-200 disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="tabular-nums font-semibold">
              Page {safePage} / {totalPages}
            </span>
            <button
              type="button"
              disabled={safePage >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              className="p-1.5 rounded-lg border border-gray-200 disabled:opacity-40"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
