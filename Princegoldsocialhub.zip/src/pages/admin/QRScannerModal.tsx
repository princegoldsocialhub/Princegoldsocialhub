import React, { useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import {
  Camera,
  RefreshCw,
  Volume2,
  VolumeX,
  X,
  Search,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { db } from '../../lib/firebase';
import { Product } from '../../types';

interface QRScannerModalProps {
  open: boolean;
  onClose: () => void;
  products: Product[];
  onProductIdentified: (product: Product) => void;
}

export const QRScannerModal: React.FC<QRScannerModalProps> = ({
  open,
  onClose,
  products,
  onProductIdentified,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const startTimeRef = useRef<number>(Date.now());
  const retryCountRef = useRef<number>(0);

  const [cameraError, setCameraError] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState('Initializing camera...');
  const [retryAttempt, setRetryAttempt] = useState(0);
  const [highSensitivity, setHighSensitivity] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(0.5);
  const [manualSku, setManualSku] = useState('');
  const [matchedProduct, setMatchedProduct] = useState<Product | null>(null);

  const playBeep = () => {
    if (muted || volume <= 0) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1046.5, ctx.currentTime);
      gain.gain.setValueAtTime(volume * 0.4, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.16);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.17);
    } catch {
      // ignore Web Audio restriction
    }
  };

  const logDiagnostic = async (errorCode: string, message: string) => {
    try {
      await addDoc(collection(db, 'scan_diagnostics'), {
        errorCode: errorCode.slice(0, 80),
        message: message.slice(0, 300),
        deviceInfo: navigator.userAgent.slice(0, 200),
        createdAt: serverTimestamp(),
      });
    } catch {
      // non-fatal diagnostic write
    }
  };

  const recordScanSuccess = async (product: Product) => {
    const durationMs = Math.max(120, Date.now() - startTimeRef.current);
    const accuracyScore = Math.max(45, Math.min(100, Math.round(100 - durationMs / 160)));
    try {
      await addDoc(collection(db, 'scan_history'), {
        productId: product.id,
        sku: product.sku,
        productTitle: product.title.slice(0, 120),
        durationMs,
        accuracyScore,
        sessionLabel: new Date().toISOString().slice(0, 10),
        createdAt: serverTimestamp(),
      });
    } catch {
      // ignore if write fails
    }
  };

  const handleDecodedText = (rawText: string) => {
    const clean = rawText.trim().toUpperCase();
    const found = products.find(
      (p) => p.sku.toUpperCase() === clean || p.id.toUpperCase() === clean
    );
    if (found) {
      playBeep();
      setMatchedProduct(found);
      setStatusMessage(`Matched ${found.title} (SKU: ${found.sku})`);
      recordScanSuccess(found);
      onProductIdentified(found);
      return true;
    }
    return false;
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  };

  useEffect(() => {
    if (!open) {
      stopCamera();
      return;
    }

    let active = true;
    let timerId: number | null = null;
    setCameraError(null);
    setMatchedProduct(null);
    retryCountRef.current = 0;
    setRetryAttempt(0);
    startTimeRef.current = Date.now();
    setStatusMessage('Point camera at product QR or barcode label...');

    async function start() {
      if (!navigator.mediaDevices?.getUserMedia) {
        const msg = 'Camera API is unavailable in this browser context.';
        setCameraError(msg);
        logDiagnostic('CAMERA_API_UNAVAILABLE', msg);
        return;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        if (!active) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }

        const intervalMs = highSensitivity ? 250 : 550;
        let framesMissed = 0;

        const scanLoop = async () => {
          if (!active || !videoRef.current || !canvasRef.current) return;
          const video = videoRef.current;
          if (video.readyState === video.HAVE_ENOUGH_DATA) {
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth || 640;
            canvas.height = video.videoHeight || 480;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
              const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
              const qrResult = jsQR(imgData.data, imgData.width, imgData.height, {
                inversionAttempts: highSensitivity ? 'attemptBoth' : 'dontInvert',
              });

              if (qrResult?.data) {
                if (handleDecodedText(qrResult.data)) {
                  stopCamera();
                  return;
                }
              }

              // Fallback to BarcodeDetector if supported
              if ('BarcodeDetector' in window) {
                try {
                  const Detector = (window as unknown as {
                    BarcodeDetector: new (opts: { formats: string[] }) => {
                      detect: (el: HTMLVideoElement) => Promise<{ rawValue: string }[]>;
                    };
                  }).BarcodeDetector;
                  const detector = new Detector({ formats: ['qr_code', 'code_128', 'ean_13'] });
                  const barcodes = await detector.detect(video);
                  if (barcodes.length > 0 && barcodes[0].rawValue) {
                    if (handleDecodedText(barcodes[0].rawValue)) {
                      stopCamera();
                      return;
                    }
                  }
                } catch {
                  // ignore unsupported format
                }
              }

              framesMissed += 1;
              const missThreshold = highSensitivity ? 5 : 10;
              if (framesMissed >= missThreshold) {
                framesMissed = 0;
                if (retryCountRef.current < 3) {
                  retryCountRef.current += 1;
                  setRetryAttempt(retryCountRef.current);
                  setStatusMessage(
                    `Low focus or lighting detected — auto-retrying (${retryCountRef.current}/3)...`
                  );
                } else {
                  setStatusMessage(
                    'Unable to detect label clearly after 3 auto-retries. Adjust lighting or enter SKU manually.'
                  );
                }
              }
            }
          }
          if (active) {
            timerId = window.setTimeout(scanLoop, intervalMs);
          }
        };

        timerId = window.setTimeout(scanLoop, intervalMs);
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Camera permission denied.';
        setCameraError(msg);
        logDiagnostic('CAMERA_PERMISSION_OR_HARDWARE_ERROR', msg);
      }
    }

    start();
    return () => {
      active = false;
      if (timerId) clearTimeout(timerId);
      stopCamera();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, highSensitivity]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div className="w-full max-w-lg rounded-3xl bg-white p-5 sm:p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-orange-50 text-[#FF6A00] flex items-center justify-center">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">QR &amp; Barcode Scanner</h3>
              <p className="text-xs text-slate-500">Scan product label to inspect stock &amp; details</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Camera Viewport */}
        <div className="relative rounded-2xl overflow-hidden bg-slate-900 aspect-video flex items-center justify-center">
          {cameraError ? (
            <div className="p-6 text-center text-white space-y-2">
              <AlertTriangle className="w-8 h-8 text-[#FF6A00] mx-auto" />
              <div className="text-sm font-semibold">Camera Access Unavailable</div>
              <p className="text-xs text-slate-300">{cameraError}</p>
            </div>
          ) : (
            <>
              <video ref={videoRef} className="w-full h-full object-cover" muted playsInline />
              <div className="absolute inset-8 border-2 border-[#FF6A00]/80 rounded-2xl pointer-events-none" />
            </>
          )}
          <canvas ref={canvasRef} className="hidden" />
        </div>

        <div className="flex items-center justify-between text-xs bg-slate-50 px-3.5 py-2.5 rounded-xl">
          <span className="text-slate-700 font-medium">{statusMessage}</span>
          {retryAttempt > 0 && (
            <span className="inline-flex items-center gap-1 text-[#FF6A00] font-semibold">
              <RefreshCw className="w-3 h-3" /> {retryAttempt}/3
            </span>
          )}
        </div>

        {matchedProduct && (
          <div className="rounded-2xl bg-emerald-50 border border-emerald-200 p-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs text-emerald-900">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <strong>{matchedProduct.title}</strong> ({matchedProduct.sku}) · Stock:{' '}
                <strong>{matchedProduct.stock}</strong>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1 rounded-lg bg-emerald-700 text-white text-xs font-semibold"
            >
              Done
            </button>
          </div>
        )}

        {/* Scanner Audio & Sensitivity Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-2 bg-slate-50 px-3 py-2 rounded-xl">
            <button
              type="button"
              onClick={() => setMuted((m) => !m)}
              className="p-1 rounded-lg hover:bg-slate-200 text-slate-700"
              aria-label={muted ? 'Unmute beep' : 'Mute beep'}
            >
              {muted ? <VolumeX className="w-4 h-4 text-red-500" /> : <Volume2 className="w-4 h-4 text-[#0B4F5B]" />}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.1}
              disabled={muted}
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              className="flex-1 accent-[#FF6A00]"
            />
            <span className="tabular-nums text-slate-500 w-8 text-right">
              {muted ? 'Off' : `${Math.round(volume * 100)}%`}
            </span>
          </div>

          <button
            type="button"
            onClick={() => setHighSensitivity((s) => !s)}
            className={`px-3 py-2 rounded-xl border font-semibold text-left flex items-center justify-between ${
              highSensitivity
                ? 'border-[#FF6A00] bg-orange-50 text-[#FF6A00]'
                : 'border-slate-200 text-slate-700'
            }`}
          >
            <span>Low-Light Auto-Retry</span>
            <span>{highSensitivity ? 'High' : 'Normal'}</span>
          </button>
        </div>

        {/* Manual SKU Lookup Fallback */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!handleDecodedText(manualSku)) {
              setStatusMessage(`No product found matching SKU "${manualSku}".`);
            }
          }}
          className="flex items-center gap-2"
        >
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={manualSku}
              onChange={(e) => setManualSku(e.target.value.toUpperCase())}
              placeholder="Or enter SKU manually to test..."
              className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-200 text-xs font-mono-tabular uppercase"
            />
          </div>
          <button
            type="submit"
            className="px-3.5 py-2 rounded-xl bg-[#0B4F5B] text-white text-xs font-semibold"
          >
            Lookup
          </button>
        </form>
      </div>
    </div>
  );
};
