import React, { useEffect, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  serverTimestamp,
  setDoc,
} from 'firebase/firestore';
import {
  Bell,
  FileText,
  HelpCircle,
  Mail,
  Plus,
  Printer,
  Send,
  Settings,
  Trash2,
  Upload,
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { auth, db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { computeFieldDiffs, logAuditEvent } from '../../lib/audit';
import { StoreConfig } from '../../types';

async function fileToResizedDataUrl(file: File, maxDim = 480): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read file'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image file'));
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(String(reader.result));
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/png', 0.85));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

export const AdminSettingsTab: React.FC = () => {
  const { storeConfig, faqs, policies, showToast } = useApp();

  const [form, setForm] = useState<StoreConfig>(storeConfig);
  const [savingConfig, setSavingConfig] = useState(false);
  const [sendingTestEmail, setSendingTestEmail] = useState(false);

  // FAQ form
  const [newFaqQ, setNewFaqQ] = useState('');
  const [newFaqA, setNewFaqA] = useState('');

  // Policy form
  const [newPolicyTitle, setNewPolicyTitle] = useState('');
  const [newPolicyContent, setNewPolicyContent] = useState('');

  useEffect(() => {
    setForm(storeConfig);
  }, [storeConfig]);

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingConfig(true);
    try {
      const payload = {
        storeName: (form.storeName || 'Princegoldsocialhub').trim().slice(0, 80),
        logoUrl: (form.logoUrl || '').slice(0, 240000),
        welcomeTitle: (form.welcomeTitle || '').trim().slice(0, 140),
        welcomeSubtitle: (form.welcomeSubtitle || '').trim().slice(0, 400),
        trustBannerText: (form.trustBannerText || '').trim().slice(0, 240),
        announcementEnabled: Boolean(form.announcementEnabled),
        announcementText: (form.announcementText || '').trim().slice(0, 280),
        announcementVersion: (form.announcementVersion || 'v1').trim().slice(0, 40),
        currencyCode: (form.currencyCode || 'NGN').trim().slice(0, 10),
        currencySymbol: (form.currencySymbol || '₦').trim().slice(0, 8),
        supportEmail: (form.supportEmail || '').trim().slice(0, 120),
        supportPhone: (form.supportPhone || '').trim().slice(0, 40),
        supportWhatsapp: (form.supportWhatsapp || '').trim().slice(0, 120),
        lowStockThreshold: Math.min(10000, Math.max(0, Number(form.lowStockThreshold || 0))),
        lowStockEmailEnabled: Boolean(form.lowStockEmailEnabled),
        lowStockAlertEmail: (form.lowStockAlertEmail || '').trim().slice(0, 120),
        lowStockEmailSubject: (form.lowStockEmailSubject || '').trim().slice(0, 160),
        lowStockEmailBody: (form.lowStockEmailBody || '').trim().slice(0, 2000),
        packingSlipLogoUrl: (form.packingSlipLogoUrl || '').slice(0, 240000),
        packingSlipHeaderAddress: (form.packingSlipHeaderAddress || '').trim().slice(0, 400),
        packingSlipFooterText: (form.packingSlipFooterText || '').trim().slice(0, 400),
        updatedAt: serverTimestamp(),
      };

      await setDoc(doc(db, 'store_config', 'main'), payload);

      const diffs = computeFieldDiffs(
        storeConfig as unknown as Record<string, unknown>,
        payload as unknown as Record<string, unknown>,
        [
          'storeName',
          'welcomeTitle',
          'announcementEnabled',
          'announcementVersion',
          'currencyCode',
          'lowStockThreshold',
          'lowStockEmailEnabled',
        ]
      );
      await logAuditEvent({
        actionType: 'settings_update',
        entityType: 'store_config',
        entityId: 'main',
        entityLabel: payload.storeName,
        changes: diffs,
        summary: 'Updated storefront, email template, and packing slip settings',
      });

      showToast('Store settings saved.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'store_config/main');
    } finally {
      setSavingConfig(false);
    }
  };

  const handleUploadImage = async (
    file: File | undefined,
    field: 'logoUrl' | 'packingSlipLogoUrl'
  ) => {
    if (!file) return;
    try {
      const dataUrl = await fileToResizedDataUrl(file, 360);
      if (dataUrl.length > 240000) {
        showToast('Image is too large even after compression. Choose a smaller PNG/JPG.', 'error');
        return;
      }
      setForm((prev) => ({ ...prev, [field]: dataUrl }));
      showToast('Logo ready. Click Save All Settings to publish.', 'info');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed to process logo.', 'error');
    }
  };

  const renderedEmailSubject = (form.lowStockEmailSubject || '')
    .replace(/\{\{sku\}\}/g, 'SM-GROWTH-01')
    .replace(/\{\{title\}\}/g, 'Instagram Brand Content Pack')
    .replace(/\{\{stock\}\}/g, '2')
    .replace(/\{\{threshold\}\}/g, String(form.lowStockThreshold));

  const renderedEmailBody = (form.lowStockEmailBody || '')
    .replace(/\{\{sku\}\}/g, 'SM-GROWTH-01')
    .replace(/\{\{title\}\}/g, 'Instagram Brand Content Pack')
    .replace(/\{\{stock\}\}/g, '2')
    .replace(/\{\{threshold\}\}/g, String(form.lowStockThreshold));

  const handleSendTestEmail = async () => {
    if (!form.lowStockAlertEmail.trim()) {
      showToast('Enter a recipient alert email address first.', 'error');
      return;
    }
    setSendingTestEmail(true);
    try {
      const idToken = await auth.currentUser?.getIdToken();
      const resp = await fetch('/api/admin/send-test-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`,
        },
        body: JSON.stringify({
          toEmail: form.lowStockAlertEmail.trim(),
          subject: renderedEmailSubject,
          body: renderedEmailBody,
          threshold: form.lowStockThreshold,
        }),
      });
      const data = (await resp.json()) as { sent?: boolean; message?: string; error?: string };
      if (!resp.ok || !data.sent) {
        showToast(data.error || 'Failed to send test email.', 'error');
        return;
      }
      showToast(data.message || 'Test email dispatched.', 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Network error.', 'error');
    } finally {
      setSendingTestEmail(false);
    }
  };

  const handleAddFaq = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFaqQ.trim() || !newFaqA.trim()) return;
    try {
      const ref = doc(collection(db, 'faqs'));
      const maxOrder = faqs.reduce((m, f) => Math.max(m, f.sortOrder), 0);
      await setDoc(ref, {
        question: newFaqQ.trim().slice(0, 240),
        answer: newFaqA.trim().slice(0, 1500),
        sortOrder: maxOrder + 1,
      });
      await logAuditEvent({
        actionType: 'faq_create',
        entityType: 'faq',
        entityId: ref.id,
        entityLabel: newFaqQ.trim().slice(0, 80),
        summary: 'Added storefront FAQ item',
      });
      setNewFaqQ('');
      setNewFaqA('');
      showToast('FAQ added.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'faqs');
    }
  };

  const handleDeleteFaq = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'faqs', id));
      showToast('FAQ deleted.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `faqs/${id}`);
    }
  };

  const handleAddPolicy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPolicyTitle.trim() || !newPolicyContent.trim()) return;
    try {
      const ref = doc(collection(db, 'policies'));
      const maxOrder = policies.reduce((m, p) => Math.max(m, p.sortOrder), 0);
      await setDoc(ref, {
        title: newPolicyTitle.trim().slice(0, 120),
        content: newPolicyContent.trim().slice(0, 5000),
        sortOrder: maxOrder + 1,
      });
      await logAuditEvent({
        actionType: 'policy_create',
        entityType: 'policy',
        entityId: ref.id,
        entityLabel: newPolicyTitle.trim().slice(0, 80),
        summary: 'Added storefront policy item',
      });
      setNewPolicyTitle('');
      setNewPolicyContent('');
      showToast('Policy added.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'policies');
    }
  };

  const handleDeletePolicy = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'policies', id));
      showToast('Policy deleted.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `policies/${id}`);
    }
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSaveConfig} className="space-y-6">
        {/* Storefront Identity & Announcement Banner */}
        <div className="rounded-3xl bg-white p-5 sm:p-6 shadow-sm border border-gray-100 space-y-5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#FF6A00] flex items-center justify-center">
                <Settings className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-display font-bold text-lg text-gray-900">
                  Storefront Content & Branding
                </h2>
                <p className="text-xs text-gray-500">
                  Edit homepage welcome copy, currency, support links, and site-wide announcement banner.
                </p>
              </div>
            </div>
            <button
              type="submit"
              disabled={savingConfig}
              className="rounded-xl bg-[#FF6A00] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#e85f00] disabled:opacity-50"
            >
              {savingConfig ? 'Saving...' : 'Save All Settings'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Store Name</label>
              <input
                type="text"
                value={form.storeName}
                onChange={(e) => setForm({ ...form, storeName: e.target.value })}
                className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Header Logo Upload
              </label>
              <div className="flex items-center gap-3">
                <label className="inline-flex items-center gap-1.5 rounded-xl border border-gray-200 px-3 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 cursor-pointer">
                  <Upload className="w-4 h-4" />
                  Upload Logo
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleUploadImage(e.target.files?.[0], 'logoUrl')}
                  />
                </label>
                {form.logoUrl && (
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, logoUrl: '' })}
                    className="text-xs text-red-600 font-semibold"
                  >
                    Reset to Brand Mark
                  </button>
                )}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Homepage Welcome Title
              </label>
              <input
                type="text"
                value={form.welcomeTitle}
                onChange={(e) => setForm({ ...form, welcomeTitle: e.target.value })}
                className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Trust Banner Text
              </label>
              <input
                type="text"
                value={form.trustBannerText}
                onChange={(e) => setForm({ ...form, trustBannerText: e.target.value })}
                className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Homepage Welcome Subtitle
              </label>
              <textarea
                rows={2}
                value={form.welcomeSubtitle}
                onChange={(e) => setForm({ ...form, welcomeSubtitle: e.target.value })}
                className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Currency Code
                </label>
                <input
                  type="text"
                  value={form.currencyCode}
                  onChange={(e) => setForm({ ...form, currencyCode: e.target.value.toUpperCase() })}
                  className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm font-mono-tabular focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Currency Symbol
                </label>
                <input
                  type="text"
                  value={form.currencySymbol}
                  onChange={(e) => setForm({ ...form, currencySymbol: e.target.value })}
                  className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Support Email
                </label>
                <input
                  type="email"
                  value={form.supportEmail}
                  onChange={(e) => setForm({ ...form, supportEmail: e.target.value })}
                  className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Support Phone
                </label>
                <input
                  type="text"
                  value={form.supportPhone}
                  onChange={(e) => setForm({ ...form, supportPhone: e.target.value })}
                  className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  WhatsApp Link
                </label>
                <input
                  type="text"
                  value={form.supportWhatsapp}
                  onChange={(e) => setForm({ ...form, supportWhatsapp: e.target.value })}
                  className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                />
              </div>
            </div>
          </div>

          {/* Announcement Banner Settings */}
          <div className="rounded-2xl bg-orange-50/60 border border-orange-100 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-[#FF6A00]" />
                <span className="font-semibold text-sm text-gray-900">
                  Site-Wide Dismissible Announcement Banner
                </span>
              </div>
              <label className="inline-flex items-center gap-2 text-xs font-semibold text-gray-700">
                <input
                  type="checkbox"
                  checked={form.announcementEnabled}
                  onChange={(e) =>
                    setForm({ ...form, announcementEnabled: e.target.checked })
                  }
                  className="rounded border-gray-300 text-[#FF6A00] focus:ring-[#FF6A00]"
                />
                Show Announcement on Home
              </label>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div className="sm:col-span-3">
                <input
                  type="text"
                  value={form.announcementText}
                  onChange={(e) => setForm({ ...form, announcementText: e.target.value })}
                  placeholder="Announcement banner message..."
                  className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                />
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={form.announcementVersion}
                  onChange={(e) => setForm({ ...form, announcementVersion: e.target.value })}
                  placeholder="v1"
                  className="w-20 rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm font-mono-tabular"
                />
                <button
                  type="button"
                  onClick={() =>
                    setForm({ ...form, announcementVersion: `v-${Date.now().toString().slice(-4)}` })
                  }
                  className="flex-1 rounded-xl border border-orange-300 bg-white px-2.5 py-2 text-xs font-semibold text-orange-800 hover:bg-orange-50"
                >
                  Re-Show All
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Low Stock & Manage Email Templates */}
        <div className="rounded-3xl bg-white p-5 sm:p-6 shadow-sm border border-gray-100 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-teal-50 text-[#0B4F5B] flex items-center justify-center">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-display font-bold text-lg text-gray-900">
                  Low-Stock Alerts & Manage Email Templates
                </h2>
                <p className="text-xs text-gray-500">
                  Configure global threshold, toggle email alerts, customize templates, and preview output.
                </p>
              </div>
            </div>
            <button
              type="button"
              disabled={sendingTestEmail}
              onClick={handleSendTestEmail}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[#0B4F5B] px-4 py-2 text-xs font-semibold text-white hover:bg-[#093e48] disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              {sendingTestEmail ? 'Sending...' : 'Send Test Email'}
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Low-Stock Threshold (Units)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={10000}
                    value={form.lowStockThreshold}
                    onChange={(e) =>
                      setForm({ ...form, lowStockThreshold: Number(e.target.value) })
                    }
                    className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Alert Recipient Email
                  </label>
                  <input
                    type="email"
                    value={form.lowStockAlertEmail}
                    onChange={(e) =>
                      setForm({ ...form, lowStockAlertEmail: e.target.value })
                    }
                    className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm"
                  />
                </div>
              </div>

              <label className="inline-flex items-center gap-2 text-sm font-medium text-gray-700">
                <input
                  type="checkbox"
                  checked={form.lowStockEmailEnabled}
                  onChange={(e) =>
                    setForm({ ...form, lowStockEmailEnabled: e.target.checked })
                  }
                  className="rounded border-gray-300 text-[#FF6A00] focus:ring-[#FF6A00]"
                />
                Enable Automated Low-Stock Email Alerts
              </label>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Email Subject Template (variables: {'{{sku}}'}, {'{{title}}'}, {'{{stock}}'}, {'{{threshold}}'})
                </label>
                <input
                  type="text"
                  value={form.lowStockEmailSubject}
                  onChange={(e) =>
                    setForm({ ...form, lowStockEmailSubject: e.target.value })
                  }
                  className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Email Body Template
                </label>
                <textarea
                  rows={5}
                  value={form.lowStockEmailBody}
                  onChange={(e) =>
                    setForm({ ...form, lowStockEmailBody: e.target.value })
                  }
                  className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm font-mono-tabular"
                />
              </div>
            </div>

            {/* Live Email Preview Window */}
            <div className="rounded-2xl border border-gray-200 bg-gray-50 overflow-hidden flex flex-col">
              <div className="px-4 py-2.5 bg-gray-100 border-b border-gray-200 flex items-center justify-between">
                <span className="text-xs font-semibold text-gray-700">
                  Live Email Preview Window
                </span>
                <span
                  className={`text-[11px] font-semibold px-2 py-0.5 rounded ${
                    form.lowStockEmailEnabled
                      ? 'bg-emerald-50 text-emerald-700'
                      : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  {form.lowStockEmailEnabled ? 'Alerts Active' : 'Alerts Paused'}
                </span>
              </div>
              <div className="p-4 space-y-3 text-sm bg-white flex-1">
                <div className="text-xs text-gray-500 space-y-0.5 border-b border-gray-100 pb-3">
                  <div>
                    <strong className="text-gray-700">To:</strong>{' '}
                    {form.lowStockAlertEmail || 'tomisin582@gmail.com'}
                  </div>
                  <div>
                    <strong className="text-gray-700">Subject:</strong>{' '}
                    <span className="text-gray-900 font-medium">{renderedEmailSubject}</span>
                  </div>
                </div>
                <pre className="whitespace-pre-wrap font-sans text-sm text-gray-700 leading-relaxed">
                  {renderedEmailBody}
                </pre>
              </div>
            </div>
          </div>
        </div>

        {/* Packing Slip Settings & Live Preview Mode */}
        <div className="rounded-3xl bg-white p-5 sm:p-6 shadow-sm border border-gray-100 space-y-5">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#FF6A00] flex items-center justify-center">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-display font-bold text-lg text-gray-900">
                Packing Slip Settings & Live Preview Mode
              </h2>
              <p className="text-xs text-gray-500">
                Customize the PDF packing slip logo, header business address, and footer message.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Packing Slip Custom Logo
                </label>
                <div className="flex items-center gap-3">
                  <label className="inline-flex items-center gap-1.5 rounded-xl border border-gray-200 px-3 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 cursor-pointer">
                    <Upload className="w-4 h-4" />
                    Upload Packing Slip Logo
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) =>
                        handleUploadImage(e.target.files?.[0], 'packingSlipLogoUrl')
                      }
                    />
                  </label>
                  {form.packingSlipLogoUrl && (
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, packingSlipLogoUrl: '' })}
                      className="text-xs text-red-600 font-semibold"
                    >
                      Remove Logo
                    </button>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Header Business Address
                </label>
                <textarea
                  rows={3}
                  value={form.packingSlipHeaderAddress}
                  onChange={(e) =>
                    setForm({ ...form, packingSlipHeaderAddress: e.target.value })
                  }
                  className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Footer Message
                </label>
                <textarea
                  rows={2}
                  value={form.packingSlipFooterText}
                  onChange={(e) =>
                    setForm({ ...form, packingSlipFooterText: e.target.value })
                  }
                  className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm"
                />
              </div>
            </div>

            {/* Live Packing Slip Preview */}
            <div className="rounded-2xl border border-gray-200 bg-gray-50 p-4">
              <div className="text-[11px] font-semibold text-gray-500 uppercase mb-2">
                Live Packing Slip Preview
              </div>
              <div className="rounded-xl bg-white border border-gray-200 p-5 space-y-4 shadow-sm">
                <div className="flex items-start justify-between gap-3 border-b border-gray-200 pb-3">
                  <div className="flex items-start gap-3">
                    {form.packingSlipLogoUrl ? (
                      <img
                        src={form.packingSlipLogoUrl}
                        alt="Packing slip logo"
                        className="h-10 w-auto object-contain rounded"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-lg bg-[#FF6A00] text-white font-display font-bold flex items-center justify-center text-sm">
                        PG
                      </div>
                    )}
                    <div>
                      <p className="font-display font-bold text-sm text-gray-900">
                        {form.storeName}
                      </p>
                      <p className="text-[11px] text-gray-500 whitespace-pre-line">
                        {form.packingSlipHeaderAddress}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-[#FF6A00]">PACKING SLIP</span>
                </div>

                <div className="text-xs text-gray-600 flex justify-between">
                  <span>Order ID: PGH-SAMPLE-001</span>
                  <span>Currency: {form.currencyCode}</span>
                </div>

                <div className="rounded-lg bg-gray-50 p-2.5 text-[11px] text-gray-600 flex justify-between font-medium">
                  <span>SKU-SAMPLE · Service / Item</span>
                  <span>Qty: 1</span>
                </div>

                <p className="text-[11px] text-gray-500 border-t border-gray-100 pt-2">
                  {form.packingSlipFooterText}
                </p>
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={savingConfig}
              className="rounded-xl bg-[#FF6A00] px-6 py-2.5 text-sm font-semibold text-white hover:bg-[#e85f00] disabled:opacity-50"
            >
              {savingConfig ? 'Saving...' : 'Save All Settings'}
            </button>
          </div>
        </div>
      </form>

      {/* Editable FAQs & Policies */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* FAQs */}
        <div className="rounded-3xl bg-white p-5 sm:p-6 shadow-sm border border-gray-100 space-y-4">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-[#FF6A00]" />
            <h3 className="font-display font-bold text-base text-gray-900">
              Manage Customer FAQs
            </h3>
          </div>
          <form onSubmit={handleAddFaq} className="space-y-2.5 p-3.5 rounded-2xl bg-gray-50 border border-gray-200">
            <input
              type="text"
              value={newFaqQ}
              onChange={(e) => setNewFaqQ(e.target.value)}
              placeholder="FAQ Question..."
              required
              className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm"
            />
            <textarea
              rows={2}
              value={newFaqA}
              onChange={(e) => setNewFaqA(e.target.value)}
              placeholder="Answer..."
              required
              className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm"
            />
            <button
              type="submit"
              className="inline-flex items-center gap-1 rounded-xl bg-[#0B4F5B] px-3.5 py-2 text-xs font-semibold text-white"
            >
              <Plus className="w-3.5 h-3.5" />
              Add FAQ
            </button>
          </form>

          <div className="divide-y divide-gray-100">
            {faqs.map((faq) => (
              <div key={faq.id} className="py-3 flex items-start justify-between gap-2">
                <div>
                  <p className="text-sm font-semibold text-gray-900">{faq.question}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{faq.answer}</p>
                </div>
                <button
                  type="button"
                  onClick={() => handleDeleteFaq(faq.id)}
                  className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Policies */}
        <div className="rounded-3xl bg-white p-5 sm:p-6 shadow-sm border border-gray-100 space-y-4">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#0B4F5B]" />
            <h3 className="font-display font-bold text-base text-gray-900">
              Manage Store Policies
            </h3>
          </div>
          <form onSubmit={handleAddPolicy} className="space-y-2.5 p-3.5 rounded-2xl bg-gray-50 border border-gray-200">
            <input
              type="text"
              value={newPolicyTitle}
              onChange={(e) => setNewPolicyTitle(e.target.value)}
              placeholder="Policy Title..."
              required
              className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm"
            />
            <textarea
              rows={2}
              value={newPolicyContent}
              onChange={(e) => setNewPolicyContent(e.target.value)}
              placeholder="Policy Content..."
              required
              className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm"
            />
            <button
              type="submit"
              className="inline-flex items-center gap-1 rounded-xl bg-[#0B4F5B] px-3.5 py-2 text-xs font-semibold text-white"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Policy
            </button>
          </form>

          <div className="divide-y divide-gray-100">
            {policies.map((pol) => (
              <div key={pol.id} className="py-3 flex items-start justify-between gap-2">
                <div>
                  <p className="text-sm font-semibold text-gray-900">{pol.title}</p>
                  <p className="text-xs text-gray-500 mt-0.5 line-clamp-3">{pol.content}</p>
                </div>
                <button
                  type="button"
                  onClick={() => handleDeletePolicy(pol.id)}
                  className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
