import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  CreditCard,
  RefreshCw,
  ShieldCheck,
  Webhook,
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { auth } from '../../lib/firebase';
import { formatCurrency, formatDateTime } from '../../lib/storeDefaults';

interface WebhookEventRecord {
  id: string;
  provider: 'paystack' | 'flutterwave';
  event: string;
  reference: string;
  amount: number;
  currency: string;
  status: string;
  verifiedSignature: boolean;
  receivedAt: string;
}

export const AdminPaymentsTab: React.FC = () => {
  const {
    allPayments,
    paymentGatewayStatus,
    refreshPaymentStatus,
    storeConfig,
    showToast,
  } = useApp();

  const [webhookEvents, setWebhookEvents] = useState<WebhookEventRecord[]>([]);
  const [loadingWebhooks, setLoadingWebhooks] = useState(false);

  const loadWebhooks = async () => {
    setLoadingWebhooks(true);
    try {
      const idToken = await auth.currentUser?.getIdToken();
      if (!idToken) return;
      const resp = await fetch('/api/admin/webhook-events', {
        headers: { Authorization: `Bearer ${idToken}` },
      });
      if (resp.ok) {
        const data = (await resp.json()) as { events?: WebhookEventRecord[] };
        setWebhookEvents(data.events || []);
      }
    } catch {
      // ignore network error
    } finally {
      setLoadingWebhooks(false);
    }
  };

  useEffect(() => {
    loadWebhooks();
  }, []);

  const handleRefreshAll = async () => {
    await refreshPaymentStatus();
    await loadWebhooks();
    showToast('Gateway status & webhook feed refreshed.', 'info');
  };

  const webhookUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/api/payments/webhook`
      : '/api/payments/webhook';

  return (
    <div className="space-y-6">
      {/* Gateway Configuration Cards */}
      <div className="rounded-3xl bg-white p-5 sm:p-6 shadow-sm border border-gray-100">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#FF6A00] flex items-center justify-center">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-display font-bold text-lg text-gray-900">
                Payment Gateway Integration Status
              </h2>
              <p className="text-xs text-gray-500">
                Server-side keys remain strictly in environment secrets and are never exposed in the browser.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleRefreshAll}
            className="inline-flex items-center gap-1.5 rounded-xl border border-gray-200 px-3.5 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh Status
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="rounded-2xl border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-gray-900">Paystack</span>
              {paymentGatewayStatus.paystackConfigured ? (
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-md">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {paymentGatewayStatus.paystackMode.toUpperCase()}
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-md">
                  <AlertCircle className="w-3.5 h-3.5" />
                  Test Fallback
                </span>
              )}
            </div>
            <p className="text-xs text-gray-500">
              {paymentGatewayStatus.paystackConfigured
                ? 'PAYSTACK_SECRET_KEY detected on server. Checkout redirects to Paystack hosted payment page.'
                : 'Set PAYSTACK_SECRET_KEY and PAYSTACK_WEBHOOK_SECRET in server environment secrets to activate Paystack.'}
            </p>
          </div>

          <div className="rounded-2xl border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-gray-900">Flutterwave</span>
              {paymentGatewayStatus.flutterwaveConfigured ? (
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-md">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {paymentGatewayStatus.flutterwaveMode.toUpperCase()}
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-md">
                  <AlertCircle className="w-3.5 h-3.5" />
                  Test Fallback
                </span>
              )}
            </div>
            <p className="text-xs text-gray-500">
              {paymentGatewayStatus.flutterwaveConfigured
                ? 'FLUTTERWAVE_SECRET_KEY detected on server. Checkout redirects to Flutterwave hosted payment page.'
                : 'Set FLUTTERWAVE_SECRET_KEY and FLUTTERWAVE_WEBHOOK_HASH in server environment secrets to activate Flutterwave.'}
            </p>
          </div>

          <div className="rounded-2xl border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-gray-900">Email Transport</span>
              {paymentGatewayStatus.emailTransportConfigured ? (
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-md">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  LIVE
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-gray-600 bg-gray-100 px-2.5 py-0.5 rounded-md">
                  Simulated
                </span>
              )}
            </div>
            <p className="text-xs text-gray-500">
              {paymentGatewayStatus.emailTransportConfigured
                ? 'RESEND_API_KEY configured for live low-stock email delivery.'
                : 'Configure RESEND_API_KEY in server secrets for live email alerts.'}
            </p>
          </div>
        </div>

        <div className="rounded-2xl bg-gray-50 border border-gray-200 p-4 text-xs text-gray-700 space-y-1.5">
          <p className="font-semibold text-gray-900 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-[#0B4F5B]" />
            Webhook Endpoint for Paystack & Flutterwave
          </p>
          <p className="font-mono-tabular bg-white px-3 py-2 rounded-lg border border-gray-200 break-all text-gray-800">
            {webhookUrl}
          </p>
          <p className="text-gray-500">
            Incoming Paystack HMAC-SHA512 signatures (<code className="font-mono-tabular">x-paystack-signature</code>) and Flutterwave verification hashes (<code className="font-mono-tabular">verif-hash</code>) are validated before logging.
          </p>
        </div>
      </div>

      {/* Verified Webhook Events Feed */}
      <div className="rounded-3xl bg-white p-5 sm:p-6 shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 mb-4">
          <Webhook className="w-5 h-5 text-[#0B4F5B]" />
          <h3 className="font-display font-bold text-base text-gray-900">
            Recent Verified Webhook Events
          </h3>
        </div>
        {loadingWebhooks ? (
          <p className="text-xs text-gray-500">Loading webhook log...</p>
        ) : webhookEvents.length === 0 ? (
          <p className="text-xs text-gray-500 py-4">
            No signed webhook deliveries recorded in this server session yet.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-gray-100 text-gray-500 uppercase">
                  <th className="py-2 pr-3">Provider</th>
                  <th className="py-2 pr-3">Event</th>
                  <th className="py-2 pr-3">Reference</th>
                  <th className="py-2 pr-3">Amount</th>
                  <th className="py-2 pr-3">Status</th>
                  <th className="py-2">Received</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {webhookEvents.map((ev) => (
                  <tr key={ev.id}>
                    <td className="py-2.5 pr-3 font-semibold uppercase">{ev.provider}</td>
                    <td className="py-2.5 pr-3">{ev.event}</td>
                    <td className="py-2.5 pr-3 font-mono-tabular">{ev.reference || '—'}</td>
                    <td className="py-2.5 pr-3 tabular-nums">
                      {ev.currency} {ev.amount.toFixed(2)}
                    </td>
                    <td className="py-2.5 pr-3">
                      <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-semibold">
                        {ev.status}
                      </span>
                    </td>
                    <td className="py-2.5 text-gray-500">{formatDateTime(ev.receivedAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Payment Ledger */}
      <div className="rounded-3xl bg-white p-5 sm:p-6 shadow-sm border border-gray-100">
        <h3 className="font-display font-bold text-base text-gray-900 mb-4">
          Customer Payment Records ({allPayments.length})
        </h3>
        {allPayments.length === 0 ? (
          <p className="text-sm text-gray-500 py-6 text-center">
            No payment records yet. Records appear automatically when customers complete checkout.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="border-b border-gray-100 text-xs text-gray-500 uppercase">
                  <th className="py-2.5 pr-3">Order ID</th>
                  <th className="py-2.5 pr-3">Provider</th>
                  <th className="py-2.5 pr-3">Reference</th>
                  <th className="py-2.5 pr-3">Amount</th>
                  <th className="py-2.5 pr-3">Status</th>
                  <th className="py-2.5">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {allPayments.map((p) => (
                  <tr key={p.id}>
                    <td className="py-3 pr-3 font-mono-tabular font-semibold text-gray-900">
                      {p.orderNumber}
                    </td>
                    <td className="py-3 pr-3 uppercase text-xs font-semibold text-gray-600">
                      {p.provider.replace('_', ' ')}
                    </td>
                    <td className="py-3 pr-3 font-mono-tabular text-xs text-gray-600">
                      {p.reference}
                    </td>
                    <td className="py-3 pr-3 font-semibold tabular-nums">
                      {formatCurrency(p.amount, storeConfig.currencySymbol)}
                    </td>
                    <td className="py-3 pr-3">
                      <span
                        className={`text-xs font-semibold px-2 py-0.5 rounded-md ${
                          p.status === 'verified'
                            ? 'bg-emerald-50 text-emerald-700'
                            : p.status === 'failed'
                            ? 'bg-red-50 text-red-700'
                            : 'bg-amber-50 text-amber-700'
                        }`}
                      >
                        {p.status}
                        {p.verifiedServerSide ? ' (server)' : ''}
                      </span>
                    </td>
                    <td className="py-3 text-xs text-gray-500">
                      {formatDateTime(p.createdAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
