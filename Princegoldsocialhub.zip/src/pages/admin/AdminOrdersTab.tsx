import React, { useEffect, useMemo, useState } from 'react';
import { jsPDF } from 'jspdf';
import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import {
  CheckSquare,
  Download,
  Eye,
  Package,
  Printer,
  Search,
  ShieldCheck,
  Square,
  Truck,
  X,
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { auth, db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { createOrderStatusNotification, logAuditEvent } from '../../lib/audit';
import {
  calculateEstimatedDeliveryDate,
  downloadCsvFile,
  formatCurrency,
  formatDateTime,
} from '../../lib/storeDefaults';
import { Order, OrderStatus, PaymentStatus } from '../../types';

const ALL_STATUSES: OrderStatus[] = [
  'Awaiting Payment',
  'Paid',
  'Processing',
  'Shipped',
  'Completed',
  'Cancelled',
  'Refunded',
];

export const AdminOrdersTab: React.FC<{
  initialFilterPending?: boolean;
}> = ({ initialFilterPending = false }) => {
  const { allOrders, storeConfig, showToast } = useApp();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>(
    initialFilterPending ? 'PENDING_GROUP' : 'ALL'
  );
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [inspectOrder, setInspectOrder] = useState<Order | null>(null);

  // Edit single order modal fields
  const [nextStatus, setNextStatus] = useState<OrderStatus>('Processing');
  const [nextPaymentStatus, setNextPaymentStatus] = useState<PaymentStatus>('unpaid');
  const [trackingNumber, setTrackingNumber] = useState('');
  const [statusNote, setStatusNote] = useState('');
  const [savingOrder, setSavingOrder] = useState(false);
  const [verifyingPayment, setVerifyingPayment] = useState(false);
  const [batchUpdating, setBatchUpdating] = useState(false);

  useEffect(() => {
    if (initialFilterPending) {
      setStatusFilter('PENDING_GROUP');
    }
  }, [initialFilterPending]);

  const filteredOrders = useMemo(() => {
    const q = search.trim().toLowerCase();
    return allOrders.filter((o) => {
      if (statusFilter === 'PENDING_GROUP') {
        if (!['Awaiting Payment', 'Paid', 'Processing'].includes(o.status)) return false;
      } else if (statusFilter !== 'ALL' && o.status !== statusFilter) {
        return false;
      }
      if (!q) return true;
      return (
        o.orderNumber.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.customerEmail.toLowerCase().includes(q) ||
        (o.paymentReference || '').toLowerCase().includes(q)
      );
    });
  }, [allOrders, search, statusFilter]);

  const openInspectModal = (order: Order) => {
    setInspectOrder(order);
    setNextStatus(order.status);
    setNextPaymentStatus(order.paymentStatus);
    setTrackingNumber(order.trackingNumber || '');
    setStatusNote('');
  };

  const toggleSelectOrder = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredOrders.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredOrders.map((o) => o.id));
    }
  };

  const buildSanitizedOrderPayload = (
    order: Order,
    updates: {
      status: OrderStatus;
      paymentStatus: PaymentStatus;
      trackingNumber: string;
      note: string;
    }
  ) => {
    const estDate = calculateEstimatedDeliveryDate(
      order.createdAt,
      updates.status,
      order.hasPhysicalItems
    );
    const nextTimeline = [
      ...(order.timeline || []),
      {
        status: updates.status,
        timestamp: new Date().toISOString(),
        note:
          updates.note.trim() ||
          `Order updated to ${updates.status}${
            updates.trackingNumber ? ` (Tracking: ${updates.trackingNumber})` : ''
          }`,
        actor: auth.currentUser?.email || 'Admin',
      },
    ].slice(-40);

    const payload: Record<string, unknown> = {
      orderNumber: order.orderNumber,
      userId: order.userId,
      customerName: order.customerName,
      customerEmail: order.customerEmail,
      customerPhone: order.customerPhone || '',
      shippingAddress: order.shippingAddress || '',
      hasPhysicalItems: Boolean(order.hasPhysicalItems),
      currencyCode: order.currencyCode || storeConfig.currencyCode,
      currencySymbol: order.currencySymbol || storeConfig.currencySymbol,
      subtotal: Number(order.subtotal ?? order.totalAmount),
      discountAmount: Number(order.discountAmount ?? 0),
      couponCode: order.couponCode || '',
      shippingFee: Number(order.shippingFee ?? 0),
      taxAmount: Number(order.taxAmount ?? 0),
      totalAmount: Number(order.totalAmount),
      paymentProvider: order.paymentProvider || 'test_mode',
      paymentReference: order.paymentReference || '',
      paymentStatus: updates.paymentStatus,
      status: updates.status,
      trackingNumber: updates.trackingNumber.trim().slice(0, 120),
      estimatedDeliveryDate: estDate.slice(0, 40),
      items: order.items,
      timeline: nextTimeline,
      updatedAt: serverTimestamp(),
    };
    if (order.createdAt) {
      payload.createdAt = order.createdAt;
    }

    const publicPayload = {
      orderId: order.id,
      orderNumber: order.orderNumber,
      status: updates.status,
      paymentStatus: updates.paymentStatus,
      trackingNumber: updates.trackingNumber.trim().slice(0, 120),
      estimatedDeliveryDate: estDate.slice(0, 40),
      hasPhysicalItems: Boolean(order.hasPhysicalItems),
      timeline: nextTimeline,
      updatedAt: serverTimestamp(),
    };

    return { payload, publicPayload };
  };

  const handleSaveSingleOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inspectOrder) return;
    setSavingOrder(true);
    try {
      const { payload, publicPayload } = buildSanitizedOrderPayload(inspectOrder, {
        status: nextStatus,
        paymentStatus: nextPaymentStatus,
        trackingNumber,
        note: statusNote,
      });

      await setDoc(doc(db, 'orders', inspectOrder.id), payload);
      await setDoc(doc(db, 'order_tracking_public', inspectOrder.orderNumber), publicPayload);

      if (inspectOrder.status !== nextStatus) {
        await createOrderStatusNotification({
          userId: inspectOrder.userId,
          orderId: inspectOrder.id,
          orderNumber: inspectOrder.orderNumber,
          newStatus: nextStatus,
          note: statusNote.trim() || undefined,
        });
      }

      await logAuditEvent({
        actionType: 'order_update',
        entityType: 'order',
        entityId: inspectOrder.id,
        entityLabel: inspectOrder.orderNumber,
        changes: [
          {
            field: 'status',
            oldValue: inspectOrder.status,
            newValue: nextStatus,
          },
          {
            field: 'paymentStatus',
            oldValue: inspectOrder.paymentStatus,
            newValue: nextPaymentStatus,
          },
          ...(trackingNumber !== (inspectOrder.trackingNumber || '')
            ? [
                {
                  field: 'trackingNumber',
                  oldValue: inspectOrder.trackingNumber || '—',
                  newValue: trackingNumber || '—',
                },
              ]
            : []),
        ],
        summary: `Updated order ${inspectOrder.orderNumber} to ${nextStatus}`,
      });

      showToast(`Order ${inspectOrder.orderNumber} updated.`, 'success');
      setInspectOrder(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${inspectOrder.id}`);
    } finally {
      setSavingOrder(false);
    }
  };

  const handleVerifyPaymentServer = async () => {
    if (!inspectOrder || inspectOrder.paymentProvider === 'test_mode') return;
    if (!inspectOrder.paymentReference) {
      showToast('No payment reference recorded on this order.', 'error');
      return;
    }
    setVerifyingPayment(true);
    try {
      const idToken = await auth.currentUser?.getIdToken();
      const resp = await fetch('/api/payments/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`,
        },
        body: JSON.stringify({
          provider: inspectOrder.paymentProvider,
          reference: inspectOrder.paymentReference,
          expectedAmount: inspectOrder.totalAmount,
        }),
      });
      const data = (await resp.json()) as {
        verified?: boolean;
        error?: string;
        amount?: number;
      };
      if (!resp.ok || !data.verified) {
        showToast(data.error || 'Payment verification failed.', 'error');
        return;
      }
      setNextPaymentStatus('verified_paid');
      if (nextStatus === 'Awaiting Payment') {
        setNextStatus('Paid');
      }
      setStatusNote(
        `Verified server-side via ${inspectOrder.paymentProvider} (${inspectOrder.paymentReference})`
      );
      showToast('Payment verified with gateway! Click Save Update to apply.', 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Verification error.', 'error');
    } finally {
      setVerifyingPayment(false);
    }
  };

  const handleBatchUpdateStatus = async (targetStatus: 'Shipped' | 'Completed') => {
    const targets = allOrders.filter((o) => selectedIds.includes(o.id));
    if (targets.length === 0) return;
    setBatchUpdating(true);
    try {
      for (const order of targets) {
        const { payload, publicPayload } = buildSanitizedOrderPayload(order, {
          status: targetStatus,
          paymentStatus: order.paymentStatus,
          trackingNumber: order.trackingNumber || '',
          note: `Batch fulfillment update to ${targetStatus}`,
        });
        await setDoc(doc(db, 'orders', order.id), payload);
        await setDoc(doc(db, 'order_tracking_public', order.orderNumber), publicPayload);
        await createOrderStatusNotification({
          userId: order.userId,
          orderId: order.id,
          orderNumber: order.orderNumber,
          newStatus: targetStatus,
        });
      }
      await logAuditEvent({
        actionType: 'order_batch_update',
        entityType: 'order',
        entityId: selectedIds.slice(0, 5).join(','),
        entityLabel: `${targets.length} orders`,
        summary: `Batch updated ${targets.length} orders to ${targetStatus}`,
      });
      showToast(`Updated ${targets.length} orders to ${targetStatus}.`, 'success');
      setSelectedIds([]);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'orders');
    } finally {
      setBatchUpdating(false);
    }
  };

  const handleExportCsv = () => {
    const source =
      selectedIds.length > 0
        ? filteredOrders.filter((o) => selectedIds.includes(o.id))
        : filteredOrders;
    if (source.length === 0) {
      showToast('No orders to export.', 'info');
      return;
    }
    const headers = [
      'OrderNumber',
      'Date',
      'CustomerName',
      'CustomerEmail',
      'Status',
      'PaymentProvider',
      'PaymentStatus',
      'PaymentReference',
      'TotalAmount',
      'Currency',
      'TrackingNumber',
      'Items',
    ];
    const rows = source.map((o) => [
      o.orderNumber,
      formatDateTime(o.createdAt),
      o.customerName,
      o.customerEmail,
      o.status,
      o.paymentProvider,
      o.paymentStatus,
      o.paymentReference || '',
      o.totalAmount,
      o.currencyCode || storeConfig.currencyCode,
      o.trackingNumber || '',
      o.items.map((i) => `${i.quantity}x ${i.title} (${i.sku})`).join('; '),
    ]);
    downloadCsvFile(`princegoldsocialhub-orders-${new Date().toISOString().slice(0, 10)}.csv`, headers, rows);
    showToast(`Exported ${source.length} orders to CSV.`, 'success');
  };

  const handlePrintPackingSlips = () => {
    const targets =
      selectedIds.length > 0
        ? filteredOrders.filter((o) => selectedIds.includes(o.id))
        : filteredOrders;
    if (targets.length === 0) {
      showToast('Select or filter orders first to print packing slips.', 'info');
      return;
    }
    const docPdf = new jsPDF({ unit: 'pt', format: 'a4' });
    targets.forEach((order, idx) => {
      if (idx > 0) docPdf.addPage();
      let y = 44;

      if (storeConfig.packingSlipLogoUrl && storeConfig.packingSlipLogoUrl.startsWith('data:image/')) {
        try {
          const fmt = storeConfig.packingSlipLogoUrl.includes('image/png') ? 'PNG' : 'JPEG';
          docPdf.addImage(storeConfig.packingSlipLogoUrl, fmt, 40, y - 10, 64, 36);
        } catch {
          // skip unreadable custom logo
        }
      }

      docPdf.setFont('helvetica', 'bold');
      docPdf.setFontSize(18);
      docPdf.setTextColor(17, 24, 39);
      docPdf.text(storeConfig.storeName || 'Princegoldsocialhub', 116, y + 6);

      docPdf.setFont('helvetica', 'normal');
      docPdf.setFontSize(9);
      docPdf.setTextColor(90, 95, 105);
      const headerLines = (storeConfig.packingSlipHeaderAddress || '').split('\n');
      headerLines.forEach((line, li) => {
        docPdf.text(line.slice(0, 80), 116, y + 22 + li * 12);
      });

      docPdf.setFont('helvetica', 'bold');
      docPdf.setFontSize(13);
      docPdf.setTextColor(255, 106, 0);
      docPdf.text('PACKING SLIP', 450, y + 6);

      y += Math.max(66, 34 + headerLines.length * 12);
      docPdf.setDrawColor(230, 232, 236);
      docPdf.line(40, y, 555, y);
      y += 22;

      docPdf.setFont('helvetica', 'bold');
      docPdf.setFontSize(11);
      docPdf.setTextColor(17, 24, 39);
      docPdf.text(`Order ID: ${order.orderNumber}`, 40, y);
      docPdf.setFont('helvetica', 'normal');
      docPdf.setFontSize(10);
      docPdf.text(`Date: ${formatDateTime(order.createdAt)}`, 360, y);
      y += 18;
      docPdf.text(`Customer: ${order.customerName} (${order.customerEmail})`, 40, y);
      y += 16;
      if (order.customerPhone) {
        docPdf.text(`Phone: ${order.customerPhone}`, 40, y);
        y += 16;
      }
      if (order.shippingAddress) {
        docPdf.text(`Delivery / Fulfillment Address: ${order.shippingAddress}`, 40, y);
        y += 16;
      }
      if (order.trackingNumber) {
        docPdf.text(`Tracking #: ${order.trackingNumber}`, 40, y);
        y += 16;
      }

      y += 12;
      docPdf.setFillColor(247, 248, 250);
      docPdf.rect(40, y, 515, 24, 'F');
      docPdf.setFont('helvetica', 'bold');
      docPdf.setFontSize(9);
      docPdf.text('SKU', 48, y + 16);
      docPdf.text('ITEM / SERVICE', 155, y + 16);
      docPdf.text('QTY', 415, y + 16);
      docPdf.text('AMOUNT', 480, y + 16);
      y += 34;

      docPdf.setFont('helvetica', 'normal');
      order.items.forEach((item) => {
        docPdf.text(item.sku.slice(0, 18), 48, y);
        docPdf.text(item.title.slice(0, 42), 155, y);
        docPdf.text(String(item.quantity), 420, y);
        docPdf.text(
          `${order.currencyCode || storeConfig.currencyCode} ${(item.price * item.quantity).toFixed(2)}`,
          475,
          y
        );
        y += 20;
      });

      y += 10;
      docPdf.line(40, y, 555, y);
      y += 20;
      docPdf.setFont('helvetica', 'bold');
      docPdf.setFontSize(11);
      docPdf.text(
        `Total: ${order.currencyCode || storeConfig.currencyCode} ${order.totalAmount.toFixed(2)} (${order.status})`,
        340,
        y
      );

      y = 760;
      docPdf.setFont('helvetica', 'normal');
      docPdf.setFontSize(9);
      docPdf.setTextColor(107, 114, 128);
      const footerLines = docPdf.splitTextToSize(storeConfig.packingSlipFooterText || '', 515);
      docPdf.text(footerLines, 40, y);
    });

    docPdf.save(`packing-slips-${new Date().toISOString().slice(0, 10)}.pdf`);
    showToast(`Generated packing slip PDF for ${targets.length} order(s).`, 'success');
  };

  return (
    <div className="space-y-5">
      {/* Toolbar */}
      <div className="rounded-3xl bg-white p-5 shadow-sm border border-gray-100 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display font-bold text-lg text-gray-900">
              Order & Fulfillment Management
            </h2>
            <p className="text-xs text-gray-500">
              Inspect orders, update delivery statuses, verify gateway payments, and print packing slips.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50"
            >
              <Download className="w-4 h-4" />
              Export to CSV
            </button>
            <button
              type="button"
              onClick={handlePrintPackingSlips}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[#0B4F5B] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#093e48]"
            >
              <Printer className="w-4 h-4" />
              Print Packing Slips ({selectedIds.length || filteredOrders.length})
            </button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search Order ID, customer name, email, or reference..."
              className="w-full rounded-xl border border-gray-200 pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-sm font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
          >
            <option value="ALL">All Orders ({allOrders.length})</option>
            <option value="PENDING_GROUP">Pending Fulfillment</option>
            {ALL_STATUSES.map((st) => (
              <option key={st} value={st}>
                {st}
              </option>
            ))}
          </select>
        </div>

        {selectedIds.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-orange-50 border border-orange-200 px-4 py-3">
            <span className="text-xs font-semibold text-orange-900">
              {selectedIds.length} order(s) selected
            </span>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={batchUpdating}
                onClick={() => handleBatchUpdateStatus('Shipped')}
                className="inline-flex items-center gap-1 rounded-lg bg-white border border-orange-300 px-3 py-1.5 text-xs font-semibold text-orange-900 hover:bg-orange-100 disabled:opacity-50"
              >
                <Truck className="w-3.5 h-3.5" />
                Batch Mark Shipped
              </button>
              <button
                type="button"
                disabled={batchUpdating}
                onClick={() => handleBatchUpdateStatus('Completed')}
                className="inline-flex items-center gap-1 rounded-lg bg-[#FF6A00] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#e85f00] disabled:opacity-50"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                Batch Mark Completed
              </button>
              <button
                type="button"
                onClick={() => setSelectedIds([])}
                className="text-xs font-semibold text-gray-600 hover:text-gray-900 px-2"
              >
                Clear
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Orders List / Table */}
      <div className="rounded-3xl bg-white shadow-sm border border-gray-100 overflow-hidden">
        {filteredOrders.length === 0 ? (
          <div className="p-10 text-center">
            <Package className="w-10 h-10 text-gray-300 mx-auto mb-3" />
            <p className="font-semibold text-gray-800">No matching orders found</p>
            <p className="text-xs text-gray-500 mt-1">
              Customer orders placed through checkout will appear here in real time.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50 text-xs font-semibold text-gray-500 uppercase">
                  <th className="py-3 px-4 w-10">
                    <button
                      type="button"
                      onClick={toggleSelectAll}
                      className="text-gray-500 hover:text-gray-800"
                    >
                      {selectedIds.length === filteredOrders.length ? (
                        <CheckSquare className="w-4 h-4 text-[#FF6A00]" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </th>
                  <th className="py-3 px-4">Order ID</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Total</th>
                  <th className="py-3 px-4">Payment</th>
                  <th className="py-3 px-4">Fulfillment</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredOrders.map((order) => {
                  const isSelected = selectedIds.includes(order.id);
                  return (
                    <tr key={order.id} className="hover:bg-gray-50/70">
                      <td className="py-3.5 px-4">
                        <button
                          type="button"
                          onClick={() => toggleSelectOrder(order.id)}
                          className="text-gray-500 hover:text-gray-800"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-[#FF6A00]" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="font-mono-tabular font-semibold text-gray-900">
                          {order.orderNumber}
                        </span>
                        <div className="text-xs text-gray-400">
                          {order.items.length} item{order.items.length === 1 ? '' : 's'}
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-medium text-gray-900">{order.customerName}</div>
                        <div className="text-xs text-gray-500">{order.customerEmail}</div>
                      </td>
                      <td className="py-3.5 px-4 font-semibold tabular-nums text-gray-900">
                        {formatCurrency(order.totalAmount, order.currencySymbol || storeConfig.currencySymbol)}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="text-xs font-medium uppercase text-gray-600 block">
                          {order.paymentProvider.replace('_', ' ')}
                        </span>
                        <span
                          className={`inline-block mt-0.5 text-[11px] font-semibold px-2 py-0.5 rounded-md ${
                            order.paymentStatus === 'verified_paid'
                              ? 'bg-emerald-50 text-emerald-700'
                              : order.paymentStatus === 'refunded'
                              ? 'bg-gray-100 text-gray-600'
                              : 'bg-amber-50 text-amber-700'
                          }`}
                        >
                          {order.paymentStatus}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-block text-xs font-semibold px-2.5 py-1 rounded-lg ${
                            order.status === 'Completed'
                              ? 'bg-emerald-50 text-emerald-700'
                              : order.status === 'Cancelled' || order.status === 'Refunded'
                              ? 'bg-red-50 text-red-700'
                              : 'bg-orange-50 text-[#FF6A00]'
                          }`}
                        >
                          {order.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-gray-500 whitespace-nowrap">
                        {formatDateTime(order.createdAt)}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => openInspectModal(order)}
                          className="inline-flex items-center gap-1 rounded-lg border border-gray-200 px-3 py-1.5 text-xs font-semibold text-gray-700 hover:bg-gray-100"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          Manage
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Inspect & Update Order Modal */}
      {inspectOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
          <div className="w-full max-w-2xl rounded-3xl bg-white p-6 shadow-2xl my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-gray-100 pb-4 mb-5">
              <div>
                <h3 className="font-display font-bold text-lg text-gray-900">
                  Manage Order{' '}
                  <span className="font-mono-tabular text-[#FF6A00]">
                    {inspectOrder.orderNumber}
                  </span>
                </h3>
                <p className="text-xs text-gray-500">
                  Placed {formatDateTime(inspectOrder.createdAt)}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setInspectOrder(null)}
                className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5 text-sm">
              <div className="rounded-2xl bg-gray-50 p-4">
                <p className="text-xs font-semibold text-gray-400 uppercase mb-1">Customer</p>
                <p className="font-semibold text-gray-900">{inspectOrder.customerName}</p>
                <p className="text-xs text-gray-600">{inspectOrder.customerEmail}</p>
                {inspectOrder.customerPhone && (
                  <p className="text-xs text-gray-600">{inspectOrder.customerPhone}</p>
                )}
                {inspectOrder.shippingAddress && (
                  <p className="text-xs text-gray-600 mt-1">{inspectOrder.shippingAddress}</p>
                )}
              </div>

              <div className="rounded-2xl bg-gray-50 p-4">
                <p className="text-xs font-semibold text-gray-400 uppercase mb-1">Payment Info</p>
                <p className="font-semibold text-gray-900">
                  {formatCurrency(
                    inspectOrder.totalAmount,
                    inspectOrder.currencySymbol || storeConfig.currencySymbol
                  )}
                </p>
                <p className="text-xs text-gray-600">
                  Provider: {inspectOrder.paymentProvider}
                </p>
                <p className="text-xs font-mono-tabular text-gray-600 break-all">
                  Ref: {inspectOrder.paymentReference || 'N/A'}
                </p>
                {inspectOrder.paymentProvider !== 'test_mode' && inspectOrder.paymentReference && (
                  <button
                    type="button"
                    disabled={verifyingPayment}
                    onClick={handleVerifyPaymentServer}
                    className="mt-2 inline-flex items-center gap-1 rounded-lg bg-[#0B4F5B] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#093e48] disabled:opacity-50"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    {verifyingPayment ? 'Verifying...' : 'Verify Payment with Provider'}
                  </button>
                )}
              </div>
            </div>

            {/* Line Items */}
            <div className="rounded-2xl border border-gray-200 p-4 mb-5">
              <p className="text-xs font-semibold text-gray-500 uppercase mb-2">Order Items</p>
              <div className="divide-y divide-gray-100 text-sm">
                {inspectOrder.items.map((item, idx) => (
                  <div key={`${item.productId}-${idx}`} className="py-2 flex items-center justify-between gap-2">
                    <div>
                      <p className="font-medium text-gray-900">{item.title}</p>
                      <p className="text-xs text-gray-500 font-mono-tabular">
                        SKU: {item.sku} · Qty: {item.quantity} · {item.fulfillmentMethod.replace('_', ' ')}
                      </p>
                    </div>
                    <span className="font-semibold tabular-nums text-gray-900">
                      {formatCurrency(
                        item.price * item.quantity,
                        inspectOrder.currencySymbol || storeConfig.currencySymbol
                      )}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Update Form */}
            <form onSubmit={handleSaveSingleOrder} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Fulfillment Status
                  </label>
                  <select
                    value={nextStatus}
                    onChange={(e) => setNextStatus(e.target.value as OrderStatus)}
                    className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                  >
                    {ALL_STATUSES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Payment Status
                  </label>
                  <select
                    value={nextPaymentStatus}
                    onChange={(e) => setNextPaymentStatus(e.target.value as PaymentStatus)}
                    className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                  >
                    <option value="unpaid">unpaid</option>
                    <option value="test_pending">test_pending</option>
                    <option value="verified_paid">verified_paid</option>
                    <option value="refunded">refunded</option>
                  </select>
                </div>
              </div>

              {(inspectOrder.hasPhysicalItems || trackingNumber) && (
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Shipment Tracking Number
                  </label>
                  <input
                    type="text"
                    value={trackingNumber}
                    onChange={(e) => setTrackingNumber(e.target.value)}
                    placeholder="e.g. DHL-948201948"
                    className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm font-mono-tabular focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Timeline & Customer Notification Note
                </label>
                <input
                  type="text"
                  value={statusNote}
                  onChange={(e) => setStatusNote(e.target.value)}
                  placeholder="Optional update message visible in order timeline..."
                  className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setInspectOrder(null)}
                  className="px-4 py-2.5 rounded-xl border border-gray-200 text-sm font-semibold text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingOrder}
                  className="px-5 py-2.5 rounded-xl bg-[#FF6A00] text-sm font-semibold text-white hover:bg-[#e85f00] disabled:opacity-50"
                >
                  {savingOrder ? 'Saving...' : 'Save Order Update'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
