import React, { useMemo, useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from 'recharts';
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  Clock,
  CreditCard,
  Download,
  FileSpreadsheet,
  Package,
  ScanLine,
  TrendingUp,
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { downloadCsvFile, formatCurrency, toDateObj } from '../../lib/storeDefaults';
import { AdminTabId, ScanHistoryEntry } from '../../types';

export const AdminDashboardTab: React.FC<{
  scanHistory: ScanHistoryEntry[];
  onNavigateTab: (tab: AdminTabId) => void;
  onFilterPendingOrders: () => void;
}> = ({ scanHistory, onNavigateTab, onFilterPendingOrders }) => {
  const { allOrders, products, storeConfig, showToast } = useApp();
  const [revenueRange, setRevenueRange] = useState<7 | 30>(7);
  const [scanRange, setScanRange] = useState<'last50' | 'all'>('last50');
  const [compareHistoricalScans, setCompareHistoricalScans] = useState(true);

  const now = new Date();
  const todayKey = now.toISOString().slice(0, 10);
  const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  const yesterdayKey = yesterday.toISOString().slice(0, 10);

  const pendingOrdersCount = useMemo(
    () =>
      allOrders.filter((o) =>
        ['Awaiting Payment', 'Paid', 'Processing'].includes(o.status)
      ).length,
    [allOrders]
  );

  const revenueMetrics = useMemo(() => {
    let todayRev = 0;
    let yesterdayRev = 0;
    const hourlyMap: Record<number, number> = {};
    for (let h = 0; h < 24; h++) hourlyMap[h] = 0;

    for (const order of allOrders) {
      if (order.status === 'Cancelled' || order.status === 'Refunded') continue;
      const d = toDateObj(order.createdAt);
      const dayStr = d.toISOString().slice(0, 10);
      if (dayStr === todayKey) {
        todayRev += order.totalAmount || 0;
        hourlyMap[d.getHours()] = (hourlyMap[d.getHours()] || 0) + (order.totalAmount || 0);
      } else if (dayStr === yesterdayKey) {
        yesterdayRev += order.totalAmount || 0;
      }
    }

    let growthPct = 0;
    if (yesterdayRev > 0) {
      growthPct = ((todayRev - yesterdayRev) / yesterdayRev) * 100;
    } else if (todayRev > 0) {
      growthPct = 100;
    }

    const hourlySeries = Object.entries(hourlyMap).map(([hr, rev]) => ({
      hour: `${String(hr).padStart(2, '0')}:00`,
      revenue: rev,
    }));

    return { todayRev, yesterdayRev, growthPct, hourlySeries };
  }, [allOrders, todayKey, yesterdayKey]);

  // Daily Revenue & Order Volume (strictly financial + order metrics, NO user counts)
  const dailySeries = useMemo(() => {
    const map = new Map<string, { date: string; label: string; revenue: number; orders: number }>();
    for (let i = revenueRange - 1; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const key = d.toISOString().slice(0, 10);
      const label = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      map.set(key, { date: key, label, revenue: 0, orders: 0 });
    }
    for (const order of allOrders) {
      if (order.status === 'Cancelled' || order.status === 'Refunded') continue;
      const d = toDateObj(order.createdAt);
      const key = d.toISOString().slice(0, 10);
      const entry = map.get(key);
      if (entry) {
        entry.revenue += order.totalAmount || 0;
        entry.orders += 1;
      }
    }
    return Array.from(map.values());
  }, [allOrders, revenueRange, now]);

  // Low Stock Inventory Alerts
  const lowStockProducts = useMemo(() => {
    const threshold = storeConfig.lowStockThreshold ?? 5;
    return products
      .filter((p) => p.trackStock && p.stock <= threshold)
      .sort((a, b) => a.stock - b.stock);
  }, [products, storeConfig.lowStockThreshold]);

  // Scan Performance Calculations (Last 50 vs Previous 50)
  const scanStats = useMemo(() => {
    const recent50 = scanHistory.slice(0, 50);
    const prev50 = scanHistory.slice(50, 100);

    const avg = (arr: ScanHistoryEntry[], key: 'accuracyScore' | 'durationMs') =>
      arr.length === 0
        ? 0
        : arr.reduce((s, item) => s + (item[key] || 0), 0) / arr.length;

    const avgAcc = avg(recent50, 'accuracyScore');
    const prevAcc = avg(prev50, 'accuracyScore');
    const avgDur = avg(recent50, 'durationMs');
    const prevDur = avg(prev50, 'durationMs');

    const accDelta = prev50.length > 0 ? avgAcc - prevAcc : 0;
    const durDelta = prev50.length > 0 ? avgDur - prevDur : 0;

    const baseSlice = scanRange === 'last50' ? recent50 : scanHistory;
    const ordered = [...baseSlice].reverse();
    const overallHistAvg = prev50.length > 0 ? prevAcc : avgAcc || 85;

    const chartData = ordered.map((s, idx) => {
      const deviation = Math.abs(s.accuracyScore - overallHistAvg);
      return {
        index: `#${idx + 1}`,
        sku: s.sku,
        accuracy: s.accuracyScore,
        historicalAvg: Math.round(overallHistAvg),
        durationMs: s.durationMs,
        deviated: deviation >= 15,
      };
    });

    return {
      recentCount: recent50.length,
      avgAcc: Math.round(avgAcc * 10) / 10,
      avgDur: Math.round(avgDur),
      accDelta: Math.round(accDelta * 10) / 10,
      durDelta: Math.round(durDelta),
      historicalAvg: Math.round(overallHistAvg),
      chartData,
    };
  }, [scanHistory, scanRange]);

  const handleGenerateMonthlyReport = () => {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const monthlyOrders = allOrders.filter(
      (o) => toDateObj(o.createdAt) >= thirtyDaysAgo
    );
    downloadCsvFile(
      `princegold-monthly-report-${todayKey}.csv`,
      ['Order ID', 'Date', 'Status', 'Payment Status', 'Items', 'Total Amount', 'Currency'],
      monthlyOrders.map((o) => [
        o.orderNumber,
        toDateObj(o.createdAt).toISOString(),
        o.status,
        o.paymentStatus,
        o.items.map((i) => `${i.quantity}x ${i.sku}`).join('; '),
        o.totalAmount,
        o.currencyCode,
      ])
    );
    showToast(`Exported 30-day financial report (${monthlyOrders.length} orders).`, 'success');
  };

  return (
    <div className="space-y-5">
      {/* Top Summary Widget: Pending Orders + Today Revenue + Growth + Sparkline + 3 Quick Actions */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Pending Orders</span>
            <div className="w-9 h-9 rounded-xl bg-orange-50 text-[#FF6A00] flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-slate-900 tabular-nums">
            {pendingOrdersCount}
          </div>
          <p className="mt-1 text-xs text-slate-500">
            Orders awaiting payment verification or fulfillment
          </p>
        </div>

        <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs lg:col-span-2 flex flex-col sm:flex-row items-stretch justify-between gap-4">
          <div className="flex flex-col justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-500">Total Revenue Today</span>
              <div className="mt-2 flex items-baseline gap-2.5">
                <span className="text-3xl font-bold text-[#0B4F5B] tabular-nums">
                  {formatCurrency(revenueMetrics.todayRev, storeConfig.currencySymbol)}
                </span>
                <span
                  className={`inline-flex items-center gap-0.5 text-xs font-bold tabular-nums ${
                    revenueMetrics.growthPct >= 0 ? 'text-emerald-700' : 'text-red-600'
                  }`}
                >
                  {revenueMetrics.growthPct >= 0 ? (
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  ) : (
                    <ArrowDownRight className="w-3.5 h-3.5" />
                  )}
                  {Math.abs(revenueMetrics.growthPct).toFixed(1)}% vs yesterday
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Yesterday:{' '}
              <span className="tabular-nums font-semibold">
                {formatCurrency(revenueMetrics.yesterdayRev, storeConfig.currencySymbol)}
              </span>
            </p>
          </div>

          {/* Hourly Revenue Sparkline */}
          <div className="w-full sm:w-64 h-24 shrink-0">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={revenueMetrics.hourlySeries}>
                <Tooltip
                  formatter={(value) => [
                    formatCurrency(Number(value ?? 0), storeConfig.currencySymbol),
                    'Hourly Revenue',
                  ]}
                  labelFormatter={(lbl) => `Hour: ${lbl}`}
                  contentStyle={{
                    borderRadius: '12px',
                    border: '1px solid #e2e8f0',
                    fontSize: '11px',
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="#FF6A00"
                  strokeWidth={2.5}
                  dot={false}
                  activeDot={{ r: 4, fill: '#0B4F5B' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Three Quick-Action Buttons */}
      <section className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={onFilterPendingOrders}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#FF6A00] text-white text-xs font-bold hover:bg-[#e55f00] transition-colors"
        >
          <Package className="w-4 h-4" />
          View All Pending
        </button>
        <button
          type="button"
          onClick={handleGenerateMonthlyReport}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#0B4F5B] text-white text-xs font-bold hover:bg-[#093f49] transition-colors"
        >
          <FileSpreadsheet className="w-4 h-4" />
          Generate Monthly Report
        </button>
        <button
          type="button"
          onClick={() => onNavigateTab('payments')}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-slate-200 text-slate-800 text-xs font-bold hover:bg-slate-50 transition-colors"
        >
          <CreditCard className="w-4 h-4 text-[#FF6A00]" />
          Configure Payment Settings
        </button>
      </section>

      {/* Recharts Daily Revenue & Order Volume */}
      <section className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Daily Sales Revenue &amp; Order Volume
            </h2>
            <p className="text-xs text-slate-500">
              Financial revenue and order counts only (excludes user/signup metrics)
            </p>
          </div>
          <div className="inline-flex p-1 rounded-xl bg-slate-100 gap-1 self-start">
            <button
              type="button"
              onClick={() => setRevenueRange(7)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                revenueRange === 7 ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Last 7 Days
            </button>
            <button
              type="button"
              onClick={() => setRevenueRange(30)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                revenueRange === 30 ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Last 30 Days
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="h-64">
            <div className="text-xs font-semibold text-slate-600 mb-2">Daily Revenue</div>
            <ResponsiveContainer width="100%" height="90%">
              <AreaChart data={dailySeries}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FF6A00" stopOpacity={0.28} />
                    <stop offset="95%" stopColor="#FF6A00" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip
                  formatter={(val) => [
                    formatCurrency(Number(val ?? 0), storeConfig.currencySymbol),
                    'Revenue',
                  ]}
                  contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }}
                />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#FF6A00"
                  strokeWidth={2.5}
                  fill="url(#revGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="h-64">
            <div className="text-xs font-semibold text-slate-600 mb-2">Daily Order Count</div>
            <ResponsiveContainer width="100%" height="90%">
              <BarChart data={dailySeries}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip
                  formatter={(val) => [`${Number(val ?? 0)} order(s)`, 'Orders']}
                  contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }}
                />
                <Bar dataKey="orders" fill="#0B4F5B" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Inventory Alerts Section */}
      <section className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-[#FF6A00]" />
            <h2 className="text-base font-bold text-slate-900">
              Inventory Alerts (Threshold ≤ {storeConfig.lowStockThreshold ?? 5})
            </h2>
          </div>
          <button
            type="button"
            onClick={() => onNavigateTab('settings')}
            className="text-xs font-semibold text-[#0B4F5B] hover:underline"
          >
            Adjust Threshold
          </button>
        </div>

        {lowStockProducts.length === 0 ? (
          <p className="text-xs text-slate-500 py-2">
            No stocked products are currently below your low-stock threshold.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-500">
                  <th className="py-2 pr-3">Product</th>
                  <th className="py-2 pr-3">Inventory SKU</th>
                  <th className="py-2 pr-3">Current Stock</th>
                  <th className="py-2">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {lowStockProducts.map((p) => (
                  <tr key={p.id}>
                    <td className="py-2.5 pr-3 font-semibold text-slate-900">{p.title}</td>
                    <td className="py-2.5 pr-3 font-mono-tabular text-slate-600">{p.sku}</td>
                    <td className="py-2.5 pr-3 font-bold text-red-600 tabular-nums">
                      {p.stock} left
                    </td>
                    <td className="py-2.5">
                      <button
                        type="button"
                        onClick={() => onNavigateTab('catalog')}
                        className="text-[#FF6A00] font-semibold hover:underline"
                      >
                        Restock in Catalog
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Scan Performance Dashboard Widget */}
      <section className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-50 text-[#0B4F5B] flex items-center justify-center">
              <ScanLine className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Scan Performance (Last 50 Scans)
              </h2>
              <p className="text-xs text-slate-500">
                QR/Barcode identification speed, accuracy, and historical deviation tracking
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setCompareHistoricalScans((v) => !v)}
              className={`px-3 py-1.5 rounded-xl border text-xs font-semibold ${
                compareHistoricalScans
                  ? 'border-[#0B4F5B] bg-teal-50 text-[#0B4F5B]'
                  : 'border-slate-200 text-slate-600'
              }`}
            >
              {compareHistoricalScans ? 'Comparing Historical Avg' : 'Compare Historical Avg'}
            </button>
            <div className="inline-flex p-1 rounded-xl bg-slate-100 gap-1">
              <button
                type="button"
                onClick={() => setScanRange('last50')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                  scanRange === 'last50' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                Last 50 Scans
              </button>
              <button
                type="button"
                onClick={() => setScanRange('all')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                  scanRange === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                All Time
              </button>
            </div>
            <button
              type="button"
              onClick={() =>
                downloadCsvFile(
                  `princegold-scan-performance-${todayKey}.csv`,
                  ['SKU', 'Product', 'Duration (ms)', 'Accuracy Score', 'Historical Avg', 'Session'],
                  scanHistory.map((s) => [
                    s.sku,
                    s.productTitle,
                    s.durationMs,
                    s.accuracyScore,
                    scanStats.historicalAvg,
                    s.sessionLabel,
                  ])
                )
              }
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="rounded-2xl bg-slate-50 p-4">
            <div className="text-xs text-slate-500">Avg Scan Accuracy</div>
            <div className="mt-1 flex items-center gap-2">
              <span className="text-2xl font-bold text-[#0B4F5B] tabular-nums">
                {scanStats.avgAcc}%
              </span>
              <span
                className={`inline-flex items-center text-xs font-bold tabular-nums ${
                  scanStats.accDelta >= 0 ? 'text-emerald-700' : 'text-red-600'
                }`}
              >
                {scanStats.accDelta >= 0 ? (
                  <ArrowUpRight className="w-3.5 h-3.5" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5" />
                )}
                {Math.abs(scanStats.accDelta)}%
              </span>
            </div>
          </div>

          <div className="rounded-2xl bg-slate-50 p-4">
            <div className="text-xs text-slate-500">Avg Time-to-Identify</div>
            <div className="mt-1 flex items-center gap-2">
              <span className="text-2xl font-bold text-slate-900 tabular-nums">
                {scanStats.avgDur} ms
              </span>
              <span
                className={`inline-flex items-center text-xs font-bold tabular-nums ${
                  scanStats.durDelta <= 0 ? 'text-emerald-700' : 'text-red-600'
                }`}
              >
                {scanStats.durDelta <= 0 ? (
                  <ArrowDownRight className="w-3.5 h-3.5" />
                ) : (
                  <ArrowUpRight className="w-3.5 h-3.5" />
                )}
                {Math.abs(scanStats.durDelta)} ms
              </span>
            </div>
          </div>

          <div className="rounded-2xl bg-slate-50 p-4">
            <div className="text-xs text-slate-500">Recorded Scans</div>
            <div className="mt-1 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-[#FF6A00]" />
              <span className="text-2xl font-bold text-slate-900 tabular-nums">
                {scanHistory.length}
              </span>
            </div>
          </div>
        </div>

        {scanStats.chartData.length > 0 ? (
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={scanStats.chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="index" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip
                  formatter={(value, name) => [
                    name === 'accuracy' ? `${Number(value ?? 0)}%` : `${Number(value ?? 0)}% (Hist. Avg)`,
                    name === 'accuracy' ? 'Scan Accuracy' : 'Historical Average',
                  ]}
                  contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }}
                />
                <ReferenceLine
                  y={scanStats.historicalAvg}
                  stroke="#0B4F5B"
                  strokeDasharray="4 4"
                  label={{
                    value: `Hist. Avg (${scanStats.historicalAvg}%)`,
                    position: 'insideTopRight',
                    fill: '#0B4F5B',
                    fontSize: 10,
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="accuracy"
                  stroke="#FF6A00"
                  strokeWidth={2.5}
                  dot={(props: { cx?: number; cy?: number; payload?: { deviated?: boolean } }) => {
                    if (!props.cx || !props.cy) return <g />;
                    return (
                      <circle
                        cx={props.cx}
                        cy={props.cy}
                        r={props.payload?.deviated ? 5 : 3}
                        fill={props.payload?.deviated ? '#dc2626' : '#FF6A00'}
                        stroke="#fff"
                        strokeWidth={1.5}
                      />
                    );
                  }}
                />
                {compareHistoricalScans && (
                  <Line
                    type="monotone"
                    dataKey="historicalAvg"
                    stroke="#0B4F5B"
                    strokeWidth={1.5}
                    strokeDasharray="5 5"
                    dot={false}
                  />
                )}
              </LineChart>
            </ResponsiveContainer>
            <div className="text-[11px] text-slate-500 mt-1">
              Red nodes indicate scans where accuracy deviated by ≥15% from historical session
              averages.
            </div>
          </div>
        ) : (
          <p className="text-xs text-slate-500 py-4 text-center">
            No scans recorded yet. Use the Scan Product button in Admin Catalog to log QR/barcode
            scan performance.
          </p>
        )}
      </section>
    </div>
  );
};
