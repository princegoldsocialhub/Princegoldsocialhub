import React, { useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import {
  ArrowDown,
  ArrowUp,
  Edit3,
  FolderKanban,
  Plus,
  Tag,
  Trash2,
  X,
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { computeFieldDiffs, logAuditEvent } from '../../lib/audit';
import { Category, CategoryGroup, Promotion } from '../../types';

export const AdminCategoriesTab: React.FC<{
  promotions: Promotion[];
}> = ({ promotions }) => {
  const { categories, products, showToast } = useApp();

  // Category Form State
  const [catModalOpen, setCatModalOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<Category | null>(null);
  const [catName, setCatName] = useState('');
  const [catSlug, setCatSlug] = useState('');
  const [catGroup, setCatGroup] = useState<CategoryGroup>('social_media');
  const [catDesc, setCatDesc] = useState('');
  const [catEnabled, setCatEnabled] = useState(true);
  const [savingCat, setSavingCat] = useState(false);

  // Delete confirmation state
  const [deleteTargetCat, setDeleteTargetCat] = useState<Category | null>(null);

  // Promotion Form State
  const [promoCode, setPromoCode] = useState('');
  const [promoPercent, setPromoPercent] = useState(10);
  const [promoDesc, setPromoDesc] = useState('');
  const [promoActive, setPromoActive] = useState(true);
  const [savingPromo, setSavingPromo] = useState(false);

  const openAddCategory = () => {
    setEditingCat(null);
    setCatName('');
    setCatSlug('');
    setCatGroup('social_media');
    setCatDesc('');
    setCatEnabled(true);
    setCatModalOpen(true);
  };

  const openEditCategory = (cat: Category) => {
    setEditingCat(cat);
    setCatName(cat.name);
    setCatSlug(cat.slug);
    setCatGroup(cat.group);
    setCatDesc(cat.description || '');
    setCatEnabled(cat.enabled);
    setCatModalOpen(true);
  };

  const normalizeSlug = (val: string) =>
    val
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9-]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 80);

  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = catName.trim();
    const cleanSlug = normalizeSlug(catSlug || cleanName);
    if (!cleanName || !cleanSlug) {
      showToast('Category name and valid slug are required.', 'error');
      return;
    }

    setSavingCat(true);
    try {
      if (editingCat) {
        const nextData = {
          name: cleanName.slice(0, 80),
          slug: cleanSlug,
          description: catDesc.trim().slice(0, 300),
          group: catGroup,
          enabled: catEnabled,
          sortOrder: editingCat.sortOrder,
          updatedAt: serverTimestamp(),
        };
        await setDoc(doc(db, 'categories', editingCat.id), nextData);
        const diffs = computeFieldDiffs(
          editingCat as unknown as Record<string, unknown>,
          nextData as unknown as Record<string, unknown>,
          ['name', 'slug', 'group', 'enabled', 'description']
        );
        await logAuditEvent({
          actionType: 'category_update',
          entityType: 'category',
          entityId: editingCat.id,
          entityLabel: cleanName,
          changes: diffs,
          summary: `Updated category "${cleanName}"`,
        });
        showToast('Category updated.', 'success');
      } else {
        const maxOrder = categories.reduce((m, c) => Math.max(m, c.sortOrder || 0), 0);
        const id = cleanSlug;
        const payload = {
          name: cleanName.slice(0, 80),
          slug: cleanSlug,
          description: catDesc.trim().slice(0, 300),
          group: catGroup,
          enabled: catEnabled,
          sortOrder: maxOrder + 1,
          updatedAt: serverTimestamp(),
        };
        await setDoc(doc(db, 'categories', id), payload);
        await logAuditEvent({
          actionType: 'category_create',
          entityType: 'category',
          entityId: id,
          entityLabel: cleanName,
          summary: `Created category "${cleanName}" (${catGroup})`,
        });
        showToast('Category added.', 'success');
      }
      setCatModalOpen(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'categories');
    } finally {
      setSavingCat(false);
    }
  };

  const handleToggleCategory = async (cat: Category) => {
    try {
      await setDoc(doc(db, 'categories', cat.id), {
        name: cat.name,
        slug: cat.slug,
        description: cat.description || '',
        group: cat.group,
        enabled: !cat.enabled,
        sortOrder: cat.sortOrder,
        updatedAt: serverTimestamp(),
      });
      await logAuditEvent({
        actionType: 'category_toggle',
        entityType: 'category',
        entityId: cat.id,
        entityLabel: cat.name,
        changes: [
          {
            field: 'enabled',
            oldValue: String(cat.enabled),
            newValue: String(!cat.enabled),
          },
        ],
        summary: `${!cat.enabled ? 'Enabled' : 'Disabled'} category "${cat.name}"`,
      });
      showToast(`Category "${cat.name}" ${!cat.enabled ? 'enabled' : 'disabled'}.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `categories/${cat.id}`);
    }
  };

  const handleMoveCategory = async (index: number, direction: -1 | 1) => {
    const targetIdx = index + direction;
    if (targetIdx < 0 || targetIdx >= categories.length) return;
    const current = categories[index];
    const swapWith = categories[targetIdx];
    try {
      await setDoc(doc(db, 'categories', current.id), {
        name: current.name,
        slug: current.slug,
        description: current.description || '',
        group: current.group,
        enabled: current.enabled,
        sortOrder: swapWith.sortOrder,
        updatedAt: serverTimestamp(),
      });
      await setDoc(doc(db, 'categories', swapWith.id), {
        name: swapWith.name,
        slug: swapWith.slug,
        description: swapWith.description || '',
        group: swapWith.group,
        enabled: swapWith.enabled,
        sortOrder: current.sortOrder,
        updatedAt: serverTimestamp(),
      });
      await logAuditEvent({
        actionType: 'category_reorder',
        entityType: 'category',
        entityId: current.id,
        entityLabel: current.name,
        summary: `Reordered category "${current.name}"`,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'categories');
    }
  };

  const handleConfirmDeleteCategory = async () => {
    if (!deleteTargetCat) return;
    try {
      await deleteDoc(doc(db, 'categories', deleteTargetCat.id));
      await logAuditEvent({
        actionType: 'category_delete',
        entityType: 'category',
        entityId: deleteTargetCat.id,
        entityLabel: deleteTargetCat.name,
        summary: `Deleted category "${deleteTargetCat.name}"`,
      });
      showToast(`Deleted category "${deleteTargetCat.name}".`, 'info');
      setDeleteTargetCat(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `categories/${deleteTargetCat.id}`);
    }
  };

  const handleCreatePromo = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = promoCode
      .toUpperCase()
      .trim()
      .replace(/[^A-Z0-9_-]/g, '');
    if (cleanCode.length < 2 || cleanCode.length > 32) {
      showToast('Coupon code must be 2–32 characters (A-Z, 0-9, _, -).', 'error');
      return;
    }
    if (promoPercent <= 0 || promoPercent > 90) {
      showToast('Discount percent must be between 1 and 90.', 'error');
      return;
    }
    setSavingPromo(true);
    try {
      await setDoc(doc(collection(db, 'promotions'), cleanCode), {
        code: cleanCode,
        discountPercent: Number(promoPercent),
        active: promoActive,
        description: promoDesc.trim().slice(0, 200),
        createdAt: serverTimestamp(),
      });
      await logAuditEvent({
        actionType: 'promotion_create',
        entityType: 'promotion',
        entityId: cleanCode,
        entityLabel: cleanCode,
        summary: `Created coupon ${cleanCode} (${promoPercent}% off)`,
      });
      setPromoCode('');
      setPromoPercent(10);
      setPromoDesc('');
      setPromoActive(true);
      showToast(`Coupon "${cleanCode}" saved.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `promotions/${cleanCode}`);
    } finally {
      setSavingPromo(false);
    }
  };

  const handleTogglePromo = async (promo: Promotion) => {
    try {
      await updateDoc(doc(db, 'promotions', promo.id), { active: !promo.active });
      await logAuditEvent({
        actionType: 'promotion_toggle',
        entityType: 'promotion',
        entityId: promo.id,
        entityLabel: promo.code,
        summary: `${!promo.active ? 'Activated' : 'Deactivated'} coupon ${promo.code}`,
      });
      showToast(`Coupon ${promo.code} ${!promo.active ? 'activated' : 'paused'}.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `promotions/${promo.id}`);
    }
  };

  const handleDeletePromo = async (promo: Promotion) => {
    try {
      await deleteDoc(doc(db, 'promotions', promo.id));
      await logAuditEvent({
        actionType: 'promotion_delete',
        entityType: 'promotion',
        entityId: promo.id,
        entityLabel: promo.code,
        summary: `Deleted coupon ${promo.code}`,
      });
      showToast(`Deleted coupon ${promo.code}.`, 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `promotions/${promo.id}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Categories Section */}
      <div className="rounded-3xl bg-white p-5 sm:p-6 shadow-sm border border-gray-100">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#FF6A00] flex items-center justify-center">
              <FolderKanban className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-display font-bold text-lg text-gray-900">
                Catalog Categories
              </h2>
              <p className="text-xs text-gray-500">
                Organize services across Social Media, Phone Services, and Custom Packages.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={openAddCategory}
            className="inline-flex items-center gap-1.5 rounded-xl bg-[#FF6A00] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#e85f00] transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Category
          </button>
        </div>

        <div className="divide-y divide-gray-100">
          {categories.map((cat, idx) => {
            const productCount = products.filter((p) => p.categoryId === cat.id).length;
            return (
              <div
                key={cat.id}
                className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold text-gray-900">{cat.name}</span>
                    <span className="font-mono-tabular text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-md">
                      {cat.slug}
                    </span>
                    <span className="text-xs font-medium text-[#0B4F5B] bg-teal-50 px-2 py-0.5 rounded-md">
                      {cat.group.replace('_', ' ')}
                    </span>
                    <span
                      className={`text-xs font-semibold px-2 py-0.5 rounded-md ${
                        cat.enabled
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-gray-100 text-gray-500'
                      }`}
                    >
                      {cat.enabled ? 'Enabled' : 'Disabled'}
                    </span>
                  </div>
                  {cat.description && (
                    <p className="text-xs text-gray-500 mt-1">{cat.description}</p>
                  )}
                  <p className="text-xs text-gray-400 mt-1 tabular-nums">
                    {productCount} product{productCount === 1 ? '' : 's'} assigned · Sort #{cat.sortOrder}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleMoveCategory(idx, -1)}
                    disabled={idx === 0}
                    title="Move up"
                    className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-30"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleMoveCategory(idx, 1)}
                    disabled={idx === categories.length - 1}
                    title="Move down"
                    className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-30"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleToggleCategory(cat)}
                    className="px-3 py-1.5 rounded-lg border border-gray-200 text-xs font-semibold text-gray-700 hover:bg-gray-50"
                  >
                    {cat.enabled ? 'Disable' : 'Enable'}
                  </button>
                  <button
                    type="button"
                    onClick={() => openEditCategory(cat)}
                    title="Edit category"
                    className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteTargetCat(cat)}
                    title="Delete category"
                    className="p-2 rounded-lg border border-red-200 text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Promotions & Coupon Codes Section */}
      <div className="rounded-3xl bg-white p-5 sm:p-6 shadow-sm border border-gray-100">
        <div className="flex items-center gap-2.5 mb-5">
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-[#0B4F5B] flex items-center justify-center">
            <Tag className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-display font-bold text-lg text-gray-900">
              Coupon Codes & Promotions
            </h2>
            <p className="text-xs text-gray-500">
              Customers can apply active codes in real time at checkout.
            </p>
          </div>
        </div>

        <form onSubmit={handleCreatePromo} className="grid grid-cols-1 sm:grid-cols-4 gap-3 mb-6 p-4 rounded-2xl bg-gray-50 border border-gray-200">
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">
              Coupon Code
            </label>
            <input
              type="text"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
              placeholder="e.g. LAUNCH15"
              required
              className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm font-mono-tabular focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">
              Discount (%)
            </label>
            <input
              type="number"
              min={1}
              max={90}
              value={promoPercent}
              onChange={(e) => setPromoPercent(Number(e.target.value))}
              required
              className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm tabular-nums focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">
              Description
            </label>
            <input
              type="text"
              value={promoDesc}
              onChange={(e) => setPromoDesc(e.target.value)}
              placeholder="Seasonal offer"
              className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
            />
          </div>
          <div className="flex items-end gap-2">
            <label className="inline-flex items-center gap-1.5 text-xs font-medium text-gray-700 mb-2.5">
              <input
                type="checkbox"
                checked={promoActive}
                onChange={(e) => setPromoActive(e.target.checked)}
                className="rounded border-gray-300 text-[#FF6A00] focus:ring-[#FF6A00]"
              />
              Active
            </label>
            <button
              type="submit"
              disabled={savingPromo}
              className="flex-1 rounded-xl bg-[#0B4F5B] px-4 py-2 text-sm font-semibold text-white hover:bg-[#093e48] disabled:opacity-50"
            >
              {savingPromo ? 'Saving...' : 'Add Coupon'}
            </button>
          </div>
        </form>

        {promotions.length === 0 ? (
          <p className="text-sm text-gray-500 text-center py-6">
            No coupon codes created yet.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {promotions.map((promo) => (
              <div
                key={promo.id}
                className="flex items-center justify-between gap-3 rounded-2xl border border-gray-200 p-4"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono-tabular font-bold text-sm text-gray-900">
                      {promo.code}
                    </span>
                    <span className="text-xs font-bold text-[#FF6A00] bg-orange-50 px-2 py-0.5 rounded-md tabular-nums">
                      {promo.discountPercent}% OFF
                    </span>
                    <span
                      className={`text-xs font-semibold px-2 py-0.5 rounded-md ${
                        promo.active
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-gray-100 text-gray-500'
                      }`}
                    >
                      {promo.active ? 'Active' : 'Paused'}
                    </span>
                  </div>
                  {promo.description && (
                    <p className="text-xs text-gray-500 mt-1">{promo.description}</p>
                  )}
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleTogglePromo(promo)}
                    className="px-2.5 py-1.5 rounded-lg border border-gray-200 text-xs font-semibold text-gray-700 hover:bg-gray-50"
                  >
                    {promo.active ? 'Pause' : 'Activate'}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeletePromo(promo)}
                    title="Delete coupon"
                    className="p-2 rounded-lg border border-red-200 text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add/Edit Category Modal */}
      {catModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-bold text-lg text-gray-900">
                {editingCat ? 'Edit Category' : 'Add Category'}
              </h3>
              <button
                type="button"
                onClick={() => setCatModalOpen(false)}
                className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveCategory} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Category Name
                </label>
                <input
                  type="text"
                  value={catName}
                  onChange={(e) => {
                    setCatName(e.target.value);
                    if (!editingCat) {
                      setCatSlug(normalizeSlug(e.target.value));
                    }
                  }}
                  required
                  className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Slug (lowercase letters, numbers, hyphens)
                </label>
                <input
                  type="text"
                  value={catSlug}
                  onChange={(e) => setCatSlug(normalizeSlug(e.target.value))}
                  required
                  className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm font-mono-tabular focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Department Group
                </label>
                <select
                  value={catGroup}
                  onChange={(e) => setCatGroup(e.target.value as CategoryGroup)}
                  className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                >
                  <option value="social_media">Social Media Services</option>
                  <option value="phone_services">Phone Number Services</option>
                  <option value="custom_packages">Custom Packages</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={catDesc}
                  onChange={(e) => setCatDesc(e.target.value)}
                  className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
                />
              </div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
                <input
                  type="checkbox"
                  checked={catEnabled}
                  onChange={(e) => setCatEnabled(e.target.checked)}
                  className="rounded border-gray-300 text-[#FF6A00] focus:ring-[#FF6A00]"
                />
                Enabled on Storefront
              </label>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCatModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-gray-200 text-sm font-semibold text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingCat}
                  className="px-5 py-2 rounded-xl bg-[#FF6A00] text-sm font-semibold text-white hover:bg-[#e85f00] disabled:opacity-50"
                >
                  {savingCat ? 'Saving...' : 'Save Category'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Category Confirmation Modal */}
      {deleteTargetCat && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl">
            <h3 className="font-display font-bold text-lg text-gray-900">Delete Category?</h3>
            <p className="text-sm text-gray-600 mt-2">
              Are you sure you want to remove <strong>{deleteTargetCat.name}</strong>? Existing products referencing this category should be reassigned.
            </p>
            <div className="flex justify-end gap-2 mt-5">
              <button
                type="button"
                onClick={() => setDeleteTargetCat(null)}
                className="px-4 py-2 rounded-xl border border-gray-200 text-sm font-semibold text-gray-700"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteCategory}
                className="px-4 py-2 rounded-xl bg-red-600 text-sm font-semibold text-white hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
