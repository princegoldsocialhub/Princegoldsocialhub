import React, { useEffect, useMemo, useRef, useState } from 'react';
import JsBarcode from 'jsbarcode';
import QRCode from 'qrcode';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import {
  Camera,
  CheckSquare,
  Download,
  Edit3,
  Eye,
  EyeOff,
  FileUp,
  History,
  Plus,
  Printer,
  RotateCcw,
  Square,
  Trash2,
  X,
  AlertCircle,
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { auth, db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { computeFieldDiffs, logAuditEvent } from '../../lib/audit';
import { downloadCsvFile, formatCurrency, formatDateTime, SKU_REGEX } from '../../lib/storeDefaults';
import {
  CategoryGroup,
  FulfillmentMethod,
  ImportChangeEntry,
  ImportErrorRow,
  ImportLog,
  Product,
  ScanHistoryEntry,
} from '../../types';
import { QRScannerModal } from './QRScannerModal';

const BarcodePreview: React.FC<{ sku: string; title: string }> = ({ sku, title }) => {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const qrCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (svgRef.current && sku) {
      try {
        JsBarcode(svgRef.current, sku, {
          format: 'CODE128',
          width: 1.6,
          height: 44,
          displayValue: true,
          fontSize: 11,
        });
      } catch {
        // ignore invalid barcode character
      }
    }
    if (qrCanvasRef.current && sku) {
      QRCode.toCanvas(qrCanvasRef.current, sku, { width: 96, margin: 1 }).catch(() => {});
    }
  }, [sku]);

  if (!sku) return null;

  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3 flex flex-wrap items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        <canvas ref={qrCanvasRef} className="rounded-lg bg-white p-1 border border-slate-200" />
        <div className="bg-white p-1.5 rounded-lg border border-slate-200">
          <svg ref={svgRef} />
        </div>
      </div>
      <button
        type="button"
        onClick={() => window.print()}
        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#0B4F5B] text-white text-xs font-semibold hover:bg-[#093f49]"
      >
        <Printer className="w-3.5 h-3.5" />
        Print Label ({title.slice(0, 14)})
      </button>
    </div>
  );
};

export const AdminCatalogTab: React.FC<{
  scanHistory: ScanHistoryEntry[];
  importLogs: ImportLog[];
}> = ({ scanHistory, importLogs }) => {
  const { products, categories, storeConfig, showToast } = useApp();

  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [skuError, setSkuError] = useState('');
  const [saving, setSaving] = useState(false);

  // Confirm delete modals
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null);
  const [bulkDeleteConfirm, setBulkDeleteConfirm] = useState(false);

  // Bulk editing controls
  const [bulkSkuPrefix, setBulkSkuPrefix] = useState('');
  const [bulkPrice, setBulkPrice] = useState('');
  const [bulkProcessing, setBulkProcessing] = useState(false);

  // CSV Import preview & error modal
  const [csvPreview, setCsvPreview] = useState<{
    fileName: string;
    totalRows: number;
    validUpdates: {
      product: Product;
      newSku: string;
      newPrice: number;
      newStock: number;
      newAvailable: boolean;
    }[];
    errors: ImportErrorRow[];
  } | null>(null);
  const [errorReportModalLog, setErrorReportModalLog] = useState<ImportLog | null>(null);
  const [changeHistoryModalLog, setChangeHistoryModalLog] = useState<ImportLog | null>(null);

  // QR Scanner
  const [scannerOpen, setScannerOpen] = useState(false);

  const openNewProductForm = () => {
    const firstCat = categories[0];
    setSkuError('');
    setEditingProduct({
      title: '',
      sku: '',
      description: '',
      categoryId: firstCat?.id || 'social-media-services',
      categoryGroup: firstCat?.group || 'social_media',
      price: 0,
      stock: 10,
      trackStock: true,
      published: true,
      available: true,
      fulfillmentMethod: 'digital_service',
      deliveryEstimate: '24-48 hours',
      terms: 'Lawful authorized service delivery only.',
      imageUrl: '',
    });
  };

  const handleImageUpload = (file: File) => {
    if (file.size > 2 * 1024 * 1024) {
      showToast('Please select an image smaller than 2MB.', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 480;
        const ratio = Math.min(1, maxDim / Math.max(img.width, img.height));
        canvas.width = Math.round(img.width * ratio);
        canvas.height = Math.round(img.height * ratio);
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.78);
          setEditingProduct((prev) => (prev ? { ...prev, imageUrl: dataUrl } : prev));
        }
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const validateSkuServerSide = async (sku: string, excludeProductId?: string): Promise<boolean> => {
    const idToken = await auth.currentUser?.getIdToken();
    const res = await fetch('/api/admin/validate-sku', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${idToken}`,
      },
      body: JSON.stringify({ sku, excludeProductId }),
    });
    const data = (await res.json()) as { unique?: boolean; error?: string };
    if (!res.ok || !data.unique) {
      setSkuError(data.error || 'SKU uniqueness check failed.');
      return false;
    }
    setSkuError('');
    return true;
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    const title = (editingProduct.title || '').trim();
    const sku = (editingProduct.sku || '').trim();
    if (!title) {
      showToast('Product title is required.', 'error');
      return;
    }
    if (!SKU_REGEX.test(sku)) {
      setSkuError('SKU must be 1-64 characters using letters, numbers, hyphens, or underscores.');
      return;
    }

    setSaving(true);
    try {
      const isUnique = await validateSkuServerSide(sku, editingProduct.id);
      if (!isUnique) {
        setSaving(false);
        return;
      }

      const isEdit = Boolean(editingProduct.id);
      const productRef = isEdit
        ? doc(db, 'products', editingProduct.id!)
        : doc(collection(db, 'products'));

      const previousProduct = isEdit ? products.find((p) => p.id === editingProduct.id) : null;
      const cat = categories.find((c) => c.id === editingProduct.categoryId);

      const payload = {
        title: title.slice(0, 120),
        sku: sku.slice(0, 64),
        description: (editingProduct.description || '').trim().slice(0, 2000),
        categoryId: editingProduct.categoryId || 'social-media-services',
        categoryGroup: (cat?.group || editingProduct.categoryGroup || 'social_media') as CategoryGroup,
        price: Math.max(0, Number(editingProduct.price || 0)),
        stock: Math.max(0, Math.floor(Number(editingProduct.stock || 0))),
        trackStock: Boolean(editingProduct.trackStock),
        published: Boolean(editingProduct.published),
        available: Boolean(editingProduct.available),
        fulfillmentMethod: (editingProduct.fulfillmentMethod || 'digital_service') as FulfillmentMethod,
        deliveryEstimate: (editingProduct.deliveryEstimate || '').trim().slice(0, 120),
        terms: (editingProduct.terms || '').trim().slice(0, 1500),
        imageUrl: (editingProduct.imageUrl || '').slice(0, 250000),
        updatedAt: serverTimestamp(),
      };

      const batch = writeBatch(db);
      if (isEdit && previousProduct) {
        if (previousProduct.sku.toUpperCase() !== sku.toUpperCase()) {
          batch.delete(doc(db, 'sku_index', previousProduct.sku.toUpperCase()));
        }
        batch.set(productRef, { ...payload, createdAt: previousProduct.createdAt || serverTimestamp() });
      } else {
        batch.set(productRef, { ...payload, createdAt: serverTimestamp() });
      }
      batch.set(doc(db, 'sku_index', sku.toUpperCase()), {
        productId: productRef.id,
        sku,
      });

      await batch.commit();

      const diffs = previousProduct
        ? computeFieldDiffs(
            previousProduct as unknown as Record<string, unknown>,
            payload as unknown as Record<string, unknown>,
            ['title', 'sku', 'price', 'stock', 'published', 'available', 'fulfillmentMethod']
          )
        : [];

      await logAuditEvent({
        actionType: isEdit ? 'product_update' : 'product_create',
        entityType: 'product',
        entityId: productRef.id,
        entityLabel: `${title} (${sku})`,
        changes: diffs,
        summary: isEdit ? `Updated product ${title}` : `Created new product ${title}`,
      });

      setEditingProduct(null);
      showToast(isEdit ? 'Product updated.' : 'Product created.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'products');
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'products', deleteTarget.id));
      batch.delete(doc(db, 'sku_index', deleteTarget.sku.toUpperCase()));
      await batch.commit();

      await logAuditEvent({
        actionType: 'product_delete',
        entityType: 'product',
        entityId: deleteTarget.id,
        entityLabel: `${deleteTarget.title} (${deleteTarget.sku})`,
        summary: `Deleted product ${deleteTarget.title}`,
      });

      setDeleteTarget(null);
      setSelectedIds((prev) => prev.filter((id) => id !== deleteTarget.id));
      showToast('Product deleted.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `products/${deleteTarget.id}`);
    }
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === products.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(products.map((p) => p.id));
    }
  };

  const handleBulkAvailability = async (available: boolean) => {
    if (selectedIds.length === 0) return;
    setBulkProcessing(true);
    try {
      const batch = writeBatch(db);
      for (const id of selectedIds) {
        batch.update(doc(db, 'products', id), { available, updatedAt: serverTimestamp() });
      }
      await batch.commit();
      await logAuditEvent({
        actionType: 'bulk_update',
        entityType: 'product',
        entityId: selectedIds.join(',').slice(0, 128),
        entityLabel: `${selectedIds.length} products`,
        summary: `Bulk set availability=${available} on ${selectedIds.length} products.`,
      });
      showToast(`Updated availability on ${selectedIds.length} products.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'products');
    } finally {
      setBulkProcessing(false);
    }
  };

  const handleBulkPriceUpdate = async () => {
    const newPrice = Number(bulkPrice);
    if (selectedIds.length === 0 || Number.isNaN(newPrice) || newPrice < 0) return;
    setBulkProcessing(true);
    try {
      const batch = writeBatch(db);
      for (const id of selectedIds) {
        batch.update(doc(db, 'products', id), { price: newPrice, updatedAt: serverTimestamp() });
      }
      await batch.commit();
      await logAuditEvent({
        actionType: 'bulk_update',
        entityType: 'product',
        entityId: selectedIds.join(',').slice(0, 128),
        entityLabel: `${selectedIds.length} products`,
        summary: `Bulk updated price to ${newPrice} on ${selectedIds.length} products.`,
      });
      setBulkPrice('');
      showToast(`Updated price on ${selectedIds.length} products.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'products');
    } finally {
      setBulkProcessing(false);
    }
  };

  const handleBulkSkuPrefix = async () => {
    const prefix = bulkSkuPrefix.trim().toUpperCase();
    if (!prefix || !SKU_REGEX.test(prefix) || selectedIds.length === 0) {
      showToast('Enter a valid alphanumeric SKU prefix.', 'error');
      return;
    }
    setBulkProcessing(true);
    try {
      const selectedProducts = products.filter((p) => selectedIds.includes(p.id));
      const existingUpperSet = new Set(products.map((p) => p.sku.toUpperCase()));
      const batch = writeBatch(db);

      for (const p of selectedProducts) {
        const cleanBase = p.sku.replace(/^[A-Z0-9]+-/, '');
        const newSku = `${prefix}-${cleanBase}`.slice(0, 64);
        if (newSku.toUpperCase() !== p.sku.toUpperCase() && existingUpperSet.has(newSku.toUpperCase())) {
          showToast(`Prefix collision on ${newSku}. Operation aborted.`, 'error');
          setBulkProcessing(false);
          return;
        }
        batch.delete(doc(db, 'sku_index', p.sku.toUpperCase()));
        batch.set(doc(db, 'sku_index', newSku.toUpperCase()), { productId: p.id, sku: newSku });
        batch.update(doc(db, 'products', p.id), { sku: newSku, updatedAt: serverTimestamp() });
      }

      await batch.commit();
      await logAuditEvent({
        actionType: 'bulk_update',
        entityType: 'product',
        entityId: selectedIds.join(',').slice(0, 128),
        entityLabel: `${selectedIds.length} products`,
        summary: `Batch updated SKU prefix to ${prefix}- for ${selectedIds.length} products.`,
      });
      setBulkSkuPrefix('');
      showToast(`Updated SKU prefix on ${selectedIds.length} products.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'products');
    } finally {
      setBulkProcessing(false);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedIds.length === 0) return;
    setBulkProcessing(true);
    try {
      const batch = writeBatch(db);
      for (const id of selectedIds) {
        const p = products.find((item) => item.id === id);
        batch.delete(doc(db, 'products', id));
        if (p) batch.delete(doc(db, 'sku_index', p.sku.toUpperCase()));
      }
      await batch.commit();
      await logAuditEvent({
        actionType: 'product_delete',
        entityType: 'product',
        entityId: selectedIds.join(',').slice(0, 128),
        entityLabel: `${selectedIds.length} products`,
        summary: `Bulk deleted ${selectedIds.length} products.`,
      });
      setSelectedIds([]);
      setBulkDeleteConfirm(false);
      showToast('Selected products deleted.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'products');
    } finally {
      setBulkProcessing(false);
    }
  };

  // CSV Template & SKU Export
  const handleDownloadTemplate = () => {
    downloadCsvFile(
      'princegold-sku-import-template.csv',
      ['current_sku', 'new_sku', 'price', 'stock', 'available'],
      products.length > 0
        ? products.slice(0, 3).map((p) => [p.sku, p.sku, p.price, p.stock, p.available ? 'true' : 'false'])
        : [['SMM-PACK-01', 'SMM-PACK-01', '15000', '20', 'true']]
    );
  };

  const handleExportSkuData = () => {
    downloadCsvFile(
      `princegold-sku-inventory-${new Date().toISOString().slice(0, 10)}.csv`,
      ['SKU', 'Title', 'Price', 'Stock', 'Available', 'Published'],
      products.map((p) => [p.sku, p.title, p.price, p.stock, p.available, p.published])
    );
  };

  // CSV Import Parsing & Preview
  const handleCsvFileSelect = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result || '');
      const lines = text.split(/\r?\n/).filter((l) => l.trim());
      if (lines.length < 2) {
        showToast('CSV file must include a header row and at least one data row.', 'error');
        return;
      }

      const validUpdates: NonNullable<typeof csvPreview>['validUpdates'] = [];
      const errors: ImportErrorRow[] = [];
      const seenNewSkus = new Set<string>();

      for (let i = 1; i < lines.length; i++) {
        const cols = lines[i].split(',').map((c) => c.trim().replace(/^"|"$/g, ''));
        const [currentSku, newSkuRaw, priceRaw, stockRaw, availRaw] = cols;
        const target = products.find((p) => p.sku.toUpperCase() === (currentSku || '').toUpperCase());
        if (!target) {
          errors.push({
            rowNumber: i + 1,
            sku: currentSku || '(empty)',
            reason: 'Existing product SKU not found in catalog.',
          });
          continue;
        }
        const newSku = (newSkuRaw || currentSku).trim();
        if (!SKU_REGEX.test(newSku)) {
          errors.push({
            rowNumber: i + 1,
            sku: newSku,
            reason: 'Invalid SKU format.',
          });
          continue;
        }
        const newSkuUpper = newSku.toUpperCase();
        const conflict = products.find(
          (p) => p.sku.toUpperCase() === newSkuUpper && p.id !== target.id
        );
        if (conflict || seenNewSkus.has(newSkuUpper)) {
          errors.push({
            rowNumber: i + 1,
            sku: newSku,
            reason: `Duplicate/conflicting SKU with "${conflict?.title || 'CSV row'}".`,
          });
          continue;
        }
        const newPrice = Number(priceRaw);
        const newStock = Number(stockRaw);
        if (Number.isNaN(newPrice) || newPrice < 0 || Number.isNaN(newStock) || newStock < 0) {
          errors.push({
            rowNumber: i + 1,
            sku: currentSku,
            reason: 'Invalid numeric price or stock level.',
          });
          continue;
        }
        seenNewSkus.add(newSkuUpper);
        validUpdates.push({
          product: target,
          newSku,
          newPrice,
          newStock: Math.floor(newStock),
          newAvailable: availRaw ? availRaw.toLowerCase() === 'true' : target.available,
        });
      }

      setCsvPreview({
        fileName: file.name,
        totalRows: lines.length - 1,
        validUpdates,
        errors,
      });
    };
    reader.readAsText(file);
  };

  const applyCsvImport = async () => {
    if (!csvPreview) return;
    setBulkProcessing(true);
    try {
      const importRef = doc(collection(db, 'import_logs'));
      const snapshotRef = doc(collection(db, 'import_snapshots'));

      // Take pre-import snapshot for Rollback
      const preImportSnapshot = csvPreview.validUpdates.map((u) => ({
        id: u.product.id,
        sku: u.product.sku,
        price: u.product.price,
        stock: u.product.stock,
        available: u.product.available,
      }));

      const changes: ImportChangeEntry[] = [];
      const batch = writeBatch(db);

      batch.set(snapshotRef, {
        importId: importRef.id,
        products: preImportSnapshot.slice(0, 200),
        createdAt: serverTimestamp(),
      });

      for (const u of csvPreview.validUpdates) {
        if (u.product.sku !== u.newSku) {
          changes.push({ productId: u.product.id, sku: u.product.sku, field: 'sku', before: u.product.sku, after: u.newSku });
          batch.delete(doc(db, 'sku_index', u.product.sku.toUpperCase()));
          batch.set(doc(db, 'sku_index', u.newSku.toUpperCase()), { productId: u.product.id, sku: u.newSku });
        }
        if (u.product.price !== u.newPrice) {
          changes.push({ productId: u.product.id, sku: u.newSku, field: 'price', before: String(u.product.price), after: String(u.newPrice) });
        }
        if (u.product.stock !== u.newStock) {
          changes.push({ productId: u.product.id, sku: u.newSku, field: 'stock', before: String(u.product.stock), after: String(u.newStock) });
        }
        if (u.product.available !== u.newAvailable) {
          changes.push({ productId: u.product.id, sku: u.newSku, field: 'available', before: String(u.product.available), after: String(u.newAvailable) });
        }

        batch.update(doc(db, 'products', u.product.id), {
          sku: u.newSku,
          price: u.newPrice,
          stock: u.newStock,
          available: u.newAvailable,
          updatedAt: serverTimestamp(),
        });
      }

      const status: ImportLog['status'] =
        csvPreview.validUpdates.length === 0
          ? 'failed'
          : csvPreview.errors.length > 0
          ? 'partial_failure'
          : 'success';

      batch.set(importRef, {
        fileName: csvPreview.fileName.slice(0, 160),
        status,
        totalRows: csvPreview.totalRows,
        updatedCount: csvPreview.validUpdates.length,
        errorCount: csvPreview.errors.length,
        errors: csvPreview.errors.slice(0, 50),
        changes: changes.slice(0, 50),
        snapshotId: snapshotRef.id,
        actorEmail: (auth.currentUser?.email || 'admin').slice(0, 160),
        createdAt: serverTimestamp(),
      });

      await batch.commit();
      await logAuditEvent({
        actionType: 'csv_import',
        entityType: 'import',
        entityId: importRef.id,
        entityLabel: csvPreview.fileName,
        summary: `CSV Import "${csvPreview.fileName}": ${csvPreview.validUpdates.length} updated, ${csvPreview.errors.length} failed.`,
      });

      setCsvPreview(null);
      showToast('CSV import processed and logged.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'import_logs');
    } finally {
      setBulkProcessing(false);
    }
  };

  const handleRollbackImport = async (log: ImportLog) => {
    if (!log.snapshotId) return;
    setBulkProcessing(true);
    try {
      const { getDoc } = await import('firebase/firestore');
      const snapDoc = await getDoc(doc(db, 'import_snapshots', log.snapshotId));
      if (!snapDoc.exists()) {
        showToast('Snapshot not found for rollback.', 'error');
        return;
      }
      const snapshotData = snapDoc.data() as {
        products: { id: string; sku: string; price: number; stock: number; available: boolean }[];
      };
      const batch = writeBatch(db);
      for (const prev of snapshotData.products || []) {
        const current = products.find((p) => p.id === prev.id);
        if (!current) continue;
        if (current.sku.toUpperCase() !== prev.sku.toUpperCase()) {
          batch.delete(doc(db, 'sku_index', current.sku.toUpperCase()));
          batch.set(doc(db, 'sku_index', prev.sku.toUpperCase()), { productId: prev.id, sku: prev.sku });
        }
        batch.update(doc(db, 'products', prev.id), {
          sku: prev.sku,
          price: prev.price,
          stock: prev.stock,
          available: prev.available,
          updatedAt: serverTimestamp(),
        });
      }
      batch.update(doc(db, 'import_logs', log.id), { status: 'rolled_back' });
      await batch.commit();

      await logAuditEvent({
        actionType: 'csv_rollback',
        entityType: 'import',
        entityId: log.id,
        entityLabel: log.fileName,
        summary: `Rolled back CSV import "${log.fileName}".`,
      });
      showToast(`Rolled back "${log.fileName}" successfully.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'products');
    } finally {
      setBulkProcessing(false);
    }
  };

  const last10Scans = useMemo(() => scanHistory.slice(0, 10), [scanHistory]);
  const last10ChartData = useMemo(
    () =>
      [...last10Scans].reverse().map((s, idx) => ({
        name: `#${idx + 1} (${s.sku})`,
        accuracy: s.accuracyScore,
        durationMs: s.durationMs,
      })),
    [last10Scans]
  );

  return (
    <div className="space-y-5">
      {/* Toolbar */}
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Catalog &amp; Inventory Management</h2>
          <p className="text-xs text-slate-500">
            Add listings, enforce server-unique SKUs, bulk edit, import/export CSV, and scan QR labels
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleDownloadTemplate}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
          >
            <Download className="w-3.5 h-3.5" />
            Download CSV Template
          </button>
          <button
            type="button"
            onClick={handleExportSkuData}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
          >
            <Download className="w-3.5 h-3.5" />
            Export SKU Data
          </button>
          <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#0B4F5B]/30 text-xs font-semibold text-[#0B4F5B] hover:bg-teal-50 cursor-pointer">
            <FileUp className="w-3.5 h-3.5" />
            Import CSV
            <input
              type="file"
              accept=".csv,text/csv"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleCsvFileSelect(file);
                e.target.value = '';
              }}
            />
          </label>
          <button
            type="button"
            onClick={openNewProductForm}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#FF6A00] text-white text-xs font-bold hover:bg-[#e55f00]"
          >
            <Plus className="w-4 h-4" />
            Add Product
          </button>
        </div>
      </div>

      {/* Bulk Action Bar */}
      {selectedIds.length > 0 && (
        <div className="bg-[#0B4F5B] text-white rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-sm">
          <span className="text-xs font-bold">{selectedIds.length} product(s) selected</span>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={bulkProcessing}
              onClick={() => handleBulkAvailability(true)}
              className="px-3 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-xs font-semibold"
            >
              Set Available
            </button>
            <button
              type="button"
              disabled={bulkProcessing}
              onClick={() => handleBulkAvailability(false)}
              className="px-3 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-xs font-semibold"
            >
              Set Unavailable
            </button>
            <div className="flex items-center gap-1">
              <input
                type="number"
                value={bulkPrice}
                onChange={(e) => setBulkPrice(e.target.value)}
                placeholder="New price"
                className="w-24 px-2 py-1 rounded-lg bg-white text-slate-900 text-xs"
              />
              <button
                type="button"
                disabled={bulkProcessing}
                onClick={handleBulkPriceUpdate}
                className="px-2.5 py-1 rounded-lg bg-[#FF6A00] text-xs font-semibold"
              >
                Set Price
              </button>
            </div>
            <div className="flex items-center gap-1">
              <input
                type="text"
                value={bulkSkuPrefix}
                onChange={(e) => setBulkSkuPrefix(e.target.value.toUpperCase())}
                placeholder="SKU Prefix"
                className="w-24 px-2 py-1 rounded-lg bg-white text-slate-900 text-xs font-mono-tabular uppercase"
              />
              <button
                type="button"
                disabled={bulkProcessing}
                onClick={handleBulkSkuPrefix}
                className="px-2.5 py-1 rounded-lg bg-[#FF6A00] text-xs font-semibold"
              >
                Batch Prefix
              </button>
            </div>
            <button
              type="button"
              disabled={bulkProcessing}
              onClick={() => setBulkDeleteConfirm(true)}
              className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-xs font-semibold"
            >
              Delete Selected
            </button>
          </div>
        </div>
      )}

      {/* Product List Table */}
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs">
        {products.length === 0 ? (
          <div className="py-10 text-center space-y-3">
            <p className="text-sm font-semibold text-slate-700">No catalog listings yet</p>
            <p className="text-xs text-slate-500">
              Click &ldquo;Add Product&rdquo; above to publish your first legitimate social media
              service or lawful business phone number package.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-500">
                  <th className="py-2.5 pr-2">
                    <button type="button" onClick={toggleSelectAll} aria-label="Select all">
                      {selectedIds.length === products.length ? (
                        <CheckSquare className="w-4 h-4 text-[#FF6A00]" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </th>
                  <th className="py-2.5 pr-3">Product</th>
                  <th className="py-2.5 pr-3">SKU</th>
                  <th className="py-2.5 pr-3">Price</th>
                  <th className="py-2.5 pr-3">Stock</th>
                  <th className="py-2.5 pr-3">Visibility</th>
                  <th className="py-2.5">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {products.map((p) => {
                  const checked = selectedIds.includes(p.id);
                  return (
                    <tr key={p.id} className="hover:bg-slate-50/70">
                      <td className="py-3 pr-2">
                        <button
                          type="button"
                          onClick={() =>
                            setSelectedIds((prev) =>
                              prev.includes(p.id)
                                ? prev.filter((id) => id !== p.id)
                                : [...prev, p.id]
                            )
                          }
                        >
                          {checked ? (
                            <CheckSquare className="w-4 h-4 text-[#FF6A00]" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-400" />
                          )}
                        </button>
                      </td>
                      <td className="py-3 pr-3 font-semibold text-slate-900">{p.title}</td>
                      <td className="py-3 pr-3 font-mono-tabular text-slate-600">{p.sku}</td>
                      <td className="py-3 pr-3 tabular-nums font-semibold text-[#0B4F5B]">
                        {formatCurrency(p.price, storeConfig.currencySymbol)}
                      </td>
                      <td className="py-3 pr-3 tabular-nums">
                        {p.trackStock ? p.stock : 'Unlimited'}
                      </td>
                      <td className="py-3 pr-3">
                        <span className={p.published ? 'text-emerald-700 font-semibold' : 'text-slate-400'}>
                          {p.published ? 'Published' : 'Hidden'}
                        </span>
                      </td>
                      <td className="py-3">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={async () => {
                              await updateDoc(doc(db, 'products', p.id), {
                                published: !p.published,
                                updatedAt: serverTimestamp(),
                              });
                              await logAuditEvent({
                                actionType: 'product_update',
                                entityType: 'product',
                                entityId: p.id,
                                entityLabel: p.title,
                                summary: `${p.published ? 'Hid' : 'Published'} ${p.title}`,
                              });
                            }}
                            className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600"
                            title={p.published ? 'Hide listing' : 'Publish listing'}
                          >
                            {p.published ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setSkuError('');
                              setEditingProduct({ ...p });
                            }}
                            className="p-1.5 rounded-lg hover:bg-slate-100 text-[#0B4F5B]"
                            title="Edit product"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteTarget(p)}
                            className="p-1.5 rounded-lg hover:bg-red-50 text-red-600"
                            title="Delete product"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Recent CSV Imports Log */}
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-[#FF6A00]" />
          <h3 className="text-base font-bold text-slate-900">Recent CSV Imports</h3>
        </div>
        {importLogs.length === 0 ? (
          <p className="text-xs text-slate-500">No CSV batch imports recorded yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-500">
                  <th className="py-2 pr-3">Date</th>
                  <th className="py-2 pr-3">File Name</th>
                  <th className="py-2 pr-3">Result</th>
                  <th className="py-2 pr-3">Summary</th>
                  <th className="py-2">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {importLogs.map((log) => (
                  <tr key={log.id}>
                    <td className="py-2.5 pr-3 text-slate-500">{formatDateTime(log.createdAt)}</td>
                    <td className="py-2.5 pr-3 font-semibold text-slate-800">{log.fileName}</td>
                    <td className="py-2.5 pr-3 font-semibold capitalize">
                      <span
                        className={
                          log.status === 'success'
                            ? 'text-emerald-700'
                            : log.status === 'rolled_back'
                            ? 'text-slate-500'
                            : 'text-red-600'
                        }
                      >
                        {log.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-2.5 pr-3 tabular-nums">
                      {log.updatedCount} updated / {log.errorCount} errors
                    </td>
                    <td className="py-2.5 flex flex-wrap items-center gap-2">
                      {log.errorCount > 0 && (
                        <button
                          type="button"
                          onClick={() => setErrorReportModalLog(log)}
                          className="text-red-600 font-semibold hover:underline"
                        >
                          Error Report
                        </button>
                      )}
                      {log.changes?.length > 0 && (
                        <button
                          type="button"
                          onClick={() => setChangeHistoryModalLog(log)}
                          className="text-[#0B4F5B] font-semibold hover:underline"
                        >
                          Change History
                        </button>
                      )}
                      {log.status !== 'rolled_back' && log.updatedCount > 0 && (
                        <button
                          type="button"
                          disabled={bulkProcessing}
                          onClick={() => handleRollbackImport(log)}
                          className="inline-flex items-center gap-1 text-[#FF6A00] font-semibold hover:underline"
                        >
                          <RotateCcw className="w-3 h-3" /> Rollback
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Scan History Log (Last 10 Scans + Recharts Accuracy Line Chart + CSV Export) */}
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900">Recent QR/Barcode Scan History</h3>
            <p className="text-xs text-slate-500">
              Last 10 scanned items with identification duration and accuracy trend
            </p>
          </div>
          {scanHistory.length > 0 && (
            <button
              type="button"
              onClick={() =>
                downloadCsvFile(
                  'princegold-scan-history.csv',
                  ['Date', 'SKU', 'Product', 'Duration (ms)', 'Accuracy (%)'],
                  scanHistory.map((s) => [
                    formatDateTime(s.createdAt),
                    s.sku,
                    s.productTitle,
                    s.durationMs,
                    s.accuracyScore,
                  ])
                )
              }
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              <Download className="w-3.5 h-3.5" />
              Export to CSV
            </button>
          )}
        </div>

        {last10Scans.length === 0 ? (
          <p className="text-xs text-slate-500">
            No scans yet. Tap the floating &ldquo;Scan Product&rdquo; button below to scan a label.
          </p>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-center">
            <div className="divide-y divide-slate-100 text-xs">
              {last10Scans.map((s) => (
                <div key={s.id} className="py-2 flex items-center justify-between gap-2">
                  <div>
                    <span className="font-semibold text-slate-900">{s.productTitle}</span>
                    <span className="ml-2 font-mono-tabular text-slate-400">{s.sku}</span>
                  </div>
                  <div className="tabular-nums text-slate-600">
                    {s.durationMs}ms · <strong className="text-[#0B4F5B]">{s.accuracyScore}%</strong>
                  </div>
                </div>
              ))}
            </div>

            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={last10ChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: '#64748b' }} />
                  <Tooltip
                    formatter={(value, _name, item) => [
                      `${Number(value ?? 0)}% (${((item?.payload as { durationMs?: number } | undefined)?.durationMs ?? 0)}ms)`,
                      'Scan Accuracy',
                    ]}
                    contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '11px' }}
                  />
                  <Line type="monotone" dataKey="accuracy" stroke="#FF6A00" strokeWidth={2.5} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </div>

      {/* Floating Scan Product Button */}
      <button
        type="button"
        onClick={() => setScannerOpen(true)}
        className="fixed bottom-20 left-4 lg:bottom-6 lg:left-72 z-30 inline-flex items-center gap-2 px-4 py-3 rounded-full bg-[#FF6A00] text-white text-xs font-bold shadow-lg shadow-[#FF6A00]/30 hover:bg-[#e55f00] transition-transform active:scale-95"
      >
        <Camera className="w-4 h-4" />
        Scan Product
      </button>

      {/* Add / Edit Product Modal (with Barcode/QR Generator) */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900">
                {editingProduct.id ? 'Edit Listing' : 'Add Catalog Listing'}
              </h3>
              <button
                type="button"
                onClick={() => setEditingProduct(null)}
                className="p-2 rounded-xl hover:bg-slate-100 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Product / Service Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={editingProduct.title || ''}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, title: e.target.value })
                    }
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Inventory SKU (Unique) *
                  </label>
                  <input
                    type="text"
                    required
                    value={editingProduct.sku || ''}
                    onChange={(e) => {
                      setSkuError('');
                      setEditingProduct({ ...editingProduct, sku: e.target.value.toUpperCase() });
                    }}
                    placeholder="e.g., PGH-SMM-001"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-mono-tabular text-sm uppercase"
                  />
                  {skuError && <p className="mt-1 text-xs text-red-600">{skuError}</p>}
                </div>
              </div>

              {editingProduct.sku && (
                <BarcodePreview sku={editingProduct.sku} title={editingProduct.title || 'Item'} />
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={editingProduct.categoryId || ''}
                    onChange={(e) => {
                      const cat = categories.find((c) => c.id === e.target.value);
                      setEditingProduct({
                        ...editingProduct,
                        categoryId: e.target.value,
                        categoryGroup: cat?.group || 'social_media',
                      });
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm bg-white"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Price ({storeConfig.currencySymbol})
                  </label>
                  <input
                    type="number"
                    min={0}
                    step="0.01"
                    value={editingProduct.price ?? 0}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, price: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Stock Count
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={editingProduct.stock ?? 0}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, stock: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Fulfillment Method
                  </label>
                  <select
                    value={editingProduct.fulfillmentMethod || 'digital_service'}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        fulfillmentMethod: e.target.value as FulfillmentMethod,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm bg-white"
                  >
                    <option value="digital_service">Digital Service (Marketing/Design)</option>
                    <option value="phone_provisioning">Lawful Phone/eSIM Provisioning</option>
                    <option value="physical_product">Physical Product (Requires Shipping)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Delivery Estimate
                  </label>
                  <input
                    type="text"
                    value={editingProduct.deliveryEstimate || ''}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, deliveryEstimate: e.target.value })
                    }
                    placeholder="e.g., 24-48 hours"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Description
                </label>
                <textarea
                  rows={3}
                  value={editingProduct.description || ''}
                  onChange={(e) =>
                    setEditingProduct({ ...editingProduct, description: e.target.value })
                  }
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Terms &amp; Lawful Use Notice
                </label>
                <textarea
                  rows={2}
                  value={editingProduct.terms || ''}
                  onChange={(e) =>
                    setEditingProduct({ ...editingProduct, terms: e.target.value })
                  }
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Product Image (Upload or URL)
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="text"
                    value={editingProduct.imageUrl || ''}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, imageUrl: e.target.value })
                    }
                    placeholder="https://... or upload an image file"
                    className="flex-1 px-3.5 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                  <label className="px-3 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-semibold cursor-pointer hover:bg-slate-200">
                    Upload Image
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) handleImageUpload(f);
                      }}
                    />
                  </label>
                </div>
              </div>

              <div className="flex flex-wrap gap-4 text-xs font-semibold text-slate-700">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={Boolean(editingProduct.published)}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, published: e.target.checked })
                    }
                    className="accent-[#FF6A00]"
                  />
                  Published to Storefront
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={Boolean(editingProduct.available)}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, available: e.target.checked })
                    }
                    className="accent-[#FF6A00]"
                  />
                  Available for Purchase
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={Boolean(editingProduct.trackStock)}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, trackStock: e.target.checked })
                    }
                    className="accent-[#FF6A00]"
                  />
                  Track Stock &amp; Low-Stock Alerts
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 rounded-xl bg-[#FF6A00] text-white text-xs font-bold hover:bg-[#e55f00] disabled:opacity-60"
                >
                  {saving ? 'Validating & Saving...' : 'Save Listing'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-slate-900">Delete Product Listing?</h3>
            <p className="text-xs text-slate-600">
              Are you sure you want to permanently delete <strong>{deleteTarget.title}</strong> (SKU:{' '}
              {deleteTarget.sku})?
            </p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-xl bg-red-600 text-white text-xs font-bold hover:bg-red-700"
              >
                Delete Listing
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Delete Confirmation Modal */}
      {bulkDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-slate-900">Delete {selectedIds.length} Selected Listings?</h3>
            <p className="text-xs text-slate-600">
              This action permanently removes all selected outdated or discontinued products from the
              catalog.
            </p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setBulkDeleteConfirm(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleBulkDelete}
                className="px-4 py-2 rounded-xl bg-red-600 text-white text-xs font-bold hover:bg-red-700"
              >
                Delete All Selected
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CSV Preview Modal */}
      {csvPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-3xl bg-white p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                CSV Import Preview: {csvPreview.fileName}
              </h3>
              <button
                type="button"
                onClick={() => setCsvPreview(null)}
                className="p-2 rounded-xl hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3 text-xs">
              <div className="rounded-xl bg-slate-50 p-3">
                <div className="text-slate-500">Total Rows</div>
                <div className="text-lg font-bold tabular-nums">{csvPreview.totalRows}</div>
              </div>
              <div className="rounded-xl bg-emerald-50 p-3">
                <div className="text-emerald-700">Valid Updates</div>
                <div className="text-lg font-bold text-emerald-800 tabular-nums">
                  {csvPreview.validUpdates.length}
                </div>
              </div>
              <div className="rounded-xl bg-red-50 p-3">
                <div className="text-red-700">Row Errors</div>
                <div className="text-lg font-bold text-red-800 tabular-nums">
                  {csvPreview.errors.length}
                </div>
              </div>
            </div>
            {csvPreview.errors.length > 0 && (
              <div className="rounded-xl bg-red-50 border border-red-200 p-3 text-xs text-red-800 space-y-1">
                <div className="font-bold">Errors detected (skipped on apply):</div>
                {csvPreview.errors.map((er, i) => (
                  <div key={i}>
                    Row {er.rowNumber} ({er.sku}): {er.reason}
                  </div>
                ))}
              </div>
            )}
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setCsvPreview(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={bulkProcessing}
                onClick={applyCsvImport}
                className="px-4 py-2 rounded-xl bg-[#FF6A00] text-white text-xs font-bold hover:bg-[#e55f00]"
              >
                Apply Batch Update ({csvPreview.validUpdates.length})
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Detailed Import Error Report Modal */}
      {errorReportModalLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-red-600" />
                <h3 className="text-base font-bold text-slate-900">
                  Import Error Report: {errorReportModalLog.fileName}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setErrorReportModalLog(null)}
                className="p-2 rounded-xl hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 text-xs">
              {errorReportModalLog.errors.map((er, idx) => (
                <div key={idx} className="py-2.5">
                  <span className="font-bold text-slate-900">Row {er.rowNumber}</span> ·{' '}
                  <span className="font-mono-tabular text-red-700">{er.sku}</span>: {er.reason}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Import Change History Before/After Modal */}
      {changeHistoryModalLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-xl rounded-3xl bg-white p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                Import Change History: {changeHistoryModalLog.fileName}
              </h3>
              <button
                type="button"
                onClick={() => setChangeHistoryModalLog(null)}
                className="p-2 rounded-xl hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="max-h-72 overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-500">
                    <th className="py-2 pr-2">SKU</th>
                    <th className="py-2 pr-2">Field</th>
                    <th className="py-2 pr-2">Before</th>
                    <th className="py-2">After</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {changeHistoryModalLog.changes.map((c, idx) => (
                    <tr key={idx}>
                      <td className="py-2 pr-2 font-mono-tabular">{c.sku}</td>
                      <td className="py-2 pr-2 font-semibold">{c.field}</td>
                      <td className="py-2 pr-2 text-red-600">{c.before}</td>
                      <td className="py-2 text-emerald-700 font-semibold">{c.after}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      <QRScannerModal
        open={scannerOpen}
        onClose={() => setScannerOpen(false)}
        products={products}
        onProductIdentified={(found) => {
          setEditingProduct({ ...found });
        }}
      />
    </div>
  );
};
