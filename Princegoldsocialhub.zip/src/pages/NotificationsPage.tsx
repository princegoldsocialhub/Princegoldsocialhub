import React from 'react';
import { Bell, CheckCheck, ArrowRight, BellRing } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { formatDateTime } from '../lib/storeDefaults';

export const NotificationsPage: React.FC = () => {
  const {
    user,
    notifications,
    unreadCount,
    markNotificationRead,
    markAllNotificationsRead,
    openOrderTracking,
    setPushModalOpen,
    setCurrentPage,
  } = useApp();

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Notification Center</h1>
          <p className="text-xs text-slate-500">
            Real-time order status alerts &amp; fulfillment updates ({unreadCount} unread)
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {user && (
            <button
              type="button"
              onClick={() => setPushModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              <BellRing className="w-3.5 h-3.5 text-[#FF6A00]" />
              Push Alert Settings
            </button>
          )}
          {user && unreadCount > 0 && (
            <button
              type="button"
              onClick={markAllNotificationsRead}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#0B4F5B] text-white text-xs font-semibold hover:bg-[#093f49]"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              Mark all as read
            </button>
          )}
        </div>
      </div>

      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs">
        {!user ? (
          <div className="py-10 text-center space-y-3">
            <Bell className="w-9 h-9 text-slate-300 mx-auto" />
            <p className="text-sm text-slate-600">
              Sign in to view your order status notifications and enable push alerts.
            </p>
            <button
              type="button"
              onClick={() => setCurrentPage('profile')}
              className="px-4 py-2 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold"
            >
              Sign In
            </button>
          </div>
        ) : notifications.length === 0 ? (
          <div className="py-10 text-center space-y-2">
            <Bell className="w-9 h-9 text-slate-300 mx-auto" />
            <p className="text-sm font-medium text-slate-700">No notifications yet</p>
            <p className="text-xs text-slate-500">
              When an admin updates one of your orders, you will see an instant alert here.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {notifications.map((notif) => (
              <button
                key={notif.id}
                type="button"
                onClick={async () => {
                  if (!notif.read) {
                    await markNotificationRead(notif.id);
                  }
                  openOrderTracking(notif.orderNumber);
                }}
                className={`w-full text-left py-4 px-3 rounded-2xl transition-colors flex items-start justify-between gap-4 hover:bg-slate-50 ${
                  !notif.read ? 'bg-orange-50/40' : ''
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs">
                    {!notif.read && (
                      <span className="font-bold text-[#FF6A00]">New</span>
                    )}
                    <span className="font-mono-tabular font-semibold text-[#0B4F5B]">
                      {notif.orderNumber}
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="text-slate-400">{formatDateTime(notif.createdAt)}</span>
                  </div>
                  <div className="text-sm font-bold text-slate-900">{notif.title}</div>
                  <p className="text-xs text-slate-600">{notif.body}</p>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 shrink-0 mt-1" />
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
