import React, { useMemo, useState } from 'react';
import {
  Search,
  Heart,
  Scale,
  ShoppingBag,
  Clock,
  SlidersHorizontal,
  PackageOpen,
  ShieldAlert,
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { formatCurrency } from '../lib/storeDefaults';
import { ProductVisual } from '../components/BrandVisuals';
import { CategoryGroup } from '../types';

export const CatalogPage: React.FC = () => {
  const {
    isAdmin,
    products,
    productsLoading,
    categories,
    storeConfig,
    catalogGroupFilter,
    setCatalogGroupFilter,
    wishlistIds,
    toggleWishlist,
    compareIds,
    toggleCompare,
    setCompareModalOpen,
    searchHistory,
    recordSearchQuery,
    openProductDetail,
    addToCart,
    setCurrentPage,
    setAdminTab,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('all');
  const [showAutocomplete, setShowAutocomplete] = useState(false);

  const publishedProducts = useMemo(
    () => products.filter((p) => p.published),
    [products]
  );

  const maxCatalogPrice = useMemo(() => {
    if (publishedProducts.length === 0) return 100000;
    return Math.max(1000, ...publishedProducts.map((p) => p.price || 0));
  }, [publishedProducts]);

  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState<number | null>(null);
  const effectiveMaxPrice = maxPrice ?? maxCatalogPrice;

  const enabledCategories = useMemo(
    () => categories.filter((c) => c.enabled),
    [categories]
  );

  const autocompleteSuggestions = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return [];
    return publishedProducts
      .filter((p) => p.title.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q))
      .slice(0, 6);
  }, [publishedProducts, searchQuery]);

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return publishedProducts.filter((p) => {
      if (catalogGroupFilter !== 'all' && p.categoryGroup !== catalogGroupFilter) {
        return false;
      }
      if (selectedCategoryId !== 'all' && p.categoryId !== selectedCategoryId) {
        return false;
      }
      if (p.price < minPrice || p.price > effectiveMaxPrice) {
        return false;
      }
      if (q) {
        const matchTitle = p.title.toLowerCase().includes(q);
        const matchDesc = (p.description || '').toLowerCase().includes(q);
        const matchSku = (p.sku || '').toLowerCase().includes(q);
        if (!matchTitle && !matchDesc && !matchSku) return false;
      }
      return true;
    });
  }, [
    publishedProducts,
    catalogGroupFilter,
    selectedCategoryId,
    minPrice,
    effectiveMaxPrice,
    searchQuery,
  ]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      recordSearchQuery(searchQuery.trim());
    }
    setShowAutocomplete(false);
  };

  return (
    <div className="space-y-5">
      {/* Search Bar + Autocomplete + Search History */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-100 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-slate-900">Service &amp; Product Catalog</h1>
            <p className="text-xs text-slate-500">
              Authorized social media services &amp; lawfully provisioned business phone numbers
            </p>
          </div>
          {compareIds.length > 0 && (
            <button
              type="button"
              onClick={() => setCompareModalOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#0B4F5B] text-white text-xs font-semibold hover:bg-[#093f49]"
            >
              <Scale className="w-4 h-4" />
              Compare ({compareIds.length}/3)
            </button>
          )}
        </div>

        <form onSubmit={handleSearchSubmit} className="relative">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={searchQuery}
                onFocus={() => setShowAutocomplete(true)}
                onBlur={() => setTimeout(() => setShowAutocomplete(false), 180)}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowAutocomplete(true);
                }}
                placeholder="Search by service title, description, or Inventory SKU..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50/70 text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#FF6A00]/30 focus:border-[#FF6A00]"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2.5 rounded-xl bg-[#FF6A00] text-white text-sm font-semibold hover:bg-[#e55f00] transition-colors shrink-0"
            >
              Search
            </button>
          </div>

          {/* Autocomplete Dropdown */}
          {showAutocomplete && autocompleteSuggestions.length > 0 && (
            <div className="absolute left-0 right-0 mt-1.5 bg-white rounded-2xl shadow-lg border border-slate-200 z-20 overflow-hidden">
              {autocompleteSuggestions.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onMouseDown={() => {
                    setSearchQuery(item.title);
                    recordSearchQuery(item.title);
                    setShowAutocomplete(false);
                  }}
                  className="w-full px-4 py-2.5 text-left hover:bg-orange-50 flex items-center justify-between text-sm border-b border-slate-100 last:border-0"
                >
                  <span className="font-medium text-slate-800 truncate">{item.title}</span>
                  <span className="text-xs font-mono-tabular text-slate-400 shrink-0 ml-2">
                    {item.sku}
                  </span>
                </button>
              ))}
            </div>
          )}
        </form>

        {/* Last 5 Search History Clickable Tags */}
        {searchHistory.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <span className="inline-flex items-center gap-1 text-xs text-slate-400">
              <Clock className="w-3.5 h-3.5" />
              Recent:
            </span>
            {searchHistory.map((term) => (
              <button
                key={term}
                type="button"
                onClick={() => setSearchQuery(term)}
                className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-orange-50 hover:text-[#FF6A00] text-xs font-medium text-slate-700 transition-colors"
              >
                {term}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Category Sidebar + Price Range Filter + Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-5 items-start">
        {/* Filter Sidebar */}
        <aside className="bg-white rounded-3xl p-4 border border-slate-100 shadow-xs space-y-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-slate-800 mb-2.5">
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#FF6A00]" />
              Service Groups
            </div>
            <div className="flex flex-wrap lg:flex-col gap-1.5">
              {(
                [
                  { id: 'all', label: 'All Offerings' },
                  { id: 'social_media', label: 'Social Media Services' },
                  { id: 'phone_services', label: 'Phone Numbers & eSIM' },
                  { id: 'custom_packages', label: 'Custom Packages' },
                ] as { id: CategoryGroup | 'all'; label: string }[]
              ).map((grp) => (
                <button
                  key={grp.id}
                  type="button"
                  onClick={() => {
                    setCatalogGroupFilter(grp.id);
                    setSelectedCategoryId('all');
                  }}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold text-left transition-colors ${
                    catalogGroupFilter === grp.id
                      ? 'bg-[#0B4F5B] text-white'
                      : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {grp.label}
                </button>
              ))}
            </div>
          </div>

          {enabledCategories.length > 0 && (
            <div>
              <div className="text-xs font-bold text-slate-800 mb-2">Categories</div>
              <div className="flex flex-wrap lg:flex-col gap-1.5">
                <button
                  type="button"
                  onClick={() => setSelectedCategoryId('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium text-left ${
                    selectedCategoryId === 'all'
                      ? 'bg-[#FF6A00]/10 text-[#FF6A00] font-semibold'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  All Categories
                </button>
                {enabledCategories.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => {
                      setSelectedCategoryId(cat.id);
                      setCatalogGroupFilter('all');
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium text-left ${
                      selectedCategoryId === cat.id
                        ? 'bg-[#FF6A00]/10 text-[#FF6A00] font-semibold'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Price Range Slider Filter */}
          <div className="pt-2 border-t border-slate-100 space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-slate-800">
              <span>Price Range</span>
              <button
                type="button"
                onClick={() => {
                  setMinPrice(0);
                  setMaxPrice(null);
                }}
                className="text-[#FF6A00] font-semibold hover:underline"
              >
                Reset
              </button>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-600 tabular-nums">
                <span>Min: {formatCurrency(minPrice, storeConfig.currencySymbol)}</span>
                <span>Max: {formatCurrency(effectiveMaxPrice, storeConfig.currencySymbol)}</span>
              </div>
              <label className="block text-[11px] text-slate-500">
                Minimum Price
                <input
                  type="range"
                  min={0}
                  max={maxCatalogPrice}
                  step={Math.max(100, Math.round(maxCatalogPrice / 50))}
                  value={Math.min(minPrice, effectiveMaxPrice)}
                  onChange={(e) => setMinPrice(Number(e.target.value))}
                  className="w-full accent-[#FF6A00] mt-1"
                />
              </label>
              <label className="block text-[11px] text-slate-500">
                Maximum Price
                <input
                  type="range"
                  min={0}
                  max={maxCatalogPrice}
                  step={Math.max(100, Math.round(maxCatalogPrice / 50))}
                  value={effectiveMaxPrice}
                  onChange={(e) => setMaxPrice(Math.max(minPrice, Number(e.target.value)))}
                  className="w-full accent-[#0B4F5B] mt-1"
                />
              </label>
            </div>
          </div>

          {/* Compliance Note */}
          <div className="rounded-2xl bg-slate-50 p-3 text-[11px] text-slate-600 leading-relaxed flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-[#0B4F5B] shrink-0 mt-0.5" />
            <span>
              Lawful Services Only: Authorized social marketing &amp; compliant business phone
              provisioning. No account passwords or OTP bypasses.
            </span>
          </div>
        </aside>

        {/* Product Grid */}
        <div className="lg:col-span-3">
          {productsLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {[1, 2, 3].map((n) => (
                <div
                  key={n}
                  className="bg-white rounded-3xl h-72 border border-slate-100 animate-pulse"
                />
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 sm:p-10 text-center border border-slate-100 shadow-xs">
              <div className="w-14 h-14 rounded-2xl bg-orange-50 text-[#FF6A00] flex items-center justify-center mx-auto mb-3">
                <PackageOpen className="w-7 h-7" />
              </div>
              <h2 className="text-lg font-bold text-slate-900">
                {publishedProducts.length === 0
                  ? 'No Listings Added Yet'
                  : 'No Products Match Your Filters'}
              </h2>
              <p className="mt-1.5 text-sm text-slate-600 max-w-md mx-auto">
                {publishedProducts.length === 0
                  ? 'Your Princegoldsocialhub catalog is ready and intentionally empty until the owner publishes real social media or phone number listings.'
                  : 'Try clearing your search term, adjusting the price range slider, or selecting another category.'}
              </p>
              <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
                {publishedProducts.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setCatalogGroupFilter('all');
                      setSelectedCategoryId('all');
                      setMinPrice(0);
                      setMaxPrice(null);
                    }}
                    className="px-4 py-2 rounded-xl bg-slate-100 text-slate-800 text-xs font-semibold hover:bg-slate-200"
                  >
                    Clear All Filters
                  </button>
                )}
                {isAdmin && (
                  <button
                    type="button"
                    onClick={() => {
                      setAdminTab('catalog');
                      setCurrentPage('admin');
                    }}
                    className="px-5 py-2.5 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold hover:bg-[#e55f00]"
                  >
                    Manage Listings in Admin Panel
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredProducts.map((product) => {
                const inWish = wishlistIds.includes(product.id);
                const inCompare = compareIds.includes(product.id);
                const inStock = product.available && (!product.trackStock || product.stock > 0);
                const catName =
                  categories.find((c) => c.id === product.categoryId)?.name || 'Service';

                return (
                  <article
                    key={product.id}
                    className="bg-white rounded-3xl overflow-hidden border border-slate-100 shadow-xs hover:shadow-md transition-shadow flex flex-col"
                  >
                    <div className="relative">
                      <ProductVisual
                        imageUrl={product.imageUrl}
                        title={product.title}
                        group={product.categoryGroup}
                        className="w-full h-44"
                      />
                      <button
                        type="button"
                        onClick={() => toggleWishlist(product.id)}
                        className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/95 shadow-sm flex items-center justify-center text-slate-600 hover:text-[#FF6A00]"
                        aria-label={inWish ? 'Remove from wishlist' : 'Save to wishlist'}
                      >
                        <Heart
                          className={`w-4 h-4 ${inWish ? 'fill-[#FF6A00] text-[#FF6A00]' : ''}`}
                        />
                      </button>
                    </div>

                    <div className="p-4 flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                          <span className="truncate">{catName}</span>
                          <span className="font-mono-tabular text-slate-400 shrink-0">
                            {product.sku}
                          </span>
                        </div>

                        <h3 className="mt-1 text-base font-bold text-slate-900 line-clamp-1">
                          {product.title}
                        </h3>
                        <p className="mt-1 text-xs text-slate-600 line-clamp-2 leading-relaxed">
                          {product.description}
                        </p>

                        <div className="mt-3 flex items-center justify-between text-xs">
                          <span className="text-base font-bold text-[#0B4F5B] tabular-nums">
                            {formatCurrency(product.price, storeConfig.currencySymbol)}
                          </span>
                          <span
                            className={`font-semibold ${
                              inStock ? 'text-emerald-700' : 'text-red-600'
                            }`}
                          >
                            {inStock
                              ? product.trackStock
                                ? `${product.stock} in stock`
                                : 'Available'
                              : 'Unavailable'}
                          </span>
                        </div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => toggleCompare(product.id)}
                          className={`min-h-[38px] px-2.5 rounded-xl border text-xs font-semibold flex items-center gap-1 transition-colors ${
                            inCompare
                              ? 'border-[#0B4F5B] bg-teal-50 text-[#0B4F5B]'
                              : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                          }`}
                          title="Compare product"
                        >
                          <Scale className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => openProductDetail(product.id)}
                          className="flex-1 min-h-[38px] px-3 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                        >
                          Details
                        </button>
                        <button
                          type="button"
                          disabled={!inStock}
                          onClick={() => addToCart(product, 1)}
                          className="min-h-[38px] px-3.5 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold hover:bg-[#e55f00] disabled:opacity-50 inline-flex items-center gap-1.5"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          Add
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
