import React, { useMemo, useState } from 'react';
import {
  collection,
  doc,
  getDocs,
  query,
  serverTimestamp,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  AlertCircle,
  CheckCircle2,
  CreditCard,
  Lock,
  ShoppingBag,
  Tag,
  Trash2,
  ExternalLink,
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { calculateEstimatedDeliveryDate, formatCurrency } from '../lib/storeDefaults';
import { ProductVisual } from '../components/BrandVisuals';
import { Order, Promotion } from '../types';

export const CheckoutPage: React.FC = () => {
  const {
    user,
    cart,
    updateCartQty,
    removeFromCart,
    clearCart,
    storeConfig,
    paymentGatewayStatus,
    setCurrentPage,
    openOrderTracking,
    showToast,
  } = useApp();

  const [customerName, setCustomerName] = useState(user?.displayName || '');
  const [customerEmail, setCustomerEmail] = useState(user?.email || '');
  const [customerPhone, setCustomerPhone] = useState('');
  const [shippingAddress, setShippingAddress] = useState('');
  const [provider, setProvider] = useState<'paystack' | 'flutterwave' | 'test_mode'>('paystack');

  const [couponInput, setCouponInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Promotion | null>(null);
  const [couponMessage, setCouponMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [checkingCoupon, setCheckingCoupon] = useState(false);

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<{
    orderNumber: string;
    totalAmount: number;
    paymentUrl?: string;
    providerUsed: string;
    configured: boolean;
  } | null>(null);

  const hasPhysicalItems = useMemo(
    () => cart.some((item) => item.product.fulfillmentMethod === 'physical_product'),
    [cart]
  );

  const subtotal = useMemo(
    () => cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0),
    [cart]
  );

  const discountAmount = useMemo(() => {
    if (!appliedCoupon) return 0;
    return Math.round((subtotal * appliedCoupon.discountPercent) / 100);
  }, [subtotal, appliedCoupon]);

  const shippingFee = hasPhysicalItems ? 2500 : 0;
  const taxable = Math.max(0, subtotal - discountAmount);
  const taxAmount = Math.round(taxable * 0.075);
  const totalAmount = Math.max(0, taxable + shippingFee + taxAmount);

  const handleApplyCoupon = async () => {
    const code = couponInput.trim().toUpperCase();
    setCouponMessage(null);
    if (!code) {
      setAppliedCoupon(null);
      return;
    }
    if (!user) {
      setCouponMessage({ ok: false, text: 'Sign in first to validate promotion codes.' });
      return;
    }
    setCheckingCoupon(true);
    try {
      const q = query(
        collection(db, 'promotions'),
        where('code', '==', code),
        where('active', '==', true)
      );
      const snap = await getDocs(q);
      if (snap.empty) {
        setAppliedCoupon(null);
        setCouponMessage({ ok: false, text: 'Invalid or expired promotion code.' });
      } else {
        const promo = { id: snap.docs[0].id, ...(snap.docs[0].data() as Omit<Promotion, 'id'>) };
        setAppliedCoupon(promo);
        setCouponMessage({
          ok: true,
          text: `Applied ${promo.code} (${promo.discountPercent}% off)`,
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'promotions');
    } finally {
      setCheckingCoupon(false);
    }
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    if (!customerName.trim() || customerName.trim().length < 2) {
      errors.customerName = 'Full name is required.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerEmail.trim())) {
      errors.customerEmail = 'Enter a valid email address.';
    }
    if (!customerPhone.trim() || customerPhone.trim().length < 7) {
      errors.customerPhone = 'Valid contact phone number is required.';
    }
    if (hasPhysicalItems && (!shippingAddress.trim() || shippingAddress.trim().length < 8)) {
      errors.shippingAddress = 'Complete delivery address is required for physical items.';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      showToast('Please sign in to complete your order.', 'info');
      setCurrentPage('profile');
      return;
    }
    if (cart.length === 0) return;
    if (!validateForm()) return;

    setSubmitting(true);
    try {
      const nowIso = new Date().toISOString();
      const rand = Math.floor(1000 + Math.random() * 9000);
      const dateCode = nowIso.slice(0, 10).replace(/-/g, '');
      const orderNumber = `PGH-${dateCode}-${rand}`;
      const orderRef = doc(collection(db, 'orders'));
      const paymentRef = doc(collection(db, 'payments'));

      const selectedProvider: Order['paymentProvider'] =
        provider === 'paystack' && paymentGatewayStatus.paystackConfigured
          ? 'paystack'
          : provider === 'flutterwave' && paymentGatewayStatus.flutterwaveConfigured
          ? 'flutterwave'
          : 'test_mode';

      const estDelivery = calculateEstimatedDeliveryDate(
        new Date(),
        'Awaiting Payment',
        hasPhysicalItems
      );

      const timeline = [
        {
          status: 'Awaiting Payment',
          timestamp: nowIso,
          note:
            selectedProvider === 'test_mode'
              ? 'Order placed in Test Mode awaiting payment provider configuration or manual confirmation.'
              : `Order initialized via ${selectedProvider.toUpperCase()} hosted checkout.`,
          actor: customerEmail.trim(),
        },
      ];

      let paymentReference = `TEST-${orderNumber}`;
      let authorizationUrl: string | undefined;
      let providerConfigured = false;

      if (provider !== 'test_mode') {
        const idToken = await auth.currentUser?.getIdToken();
        const initRes = await fetch('/api/payments/initialize', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${idToken}`,
          },
          body: JSON.stringify({
            provider,
            email: customerEmail.trim(),
            amount: totalAmount,
            currency: storeConfig.currencyCode,
            orderNumber,
            orderId: orderRef.id,
            callbackUrl: window.location.href,
          }),
        });
        const initData = (await initRes.json()) as {
          configured?: boolean;
          authorizationUrl?: string;
          reference?: string;
          error?: string;
        };
        if (!initRes.ok) {
          throw new Error(initData.error || 'Payment initialization failed.');
        }
        providerConfigured = Boolean(initData.configured);
        if (initData.reference) paymentReference = initData.reference;
        if (initData.authorizationUrl) authorizationUrl = initData.authorizationUrl;
      }

      const batch = writeBatch(db);

      batch.set(orderRef, {
        orderNumber,
        userId: user.uid,
        customerName: customerName.trim().slice(0, 120),
        customerEmail: customerEmail.trim().slice(0, 160),
        customerPhone: customerPhone.trim().slice(0, 40),
        shippingAddress: shippingAddress.trim().slice(0, 400),
        hasPhysicalItems,
        currencyCode: storeConfig.currencyCode,
        currencySymbol: storeConfig.currencySymbol,
        subtotal,
        discountAmount,
        couponCode: appliedCoupon?.code || '',
        shippingFee,
        taxAmount,
        totalAmount,
        paymentProvider: providerConfigured ? provider : 'test_mode',
        paymentReference,
        paymentStatus: providerConfigured ? 'unpaid' : 'test_pending',
        status: 'Awaiting Payment',
        trackingNumber: '',
        estimatedDeliveryDate: estDelivery,
        items: cart.slice(0, 30).map((item) => ({
          productId: item.product.id,
          sku: item.product.sku,
          title: item.product.title,
          price: item.product.price,
          quantity: item.quantity,
          fulfillmentMethod: item.product.fulfillmentMethod,
        })),
        timeline,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      batch.set(doc(db, 'order_tracking_public', orderNumber), {
        orderId: orderRef.id,
        orderNumber,
        status: 'Awaiting Payment',
        paymentStatus: providerConfigured ? 'unpaid' : 'test_pending',
        trackingNumber: '',
        estimatedDeliveryDate: estDelivery,
        hasPhysicalItems,
        timeline,
        updatedAt: serverTimestamp(),
      });

      batch.set(paymentRef, {
        orderId: orderRef.id,
        orderNumber,
        userId: user.uid,
        provider: providerConfigured ? provider : 'test_mode',
        reference: paymentReference,
        amount: totalAmount,
        currencyCode: storeConfig.currencyCode,
        status: 'pending',
        verifiedServerSide: false,
        createdAt: serverTimestamp(),
      });

      await batch.commit();

      clearCart();
      setConfirmedOrder({
        orderNumber,
        totalAmount,
        paymentUrl: authorizationUrl,
        providerUsed: providerConfigured ? provider : 'test_mode',
        configured: providerConfigured,
      });
      showToast(`Order ${orderNumber} created successfully.`, 'success');
    } catch (err) {
      if (err instanceof Error && err.message.startsWith('{')) {
        throw err;
      }
      showToast(err instanceof Error ? err.message : 'Checkout failed.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  if (confirmedOrder) {
    return (
      <div className="max-w-2xl mx-auto bg-white rounded-3xl p-6 sm:p-8 border border-slate-100 shadow-xs text-center space-y-5">
        <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
          <CheckCircle2 className="w-9 h-9" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Order Confirmed</h1>
          <p className="mt-1 text-sm text-slate-600">
            Save your unique Order ID below to track status updates in real time.
          </p>
        </div>

        <div className="rounded-2xl bg-slate-50 border border-slate-200 p-4 space-y-1">
          <div className="text-xs text-slate-500">Order ID</div>
          <div className="text-xl font-bold font-mono-tabular text-[#0B4F5B]">
            {confirmedOrder.orderNumber}
          </div>
          <div className="text-sm font-semibold text-slate-700 tabular-nums">
            Total: {formatCurrency(confirmedOrder.totalAmount, storeConfig.currencySymbol)}
          </div>
        </div>

        {confirmedOrder.paymentUrl ? (
          <div className="rounded-2xl bg-orange-50 border border-[#FF6A00]/30 p-4 space-y-3">
            <p className="text-xs text-slate-700 font-medium">
              Complete your hosted payment securely via{' '}
              <span className="uppercase font-bold">{confirmedOrder.providerUsed}</span>:
            </p>
            <a
              href={confirmedOrder.paymentUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#FF6A00] text-white text-sm font-bold hover:bg-[#e55f00]"
            >
              Continue to Hosted Checkout
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        ) : (
          <div className="rounded-2xl bg-amber-50 border border-amber-200 p-4 text-xs text-amber-900 text-left">
            <strong>Test Mode Notice:</strong> Live Paystack/Flutterwave server keys are not
            configured yet (`PAYSTACK_SECRET_KEY` / `FLUTTERWAVE_SECRET_KEY`). Your order has been
            recorded with status <strong>Awaiting Payment</strong> so no fake charge was claimed.
          </div>
        )}

        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            type="button"
            onClick={() => openOrderTracking(confirmedOrder.orderNumber)}
            className="px-5 py-2.5 rounded-xl bg-[#0B4F5B] text-white text-sm font-semibold hover:bg-[#093f49]"
          >
            Track Order Now
          </button>
          <button
            type="button"
            onClick={() => setCurrentPage('catalog')}
            className="px-5 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-sm font-semibold hover:bg-slate-50"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="bg-white rounded-3xl p-8 sm:p-10 text-center border border-slate-100 shadow-xs">
        <div className="w-14 h-14 rounded-2xl bg-orange-50 text-[#FF6A00] flex items-center justify-center mx-auto mb-3">
          <ShoppingBag className="w-7 h-7" />
        </div>
        <h1 className="text-xl font-bold text-slate-900">Your Cart is Empty</h1>
        <p className="mt-1.5 text-sm text-slate-600">
          Browse the Princegoldsocialhub catalog to add social media services or phone number
          packages.
        </p>
        <button
          type="button"
          onClick={() => setCurrentPage('catalog')}
          className="mt-5 px-5 py-2.5 rounded-xl bg-[#FF6A00] text-white text-sm font-semibold hover:bg-[#e55f00]"
        >
          Browse Catalog
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-slate-900">Shopping Cart &amp; Secure Checkout</h1>
        <p className="text-xs text-slate-500">
          Review items, apply promotion codes, and confirm your order details
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left: Cart Items + Customer Details Form */}
        <div className="lg:col-span-7 space-y-5">
          {/* Cart Items */}
          <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-3">
            <h2 className="text-sm font-bold text-slate-900">Cart Items ({cart.length})</h2>
            <div className="divide-y divide-slate-100">
              {cart.map((item) => (
                <div key={item.product.id} className="py-3 flex items-center gap-3">
                  <ProductVisual
                    imageUrl={item.product.imageUrl}
                    title={item.product.title}
                    group={item.product.categoryGroup}
                    className="w-16 h-16 rounded-2xl shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-bold text-slate-900 truncate">
                      {item.product.title}
                    </div>
                    <div className="text-xs font-mono-tabular text-slate-400">
                      SKU: {item.product.sku}
                    </div>
                    <div className="text-xs font-semibold text-[#0B4F5B] mt-0.5 tabular-nums">
                      {formatCurrency(item.product.price, storeConfig.currencySymbol)}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center border border-slate-200 rounded-xl">
                      <button
                        type="button"
                        onClick={() => updateCartQty(item.product.id, item.quantity - 1)}
                        className="w-8 h-8 text-sm font-bold text-slate-600 hover:bg-slate-50"
                      >
                        -
                      </button>
                      <span className="px-2 text-xs font-bold tabular-nums">{item.quantity}</span>
                      <button
                        type="button"
                        onClick={() => updateCartQty(item.product.id, item.quantity + 1)}
                        className="w-8 h-8 text-sm font-bold text-slate-600 hover:bg-slate-50"
                      >
                        +
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeFromCart(item.product.id)}
                      className="p-2 text-slate-400 hover:text-red-500"
                      aria-label="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Checkout Form */}
          <form
            id="checkout-form"
            onSubmit={handlePlaceOrder}
            className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4"
          >
            <h2 className="text-sm font-bold text-slate-900">Customer &amp; Delivery Information</h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Enter your full name"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]/30 focus:border-[#FF6A00]"
                />
                {formErrors.customerName && (
                  <p className="mt-1 text-xs text-red-600">{formErrors.customerName}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Delivery Email *
                </label>
                <input
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]/30 focus:border-[#FF6A00]"
                />
                {formErrors.customerEmail && (
                  <p className="mt-1 text-xs text-red-600">{formErrors.customerEmail}</p>
                )}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Contact Phone / WhatsApp *
              </label>
              <input
                type="tel"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                placeholder="+234 800 000 0000"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]/30 focus:border-[#FF6A00]"
              />
              {formErrors.customerPhone && (
                <p className="mt-1 text-xs text-red-600">{formErrors.customerPhone}</p>
              )}
            </div>

            {hasPhysicalItems && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Shipping Address (Required for physical items) *
                </label>
                <textarea
                  rows={2}
                  value={shippingAddress}
                  onChange={(e) => setShippingAddress(e.target.value)}
                  placeholder="Street address, city, state, and postal code"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6A00]/30 focus:border-[#FF6A00]"
                />
                {formErrors.shippingAddress && (
                  <p className="mt-1 text-xs text-red-600">{formErrors.shippingAddress}</p>
                )}
              </div>
            )}

            {/* Payment Provider Selector */}
            <div className="pt-2 border-t border-slate-100 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">Payment Method</span>
                <span className="inline-flex items-center gap-1 text-[11px] text-slate-500">
                  <Lock className="w-3 h-3 text-[#0B4F5B]" />
                  No card details stored
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setProvider('paystack')}
                  className={`p-3 rounded-2xl border text-left transition-colors ${
                    provider === 'paystack'
                      ? 'border-[#FF6A00] bg-orange-50/60'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="text-xs font-bold text-slate-900">Paystack</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    {paymentGatewayStatus.paystackConfigured
                      ? `${paymentGatewayStatus.paystackMode.toUpperCase()} Ready`
                      : 'Setup Required'}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setProvider('flutterwave')}
                  className={`p-3 rounded-2xl border text-left transition-colors ${
                    provider === 'flutterwave'
                      ? 'border-[#FF6A00] bg-orange-50/60'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="text-xs font-bold text-slate-900">Flutterwave</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    {paymentGatewayStatus.flutterwaveConfigured
                      ? `${paymentGatewayStatus.flutterwaveMode.toUpperCase()} Ready`
                      : 'Setup Required'}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setProvider('test_mode')}
                  className={`p-3 rounded-2xl border text-left transition-colors ${
                    provider === 'test_mode'
                      ? 'border-[#0B4F5B] bg-teal-50/60'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="text-xs font-bold text-slate-900">Test Order</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">Pending Verification</div>
                </button>
              </div>

              {!paymentGatewayStatus.anyLiveOrTestConfigured && (
                <div className="rounded-2xl bg-amber-50 border border-amber-200 p-3 flex items-start gap-2.5 text-xs text-amber-900">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
                  <div>
                    <strong>Payment Gateway Not Connected Yet:</strong> Server secret keys (
                    <code>PAYSTACK_SECRET_KEY</code> or <code>FLUTTERWAVE_SECRET_KEY</code>) are not
                    configured. You can still submit this order in Test Mode (`Awaiting Payment`).
                  </div>
                </div>
              )}
            </div>
          </form>
        </div>

        {/* Right: Persistent Real-Time Order Summary & Coupon Validator */}
        <aside className="lg:col-span-5 bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4 lg:sticky lg:top-20">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-[#FF6A00]" />
            <h2 className="text-base font-bold text-slate-900">Order Summary</h2>
          </div>

          {/* Coupon Code Input */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700">Promotion Code</label>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={couponInput}
                  onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                  placeholder="Enter code"
                  className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-200 text-xs font-mono-tabular uppercase focus:outline-none focus:border-[#FF6A00]"
                />
              </div>
              <button
                type="button"
                onClick={handleApplyCoupon}
                disabled={checkingCoupon}
                className="px-3.5 py-2 rounded-xl bg-slate-100 text-slate-800 text-xs font-semibold hover:bg-slate-200"
              >
                {checkingCoupon ? 'Checking...' : 'Apply'}
              </button>
            </div>
            {couponMessage && (
              <p
                className={`text-xs font-medium ${
                  couponMessage.ok ? 'text-emerald-700' : 'text-red-600'
                }`}
              >
                {couponMessage.text}
              </p>
            )}
          </div>

          <div className="space-y-2.5 pt-3 border-t border-slate-100 text-sm">
            <div className="flex justify-between text-slate-600">
              <span>Subtotal</span>
              <span className="tabular-nums font-medium">
                {formatCurrency(subtotal, storeConfig.currencySymbol)}
              </span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-700">
                <span>Discount ({appliedCoupon?.code})</span>
                <span className="tabular-nums font-medium">
                  -{formatCurrency(discountAmount, storeConfig.currencySymbol)}
                </span>
              </div>
            )}
            <div className="flex justify-between text-slate-600">
              <span>Shipping</span>
              <span className="tabular-nums font-medium">
                {hasPhysicalItems
                  ? formatCurrency(shippingFee, storeConfig.currencySymbol)
                  : 'Digital Delivery (Free)'}
              </span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Estimated VAT (7.5%)</span>
              <span className="tabular-nums font-medium">
                {formatCurrency(taxAmount, storeConfig.currencySymbol)}
              </span>
            </div>
            <div className="pt-3 border-t border-slate-100 flex justify-between text-base font-bold text-slate-900">
              <span>Total</span>
              <span className="text-[#0B4F5B] tabular-nums">
                {formatCurrency(totalAmount, storeConfig.currencySymbol)}
              </span>
            </div>
          </div>

          {!user && (
            <div className="rounded-xl bg-slate-50 p-3 text-xs text-slate-600">
              Sign in is required to protect your order tracking and transaction history.
            </div>
          )}

          <button
            type="submit"
            form="checkout-form"
            disabled={submitting}
            className="w-full py-3.5 px-5 rounded-xl bg-[#FF6A00] text-white text-sm font-bold hover:bg-[#e55f00] disabled:opacity-60 transition-colors"
          >
            {submitting
              ? 'Processing Order...'
              : user
              ? 'Confirm & Place Order'
              : 'Sign In to Checkout'}
          </button>
        </aside>
      </div>
    </div>
  );
};
