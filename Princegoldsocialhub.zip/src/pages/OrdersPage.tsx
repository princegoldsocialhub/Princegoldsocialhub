import React, { useEffect, useMemo, useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import {
  CheckCircle2,
  Clock,
  Package,
  Search,
  Truck,
  XCircle,
  CalendarClock,
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { db } from '../lib/firebase';
import {
  calculateEstimatedDeliveryDate,
  formatCurrency,
  formatDateTime,
} from '../lib/storeDefaults';
import { Order, OrderStatus, OrderTrackingPublic } from '../types';

const STEP_STAGES: OrderStatus[] = ['Awaiting Payment', 'Paid', 'Processing', 'Shipped', 'Completed'];

export const OrdersPage: React.FC = () => {
  const {
    user,
    customerOrders,
    storeConfig,
    selectedOrderNumber,
    setCurrentPage,
  } = useApp();

  const [lookupInput, setLookupInput] = useState(selectedOrderNumber || '');
  const [searchTerm, setSearchTerm] = useState('');
  const [trackedPublicOrder, setTrackedPublicOrder] = useState<OrderTrackingPublic | null>(null);
  const [trackedFullOrder, setTrackedFullOrder] = useState<Order | null>(null);
  const [lookupError, setLookupError] = useState('');
  const [lookupLoading, setLookupLoading] = useState(false);

  const performLookup = async (orderNumRaw: string) => {
    const orderNum = orderNumRaw.trim().toUpperCase();
    setLookupError('');
    if (!orderNum) return;

    const localMatch = customerOrders.find(
      (o) => o.orderNumber.toUpperCase() === orderNum
    );
    if (localMatch) {
      setTrackedFullOrder(localMatch);
      setTrackedPublicOrder({
        orderId: localMatch.id,
        orderNumber: localMatch.orderNumber,
        status: localMatch.status,
        paymentStatus: localMatch.paymentStatus,
        trackingNumber: localMatch.trackingNumber,
        estimatedDeliveryDate: localMatch.estimatedDeliveryDate,
        hasPhysicalItems: localMatch.hasPhysicalItems,
        timeline: localMatch.timeline,
      });
      return;
    }

    setLookupLoading(true);
    try {
      const snap = await getDoc(doc(db, 'order_tracking_public', orderNum));
      if (!snap.exists()) {
        setTrackedPublicOrder(null);
        setTrackedFullOrder(null);
        setLookupError(`No order found with Order ID "${orderNum}".`);
      } else {
        setTrackedFullOrder(null);
        setTrackedPublicOrder(snap.data() as OrderTrackingPublic);
      }
    } catch {
      setLookupError('Unable to look up that Order ID right now.');
    } finally {
      setLookupLoading(false);
    }
  };

  useEffect(() => {
    if (selectedOrderNumber) {
      setLookupInput(selectedOrderNumber);
      performLookup(selectedOrderNumber);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedOrderNumber]);

  const filteredMyOrders = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return customerOrders;
    return customerOrders.filter(
      (o) =>
        o.orderNumber.toLowerCase().includes(q) ||
        o.status.toLowerCase().includes(q) ||
        o.items.some((i) => i.title.toLowerCase().includes(q))
    );
  }, [customerOrders, searchTerm]);

  const activeOrder = trackedPublicOrder;
  const currentStageIndex = activeOrder
    ? STEP_STAGES.indexOf(activeOrder.status)
    : -1;
  const isTerminalNegative =
    activeOrder?.status === 'Cancelled' || activeOrder?.status === 'Refunded';

  const dynamicEta = activeOrder
    ? activeOrder.estimatedDeliveryDate ||
      calculateEstimatedDeliveryDate(
        activeOrder.timeline?.[0]?.timestamp,
        activeOrder.status,
        activeOrder.hasPhysicalItems
      )
    : '';

  return (
    <div className="space-y-5">
      {/* Track Order by ID */}
      <section className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Orders &amp; Real-Time Tracking</h1>
          <p className="text-xs text-slate-500">
            Enter your unique Princegoldsocialhub Order ID to inspect fulfillment progress
          </p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            performLookup(lookupInput);
          }}
          className="flex flex-col sm:flex-row gap-2"
        >
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={lookupInput}
              onChange={(e) => setLookupInput(e.target.value.toUpperCase())}
              placeholder="Enter Order ID (e.g., PGH-20261120-1042)"
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 font-mono-tabular text-sm uppercase focus:outline-none focus:ring-2 focus:ring-[#FF6A00]/30 focus:border-[#FF6A00]"
            />
          </div>
          <button
            type="submit"
            disabled={lookupLoading}
            className="px-5 py-2.5 rounded-xl bg-[#0B4F5B] text-white text-sm font-semibold hover:bg-[#093f49] disabled:opacity-60"
          >
            {lookupLoading ? 'Tracking...' : 'Track Order'}
          </button>
        </form>

        {lookupError && (
          <div className="rounded-xl bg-red-50 text-red-700 px-3.5 py-2.5 text-xs font-medium">
            {lookupError}
          </div>
        )}

        {/* Active Tracked Order Stepper + Timeline */}
        {activeOrder && (
          <div className="pt-3 border-t border-slate-100 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-xs text-slate-500">Tracking Order</div>
                <div className="text-lg font-bold font-mono-tabular text-[#0B4F5B]">
                  {activeOrder.orderNumber}
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-4 text-xs">
                <div className="flex items-center gap-1.5 text-slate-700">
                  <CalendarClock className="w-4 h-4 text-[#FF6A00]" />
                  <span>
                    Estimated Delivery: <strong>{dynamicEta}</strong>
                  </span>
                </div>
                <div className="font-bold text-slate-900">
                  Status: <span className="text-[#FF6A00]">{activeOrder.status}</span>
                </div>
              </div>
            </div>

            {/* Visual Stepper */}
            {isTerminalNegative ? (
              <div className="rounded-2xl bg-red-50 border border-red-200 p-4 flex items-center gap-3 text-sm text-red-800">
                <XCircle className="w-5 h-5 text-red-600 shrink-0" />
                <span>
                  This order is marked as <strong>{activeOrder.status}</strong>. See the timeline
                  below for details.
                </span>
              </div>
            ) : (
              <div className="grid grid-cols-5 gap-2">
                {STEP_STAGES.map((stage, idx) => {
                  const completed = currentStageIndex >= idx;
                  const current = currentStageIndex === idx;
                  return (
                    <div key={stage} className="flex flex-col items-center text-center">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                          completed
                            ? 'bg-[#FF6A00] text-white'
                            : 'bg-slate-100 text-slate-400'
                        } ${current ? 'ring-4 ring-[#FF6A00]/20' : ''}`}
                      >
                        {completed ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                      </div>
                      <span
                        className={`mt-1.5 text-[11px] leading-tight ${
                          completed ? 'font-bold text-slate-900' : 'text-slate-400'
                        }`}
                      >
                        {stage}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Physical Shipment Tracking Number (only when applicable) */}
            {activeOrder.hasPhysicalItems && activeOrder.trackingNumber && (
              <div className="rounded-2xl bg-teal-50/70 border border-teal-200 p-3.5 flex items-center gap-2.5 text-xs text-[#0B4F5B]">
                <Truck className="w-4 h-4 shrink-0" />
                <span>
                  Shipment Tracking Number:{' '}
                  <strong className="font-mono-tabular">{activeOrder.trackingNumber}</strong>
                </span>
              </div>
            )}

            {/* Full Itemized Breakdown if owner is viewing their own order */}
            {trackedFullOrder && (
              <div className="rounded-2xl bg-slate-50 p-4 space-y-2 text-xs">
                <div className="font-bold text-slate-900">Order Items</div>
                {trackedFullOrder.items.map((item, idx) => (
                  <div key={`${item.sku}-${idx}`} className="flex justify-between text-slate-700">
                    <span>
                      {item.quantity}× {item.title}{' '}
                      <span className="font-mono-tabular text-slate-400">({item.sku})</span>
                    </span>
                    <span className="tabular-nums font-semibold">
                      {formatCurrency(item.price * item.quantity, trackedFullOrder.currencySymbol)}
                    </span>
                  </div>
                ))}
                <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-slate-900">
                  <span>Total</span>
                  <span className="tabular-nums">
                    {formatCurrency(trackedFullOrder.totalAmount, trackedFullOrder.currencySymbol)}
                  </span>
                </div>
              </div>
            )}

            {/* Detailed Timestamped Timeline */}
            <div className="space-y-3">
              <div className="text-xs font-bold text-slate-800">Fulfillment Timeline</div>
              <div className="space-y-3 pl-2">
                {(activeOrder.timeline || []).map((entry, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <div className="mt-1 w-2.5 h-2.5 rounded-full bg-[#0B4F5B] shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="font-bold text-slate-900">{entry.status}</span>
                        <span className="text-slate-400">·</span>
                        <span className="text-slate-500">{formatDateTime(entry.timestamp)}</span>
                      </div>
                      {entry.note && (
                        <p className="text-xs text-slate-600 mt-0.5">{entry.note}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </section>

      {/* Customer's Own Order History */}
      <section className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900">My Order History</h2>
            <p className="text-xs text-slate-500">
              Only genuine orders placed under your signed-in account
            </p>
          </div>
          {user && customerOrders.length > 0 && (
            <input
              type="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Filter my orders..."
              className="px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:border-[#FF6A00]"
            />
          )}
        </div>

        {!user ? (
          <div className="py-8 text-center space-y-3">
            <Clock className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-sm text-slate-600">
              Sign in to view your personal order history and receive status notifications.
            </p>
            <button
              type="button"
              onClick={() => setCurrentPage('profile')}
              className="px-4 py-2 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold"
            >
              Sign In / Create Account
            </button>
          </div>
        ) : filteredMyOrders.length === 0 ? (
          <div className="py-8 text-center space-y-3">
            <Package className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-sm text-slate-600">
              {customerOrders.length === 0
                ? 'You have not placed any orders yet.'
                : 'No orders match your filter.'}
            </p>
            {customerOrders.length === 0 && (
              <button
                type="button"
                onClick={() => setCurrentPage('catalog')}
                className="px-4 py-2 rounded-xl bg-[#0B4F5B] text-white text-xs font-semibold"
              >
                Explore Catalog
              </button>
            )}
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredMyOrders.map((order) => (
              <div
                key={order.id}
                className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-mono-tabular font-bold text-[#0B4F5B]">
                      {order.orderNumber}
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="text-slate-500">{formatDateTime(order.createdAt)}</span>
                  </div>
                  <div className="text-sm font-semibold text-slate-900">
                    {order.items.map((i) => `${i.quantity}× ${i.title}`).join(', ')}
                  </div>
                  <div className="text-xs text-slate-500">
                    Status: <strong className="text-[#FF6A00]">{order.status}</strong> ·{' '}
                    <span className="tabular-nums font-semibold text-slate-700">
                      {formatCurrency(
                        order.totalAmount,
                        order.currencySymbol || storeConfig.currencySymbol
                      )}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setLookupInput(order.orderNumber);
                    performLookup(order.orderNumber);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 shrink-0"
                >
                  Inspect Timeline
                </button>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
