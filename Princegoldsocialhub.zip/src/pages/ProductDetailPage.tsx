import React, { useState } from 'react';
import {
  ArrowLeft,
  Check,
  Copy,
  Heart,
  ShieldCheck,
  ShoppingBag,
  Truck,
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { formatCurrency } from '../lib/storeDefaults';
import { ProductVisual } from '../components/BrandVisuals';

export const ProductDetailPage: React.FC = () => {
  const {
    products,
    categories,
    selectedProductId,
    storeConfig,
    wishlistIds,
    toggleWishlist,
    addToCart,
    setCurrentPage,
    showToast,
  } = useApp();

  const [qty, setQty] = useState(1);
  const [copiedSku, setCopiedSku] = useState(false);

  const product = products.find((p) => p.id === selectedProductId);

  if (!product) {
    return (
      <div className="bg-white rounded-3xl p-8 text-center border border-slate-100 shadow-xs">
        <h2 className="text-lg font-bold text-slate-900">Product Not Found</h2>
        <p className="mt-1 text-sm text-slate-600">
          This listing may have been unpublished or removed.
        </p>
        <button
          type="button"
          onClick={() => setCurrentPage('catalog')}
          className="mt-4 px-5 py-2.5 rounded-xl bg-[#FF6A00] text-white text-sm font-semibold"
        >
          Back to Catalog
        </button>
      </div>
    );
  }

  const category = categories.find((c) => c.id === product.categoryId);
  const inWish = wishlistIds.includes(product.id);
  const inStock = product.available && (!product.trackStock || product.stock > 0);
  const maxQty = product.trackStock ? Math.max(1, product.stock) : 99;

  const handleCopySku = async () => {
    try {
      await navigator.clipboard.writeText(product.sku);
      setCopiedSku(true);
      showToast(`Copied SKU ${product.sku} to clipboard.`, 'success');
      setTimeout(() => setCopiedSku(false), 2000);
    } catch {
      showToast(`SKU: ${product.sku}`, 'info');
    }
  };

  return (
    <div className="space-y-4">
      <button
        type="button"
        onClick={() => setCurrentPage('catalog')}
        className="inline-flex items-center gap-2 text-sm font-semibold text-[#0B4F5B] hover:underline"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Catalog
      </button>

      <div className="bg-white rounded-3xl border border-slate-100 shadow-xs overflow-hidden grid grid-cols-1 lg:grid-cols-2">
        <div className="relative bg-slate-50">
          <ProductVisual
            imageUrl={product.imageUrl}
            title={product.title}
            group={product.categoryGroup}
            className="w-full h-72 lg:h-full min-h-[280px]"
          />
          <button
            type="button"
            onClick={() => toggleWishlist(product.id)}
            className="absolute top-4 right-4 w-11 h-11 rounded-full bg-white/95 shadow-sm flex items-center justify-center text-slate-600 hover:text-[#FF6A00]"
            aria-label="Toggle wishlist"
          >
            <Heart className={`w-5 h-5 ${inWish ? 'fill-[#FF6A00] text-[#FF6A00]' : ''}`} />
          </button>
        </div>

        <div className="p-6 sm:p-8 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
              <span>{category?.name || 'Service Listing'}</span>
              <div className="flex items-center gap-2">
                <span className="font-mono-tabular font-semibold text-slate-700">
                  SKU: {product.sku}
                </span>
                <button
                  type="button"
                  onClick={handleCopySku}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-orange-50 text-slate-700 hover:text-[#FF6A00] font-semibold transition-colors"
                >
                  {copiedSku ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedSku ? 'Copied' : 'Copy SKU'}
                </button>
              </div>
            </div>

            <h1 className="text-2xl font-bold text-slate-900">{product.title}</h1>

            <div className="flex items-baseline gap-3">
              <span className="text-2xl font-bold text-[#0B4F5B] tabular-nums">
                {formatCurrency(product.price, storeConfig.currencySymbol)}
              </span>
              <span
                className={`text-xs font-semibold ${
                  inStock ? 'text-emerald-700' : 'text-red-600'
                }`}
              >
                {inStock
                  ? product.trackStock
                    ? `${product.stock} units available`
                    : 'Available for order'
                  : 'Currently unavailable'}
              </span>
            </div>

            <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-line">
              {product.description || 'No additional description provided.'}
            </p>

            {/* Clear Delivery & Terms Info Before Order */}
            <div className="rounded-2xl bg-slate-50 p-4 space-y-2.5 text-xs text-slate-700 border border-slate-100">
              <div className="flex items-start gap-2.5">
                <Truck className="w-4 h-4 text-[#FF6A00] shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-900">Delivery &amp; Fulfillment: </span>
                  <span className="capitalize">
                    {product.fulfillmentMethod.replace('_', ' ')}
                  </span>
                  {product.deliveryEstimate ? ` · Estimated ${product.deliveryEstimate}` : ''}
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-[#0B4F5B] shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-900">Terms &amp; Lawful Use: </span>
                  <span>
                    {product.terms ||
                      'Provided strictly for authorized marketing and lawful communication use. No account passwords or identity verification bypasses.'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="flex items-center justify-between border border-slate-200 rounded-xl px-3 py-2 sm:w-32">
              <button
                type="button"
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                className="w-7 h-7 rounded-lg hover:bg-slate-100 font-bold text-slate-700"
              >
                -
              </button>
              <span className="text-sm font-bold tabular-nums">{qty}</span>
              <button
                type="button"
                onClick={() => setQty((q) => Math.min(maxQty, q + 1))}
                className="w-7 h-7 rounded-lg hover:bg-slate-100 font-bold text-slate-700"
              >
                +
              </button>
            </div>

            <button
              type="button"
              disabled={!inStock}
              onClick={() => addToCart(product, qty)}
              className="flex-1 py-3 px-4 rounded-xl border border-[#0B4F5B] text-[#0B4F5B] text-sm font-bold hover:bg-teal-50 disabled:opacity-50 inline-flex items-center justify-center gap-2"
            >
              <ShoppingBag className="w-4 h-4" />
              Add to Cart
            </button>

            <button
              type="button"
              disabled={!inStock}
              onClick={() => {
                addToCart(product, qty);
                setCurrentPage('checkout');
              }}
              className="flex-1 py-3 px-4 rounded-xl bg-[#FF6A00] text-white text-sm font-bold hover:bg-[#e55f00] disabled:opacity-50"
            >
              Proceed to Checkout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
