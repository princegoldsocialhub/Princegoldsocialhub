import React, { useEffect, useState } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import {
  CreditCard,
  FolderKanban,
  HelpCircle,
  History,
  LayoutDashboard,
  MessageSquare,
  Package,
  Settings,
  ShieldAlert,
  ShoppingBag,
  Star,
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { formatDateTime, toDateObj } from '../lib/storeDefaults';
import {
  AdminTabId,
  AuditLog,
  FeedbackItem,
  ImportLog,
  Promotion,
  ScanDiagnostic,
  ScanHistoryEntry,
} from '../types';
import { AdminDashboardTab } from './admin/AdminDashboardTab';
import { AdminCatalogTab } from './admin/AdminCatalogTab';
import { AdminCategoriesTab } from './admin/AdminCategoriesTab';
import { AdminOrdersTab } from './admin/AdminOrdersTab';
import { AdminPaymentsTab } from './admin/AdminPaymentsTab';
import { AdminSettingsTab } from './admin/AdminSettingsTab';
import { AdminAuditLogsTab } from './admin/AdminAuditLogsTab';
import { AdminHelpTab } from './admin/AdminHelpTab';

export const AdminPage: React.FC = () => {
  const { user, isAdmin, adminTab, setAdminTab, setCurrentPage } = useApp();

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [importLogs, setImportLogs] = useState<ImportLog[]>([]);
  const [scanHistory, setScanHistory] = useState<ScanHistoryEntry[]>([]);
  const [diagnostics, setDiagnostics] = useState<ScanDiagnostic[]>([]);
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [feedbackList, setFeedbackList] = useState<FeedbackItem[]>([]);
  const [filterPendingOrders, setFilterPendingOrders] = useState(false);

  useEffect(() => {
    if (!user || !isAdmin) return;

    const sortByCreatedDesc = <T extends { createdAt?: unknown }>(items: T[]) =>
      items.sort((a, b) => toDateObj(b.createdAt).getTime() - toDateObj(a.createdAt).getTime());

    const unsubAudit = onSnapshot(
      collection(db, 'audit_logs'),
      (snap) => {
        setAuditLogs(
          sortByCreatedDesc(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<AuditLog, 'id'>) }))
          )
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'audit_logs')
    );

    const unsubImports = onSnapshot(
      collection(db, 'import_logs'),
      (snap) => {
        setImportLogs(
          sortByCreatedDesc(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ImportLog, 'id'>) }))
          )
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'import_logs')
    );

    const unsubScans = onSnapshot(
      collection(db, 'scan_history'),
      (snap) => {
        setScanHistory(
          sortByCreatedDesc(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ScanHistoryEntry, 'id'>) }))
          )
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'scan_history')
    );

    const unsubDiag = onSnapshot(
      collection(db, 'scan_diagnostics'),
      (snap) => {
        setDiagnostics(
          sortByCreatedDesc(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ScanDiagnostic, 'id'>) }))
          )
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'scan_diagnostics')
    );

    const unsubPromos = onSnapshot(
      collection(db, 'promotions'),
      (snap) => {
        setPromotions(
          sortByCreatedDesc(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Promotion, 'id'>) }))
          )
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'promotions')
    );

    const unsubFeedback = onSnapshot(
      collection(db, 'feedback'),
      (snap) => {
        setFeedbackList(
          sortByCreatedDesc(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<FeedbackItem, 'id'>) }))
          )
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'feedback')
    );

    return () => {
      unsubAudit();
      unsubImports();
      unsubScans();
      unsubDiag();
      unsubPromos();
      unsubFeedback();
    };
  }, [user, isAdmin]);

  if (!user || !isAdmin) {
    return (
      <div className="max-w-lg mx-auto rounded-3xl bg-white p-8 text-center shadow-sm border border-gray-100 my-8">
        <div className="w-14 h-14 rounded-2xl bg-orange-50 text-[#FF6A00] flex items-center justify-center mx-auto mb-4">
          <ShieldAlert className="w-7 h-7" />
        </div>
        <h1 className="font-display font-bold text-xl text-gray-900">
          Owner Admin Access Required
        </h1>
        <p className="text-sm text-gray-600 mt-2 leading-relaxed">
          {user
            ? `Signed in as ${user.email || 'user'}. Only the verified Princegoldsocialhub owner account can access catalog, order fulfillment, and store configuration.`
            : 'Sign in with the verified Princegoldsocialhub owner account to access store administration.'}
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <button
            type="button"
            onClick={() => setCurrentPage('profile')}
            className="rounded-xl bg-[#FF6A00] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#e85f00]"
          >
            Go to Sign In
          </button>
          <button
            type="button"
            onClick={() => setCurrentPage('home')}
            className="rounded-xl border border-gray-200 px-5 py-2.5 text-sm font-semibold text-gray-700"
          >
            Back to Storefront
          </button>
        </div>
      </div>
    );
  }

  const tabs: {
    id: AdminTabId;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'catalog', label: 'Catalog', icon: ShoppingBag },
    { id: 'categories', label: 'Categories & Coupons', icon: FolderKanban },
    { id: 'orders', label: 'Orders', icon: Package },
    { id: 'payments', label: 'Payments', icon: CreditCard },
    { id: 'settings', label: 'Content & Settings', icon: Settings },
    { id: 'audit', label: 'Audit Logs', icon: History },
    { id: 'help', label: 'Setup & Scanner Help', icon: HelpCircle },
  ];

  const handleSelectTab = (tab: AdminTabId) => {
    if (tab !== 'orders') setFilterPendingOrders(false);
    setAdminTab(tab);
  };

  const handleFilterPendingFromDashboard = () => {
    setFilterPendingOrders(true);
    setAdminTab('orders');
  };

  return (
    <div className="space-y-6 pb-8">
      {/* Admin Header & Tab Bar */}
      <div className="rounded-3xl bg-white p-4 sm:p-5 shadow-sm border border-gray-100">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <p className="text-xs font-semibold text-[#0B4F5B] uppercase tracking-wider">
              Princegoldsocialhub Operations
            </p>
            <h1 className="font-display font-bold text-xl sm:text-2xl text-gray-900">
              Owner Admin Panel
            </h1>
          </div>
          <span className="text-xs font-medium text-gray-500">
            Verified Admin: <strong className="text-gray-800">{user.email}</strong>
          </span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const active = adminTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => handleSelectTab(tab.id)}
                className={`inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-semibold whitespace-nowrap transition-colors ${
                  active
                    ? 'bg-[#FF6A00] text-white shadow-xs'
                    : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content */}
      {adminTab === 'dashboard' && (
        <AdminDashboardTab
          scanHistory={scanHistory}
          onNavigateTab={handleSelectTab}
          onFilterPendingOrders={handleFilterPendingFromDashboard}
        />
      )}

      {adminTab === 'catalog' && (
        <AdminCatalogTab scanHistory={scanHistory} importLogs={importLogs} />
      )}

      {adminTab === 'categories' && <AdminCategoriesTab promotions={promotions} />}

      {adminTab === 'orders' && (
        <AdminOrdersTab initialFilterPending={filterPendingOrders} />
      )}

      {adminTab === 'payments' && <AdminPaymentsTab />}

      {adminTab === 'settings' && <AdminSettingsTab />}

      {adminTab === 'audit' && <AdminAuditLogsTab auditLogs={auditLogs} />}

      {adminTab === 'help' && (
        <div className="space-y-6">
          <AdminHelpTab diagnostics={diagnostics} />

          {/* Recent Customer Feedback Messages */}
          <div className="rounded-3xl bg-white p-6 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-4">
              <MessageSquare className="w-5 h-5 text-[#FF6A00]" />
              <h3 className="font-display font-bold text-base text-gray-900">
                Customer Feedback Inbox
              </h3>
            </div>
            {feedbackList.length === 0 ? (
              <p className="text-xs text-gray-500">
                No customer feedback submissions yet.
              </p>
            ) : (
              <div className="divide-y divide-gray-100">
                {feedbackList.slice(0, 10).map((fb) => (
                  <div key={fb.id} className="py-3 space-y-1">
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-gray-900">
                          {fb.userEmail || 'Customer'}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-gray-100 text-gray-700 font-medium">
                          {fb.category}
                        </span>
                        <span className="inline-flex items-center gap-0.5 text-amber-500 font-semibold">
                          <Star className="w-3.5 h-3.5 fill-amber-400" />
                          {fb.rating}/5
                        </span>
                      </div>
                      <span className="text-gray-400">{formatDateTime(fb.createdAt)}</span>
                    </div>
                    <p className="text-sm text-gray-700">{fb.message}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
