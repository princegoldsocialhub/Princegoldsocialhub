export type PageId =
  | 'home'
  | 'catalog'
  | 'product'
  | 'checkout'
  | 'orders'
  | 'transactions'
  | 'notifications'
  | 'profile'
  | 'admin';

export type AdminTabId =
  | 'dashboard'
  | 'catalog'
  | 'categories'
  | 'orders'
  | 'payments'
  | 'settings'
  | 'audit'
  | 'help';

export type CategoryGroup = 'social_media' | 'phone_services' | 'custom_packages';
export type FulfillmentMethod = 'digital_service' | 'phone_provisioning' | 'physical_product';
export type OrderStatus =
  | 'Awaiting Payment'
  | 'Paid'
  | 'Processing'
  | 'Shipped'
  | 'Completed'
  | 'Cancelled'
  | 'Refunded';
export type PaymentStatus = 'unpaid' | 'verified_paid' | 'test_pending' | 'refunded';

export interface StoreConfig {
  storeName: string;
  logoUrl: string;
  welcomeTitle: string;
  welcomeSubtitle: string;
  trustBannerText: string;
  announcementEnabled: boolean;
  announcementText: string;
  announcementVersion: string;
  currencyCode: string;
  currencySymbol: string;
  supportEmail: string;
  supportPhone: string;
  supportWhatsapp: string;
  lowStockThreshold: number;
  lowStockEmailEnabled: boolean;
  lowStockAlertEmail: string;
  lowStockEmailSubject: string;
  lowStockEmailBody: string;
  packingSlipLogoUrl: string;
  packingSlipHeaderAddress: string;
  packingSlipFooterText: string;
  updatedAt?: unknown;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  group: CategoryGroup;
  enabled: boolean;
  sortOrder: number;
  updatedAt?: unknown;
}

export interface Product {
  id: string;
  title: string;
  sku: string;
  description: string;
  categoryId: string;
  categoryGroup: CategoryGroup;
  price: number;
  stock: number;
  trackStock: boolean;
  published: boolean;
  available: boolean;
  fulfillmentMethod: FulfillmentMethod;
  deliveryEstimate: string;
  terms: string;
  imageUrl: string;
  specs?: Record<string, string>;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Promotion {
  id: string;
  code: string;
  discountPercent: number;
  active: boolean;
  description: string;
  createdAt?: unknown;
}

export interface OrderItem {
  productId: string;
  sku: string;
  title: string;
  price: number;
  quantity: number;
  fulfillmentMethod: FulfillmentMethod;
}

export interface OrderTimelineEntry {
  status: string;
  timestamp: string;
  note: string;
  actor: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: string;
  hasPhysicalItems: boolean;
  currencyCode: string;
  currencySymbol: string;
  subtotal: number;
  discountAmount: number;
  couponCode: string;
  shippingFee: number;
  taxAmount: number;
  totalAmount: number;
  paymentProvider: 'paystack' | 'flutterwave' | 'test_mode';
  paymentReference: string;
  paymentStatus: PaymentStatus;
  status: OrderStatus;
  trackingNumber: string;
  estimatedDeliveryDate: string;
  items: OrderItem[];
  timeline: OrderTimelineEntry[];
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface OrderTrackingPublic {
  orderId: string;
  orderNumber: string;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  trackingNumber: string;
  estimatedDeliveryDate: string;
  hasPhysicalItems: boolean;
  timeline: OrderTimelineEntry[];
  updatedAt?: unknown;
}

export interface PaymentRecord {
  id: string;
  orderId: string;
  orderNumber: string;
  userId: string;
  provider: string;
  reference: string;
  amount: number;
  currencyCode: string;
  status: 'pending' | 'verified' | 'failed' | 'refunded';
  verifiedServerSide: boolean;
  createdAt?: unknown;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  phone: string;
  fcmTokens: string[];
  notificationsEnabled: boolean;
  updatedAt?: unknown;
}

export interface AppNotification {
  id: string;
  userId: string;
  orderId: string;
  orderNumber: string;
  title: string;
  body: string;
  status: string;
  read: boolean;
  createdAt?: unknown;
}

export interface AuditFieldDiff {
  field: string;
  oldValue: string;
  newValue: string;
}

export interface AuditLog {
  id: string;
  actionType: string;
  entityType: string;
  entityId: string;
  entityLabel: string;
  actorEmail: string;
  actorUid: string;
  changes: AuditFieldDiff[];
  summary: string;
  createdAt?: unknown;
}

export interface ImportErrorRow {
  rowNumber: number;
  sku: string;
  reason: string;
}

export interface ImportChangeEntry {
  productId: string;
  sku: string;
  field: string;
  before: string;
  after: string;
}

export interface ImportLog {
  id: string;
  fileName: string;
  status: 'success' | 'partial_failure' | 'failed' | 'rolled_back';
  totalRows: number;
  updatedCount: number;
  errorCount: number;
  errors: ImportErrorRow[];
  changes: ImportChangeEntry[];
  snapshotId: string;
  actorEmail: string;
  createdAt?: unknown;
}

export interface ScanHistoryEntry {
  id: string;
  productId: string;
  sku: string;
  productTitle: string;
  durationMs: number;
  accuracyScore: number;
  sessionLabel: string;
  createdAt?: unknown;
}

export interface ScanDiagnostic {
  id: string;
  errorCode: string;
  message: string;
  deviceInfo: string;
  createdAt?: unknown;
}

export interface FeedbackItem {
  id: string;
  userId: string;
  userEmail: string;
  rating: number;
  category: string;
  message: string;
  createdAt?: unknown;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  sortOrder: number;
}

export interface PolicyItem {
  id: string;
  title: string;
  content: string;
  sortOrder: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface PaymentGatewayStatus {
  paystackConfigured: boolean;
  flutterwaveConfigured: boolean;
  paystackMode: 'live' | 'test' | 'unconfigured';
  flutterwaveMode: 'live' | 'test' | 'unconfigured';
  anyLiveOrTestConfigured: boolean;
  emailTransportConfigured: boolean;
}
