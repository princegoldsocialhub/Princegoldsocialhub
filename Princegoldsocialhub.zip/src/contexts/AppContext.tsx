import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile,
  signOut as firebaseSignOut,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  deleteDoc,
  where,
  writeBatch,
  arrayUnion,
} from 'firebase/firestore';
import {
  ADMIN_EMAIL,
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
  subscribeForegroundFCM,
  testConnection,
} from '../lib/firebase';
import {
  DEFAULT_CATEGORIES,
  DEFAULT_FAQS,
  DEFAULT_POLICIES,
  DEFAULT_STORE_CONFIG,
} from '../lib/storeDefaults';
import {
  AdminTabId,
  AppNotification,
  CartItem,
  Category,
  CategoryGroup,
  FaqItem,
  Order,
  PageId,
  PaymentGatewayStatus,
  PaymentRecord,
  PolicyItem,
  Product,
  StoreConfig,
  UserProfile,
} from '../types';

interface AppContextValue {
  user: User | null;
  authReady: boolean;
  isAdmin: boolean;
  userProfile: UserProfile | null;
  storeConfig: StoreConfig;
  categories: Category[];
  products: Product[];
  productsLoading: boolean;
  customerOrders: Order[];
  allOrders: Order[];
  customerPayments: PaymentRecord[];
  allPayments: PaymentRecord[];
  notifications: AppNotification[];
  unreadCount: number;
  wishlistIds: string[];
  faqs: FaqItem[];
  policies: PolicyItem[];
  cart: CartItem[];
  compareIds: string[];
  searchHistory: string[];
  paymentGatewayStatus: PaymentGatewayStatus;

  // Navigation
  currentPage: PageId;
  setCurrentPage: (page: PageId) => void;
  selectedProductId: string | null;
  openProductDetail: (productId: string) => void;
  selectedOrderNumber: string | null;
  openOrderTracking: (orderNumber: string) => void;
  catalogGroupFilter: CategoryGroup | 'all';
  setCatalogGroupFilter: (group: CategoryGroup | 'all') => void;
  adminTab: AdminTabId;
  setAdminTab: (tab: AdminTabId) => void;

  // Modals & Toasts
  feedbackModalOpen: boolean;
  setFeedbackModalOpen: (open: boolean) => void;
  compareModalOpen: boolean;
  setCompareModalOpen: (open: boolean) => void;
  pushModalOpen: boolean;
  setPushModalOpen: (open: boolean) => void;
  toast: { type: 'success' | 'error' | 'info'; message: string } | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;

  // Actions
  signInWithGoogle: () => Promise<void>;
  signInEmail: (email: string, password: string) => Promise<void>;
  signUpEmail: (name: string, email: string, password: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
  addToCart: (product: Product, quantity?: number) => void;
  updateCartQty: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => Promise<void>;
  toggleCompare: (productId: string) => void;
  clearCompare: () => void;
  recordSearchQuery: (q: string) => void;
  markNotificationRead: (notificationId: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  saveFcmToken: (token: string | null, enabled: boolean) => Promise<void>;
  refreshPaymentStatus: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

const CART_STORAGE_KEY = 'pgh_cart_v1';
const SEARCH_HISTORY_KEY = 'pgh_search_history_v1';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [isAdminDoc, setIsAdminDoc] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  const [storeConfig, setStoreConfig] = useState<StoreConfig>(DEFAULT_STORE_CONFIG);
  const [categories, setCategories] = useState<Category[]>(
    DEFAULT_CATEGORIES.map((c) => ({ ...c }))
  );
  const [products, setProducts] = useState<Product[]>([]);
  const [productsLoading, setProductsLoading] = useState(true);
  const [customerOrders, setCustomerOrders] = useState<Order[]>([]);
  const [allOrders, setAllOrders] = useState<Order[]>([]);
  const [customerPayments, setCustomerPayments] = useState<PaymentRecord[]>([]);
  const [allPayments, setAllPayments] = useState<PaymentRecord[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [wishlistIds, setWishlistIds] = useState<string[]>([]);
  const [faqs, setFaqs] = useState<FaqItem[]>(DEFAULT_FAQS);
  const [policies, setPolicies] = useState<PolicyItem[]>(DEFAULT_POLICIES);

  const [paymentGatewayStatus, setPaymentGatewayStatus] = useState<PaymentGatewayStatus>({
    paystackConfigured: false,
    flutterwaveConfigured: false,
    paystackMode: 'unconfigured',
    flutterwaveMode: 'unconfigured',
    anyLiveOrTestConfigured: false,
    emailTransportConfigured: false,
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? (JSON.parse(saved) as CartItem[]) : [];
    } catch {
      return [];
    }
  });

  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(SEARCH_HISTORY_KEY);
      return saved ? (JSON.parse(saved) as string[]) : [];
    } catch {
      return [];
    }
  });

  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedOrderNumber, setSelectedOrderNumber] = useState<string | null>(null);
  const [catalogGroupFilter, setCatalogGroupFilter] = useState<CategoryGroup | 'all'>('all');
  const [adminTab, setAdminTab] = useState<AdminTabId>('dashboard');

  const [feedbackModalOpen, setFeedbackModalOpen] = useState(false);
  const [compareModalOpen, setCompareModalOpen] = useState(false);
  const [pushModalOpen, setPushModalOpen] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast((prev) => (prev?.message === message ? null : prev));
    }, 4500);
  }, []);

  const refreshPaymentStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/payments/status');
      if (res.ok) {
        const data = (await res.json()) as PaymentGatewayStatus;
        setPaymentGatewayStatus(data);
      }
    } catch {
      // keep default unconfigured status
    }
  }, []);

  useEffect(() => {
    testConnection();
    refreshPaymentStatus();
  }, [refreshPaymentStatus]);

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    } catch {
      // ignore storage quota errors
    }
  }, [cart]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        try {
          const adminSnap = await getDoc(doc(db, 'admins', firebaseUser.uid));
          setIsAdminDoc(adminSnap.exists());
        } catch {
          setIsAdminDoc(false);
        }
        // Ensure user profile doc exists
        try {
          const profileRef = doc(db, 'users', firebaseUser.uid);
          const profileSnap = await getDoc(profileRef);
          if (!profileSnap.exists()) {
            await setDoc(profileRef, {
              uid: firebaseUser.uid,
              displayName: (firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Customer').slice(0, 120),
              email: (firebaseUser.email || 'user@princegoldsocialhub.com').slice(0, 160),
              phone: '',
              fcmTokens: [],
              notificationsEnabled: false,
              updatedAt: serverTimestamp(),
            });
          }
        } catch (err) {
          console.warn('User profile sync notice:', err);
        }
      } else {
        setIsAdminDoc(false);
        setUserProfile(null);
      }
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  const isAdmin = useMemo(() => {
    if (!user) return false;
    return isAdminDoc || (user.email === ADMIN_EMAIL && user.emailVerified === true);
  }, [user, isAdminDoc]);

  // Public listeners: Store Config, Categories, FAQs, Policies
  useEffect(() => {
    const unsubConfig = onSnapshot(
      doc(db, 'store_config', 'main'),
      (snap) => {
        if (snap.exists()) {
          setStoreConfig({ ...DEFAULT_STORE_CONFIG, ...(snap.data() as Partial<StoreConfig>) });
        }
      },
      (err) => {
        console.warn('store_config read notice:', err);
      }
    );

    const unsubCategories = onSnapshot(
      collection(db, 'categories'),
      (snap) => {
        if (!snap.empty) {
          const list = snap.docs
            .map((d) => ({ id: d.id, ...(d.data() as Omit<Category, 'id'>) }))
            .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
          setCategories(list);
        } else {
          setCategories(DEFAULT_CATEGORIES.map((c) => ({ ...c })));
        }
      },
      (err) => {
        console.warn('categories read notice:', err);
      }
    );

    const unsubFaqs = onSnapshot(
      collection(db, 'faqs'),
      (snap) => {
        if (!snap.empty) {
          setFaqs(
            snap.docs
              .map((d) => ({ id: d.id, ...(d.data() as Omit<FaqItem, 'id'>) }))
              .sort((a, b) => a.sortOrder - b.sortOrder)
          );
        } else {
          setFaqs(DEFAULT_FAQS);
        }
      },
      () => {}
    );

    const unsubPolicies = onSnapshot(
      collection(db, 'policies'),
      (snap) => {
        if (!snap.empty) {
          setPolicies(
            snap.docs
              .map((d) => ({ id: d.id, ...(d.data() as Omit<PolicyItem, 'id'>) }))
              .sort((a, b) => a.sortOrder - b.sortOrder)
          );
        } else {
          setPolicies(DEFAULT_POLICIES);
        }
      },
      () => {}
    );

    return () => {
      unsubConfig();
      unsubCategories();
      unsubFaqs();
      unsubPolicies();
    };
  }, []);

  // Products listener (all for admin, published==true for customers/guests)
  useEffect(() => {
    if (!authReady) return;
    setProductsLoading(true);
    const prodRef = collection(db, 'products');
    const q = isAdmin ? prodRef : query(prodRef, where('published', '==', true));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<Product, 'id'>),
        }));
        setProducts(list);
        setProductsLoading(false);
      },
      (err) => {
        setProductsLoading(false);
        handleFirestoreError(err, OperationType.LIST, 'products');
      }
    );
    return () => unsub();
  }, [authReady, isAdmin]);

  // Authenticated user listeners (Profile, Wishlist, Orders, Payments, Notifications)
  useEffect(() => {
    if (!authReady || !user) {
      setCustomerOrders([]);
      setAllOrders([]);
      setCustomerPayments([]);
      setAllPayments([]);
      setNotifications([]);
      setWishlistIds([]);
      return;
    }

    const unsubProfile = onSnapshot(
      doc(db, 'users', user.uid),
      (snap) => {
        if (snap.exists()) {
          setUserProfile(snap.data() as UserProfile);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `users/${user.uid}`)
    );

    const unsubWishlist = onSnapshot(
      collection(db, 'users', user.uid, 'wishlist'),
      (snap) => {
        setWishlistIds(snap.docs.map((d) => d.id));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, `users/${user.uid}/wishlist`)
    );

    const ordersQuery = isAdmin
      ? collection(db, 'orders')
      : query(collection(db, 'orders'), where('userId', '==', user.uid));

    const unsubOrders = onSnapshot(
      ordersQuery,
      (snap) => {
        const list = snap.docs
          .map((d) => ({ id: d.id, ...(d.data() as Omit<Order, 'id'>) }))
          .sort((a, b) => {
            const ta = (a.createdAt as { seconds?: number })?.seconds ?? 0;
            const tb = (b.createdAt as { seconds?: number })?.seconds ?? 0;
            return tb - ta;
          });
        if (isAdmin) {
          setAllOrders(list);
          setCustomerOrders(list.filter((o) => o.userId === user.uid));
        } else {
          setCustomerOrders(list);
          setAllOrders([]);
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'orders')
    );

    const paymentsQuery = isAdmin
      ? collection(db, 'payments')
      : query(collection(db, 'payments'), where('userId', '==', user.uid));

    const unsubPayments = onSnapshot(
      paymentsQuery,
      (snap) => {
        const list = snap.docs
          .map((d) => ({ id: d.id, ...(d.data() as Omit<PaymentRecord, 'id'>) }))
          .sort((a, b) => {
            const ta = (a.createdAt as { seconds?: number })?.seconds ?? 0;
            const tb = (b.createdAt as { seconds?: number })?.seconds ?? 0;
            return tb - ta;
          });
        if (isAdmin) {
          setAllPayments(list);
          setCustomerPayments(list.filter((p) => p.userId === user.uid));
        } else {
          setCustomerPayments(list);
          setAllPayments([]);
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'payments')
    );

    const notifQuery = query(collection(db, 'notifications'), where('userId', '==', user.uid));
    const unsubNotifs = onSnapshot(
      notifQuery,
      (snap) => {
        const list = snap.docs
          .map((d) => ({ id: d.id, ...(d.data() as Omit<AppNotification, 'id'>) }))
          .sort((a, b) => {
            const ta = (a.createdAt as { seconds?: number })?.seconds ?? 0;
            const tb = (b.createdAt as { seconds?: number })?.seconds ?? 0;
            return tb - ta;
          });
        setNotifications(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'notifications')
    );

    return () => {
      unsubProfile();
      unsubWishlist();
      unsubOrders();
      unsubPayments();
      unsubNotifs();
    };
  }, [authReady, user, isAdmin]);

  // Foreground FCM notification toast
  useEffect(() => {
    let cleanup: () => void = () => {};
    subscribeForegroundFCM((payload) => {
      const title = payload.notification?.title || 'Order Update';
      const body = payload.notification?.body || '';
      showToast(`${title}${body ? `: ${body}` : ''}`, 'info');
    }).then((fn) => {
      cleanup = fn;
    });
    return () => cleanup();
  }, [showToast]);

  // First-visit dwell timer (>= 10s) for Push Notification Permission Modal
  useEffect(() => {
    if (!authReady || !user) return;
    const promptedKey = `pgh_push_prompted_${user.uid}`;
    if (localStorage.getItem(promptedKey)) return;
    if (userProfile?.notificationsEnabled) return;
    const timer = setTimeout(() => {
      localStorage.setItem(promptedKey, '1');
      setPushModalOpen(true);
    }, 10500);
    return () => clearTimeout(timer);
  }, [authReady, user, userProfile]);

  const unreadCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications]
  );

  const openProductDetail = useCallback((productId: string) => {
    setSelectedProductId(productId);
    setCurrentPage('product');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const openOrderTracking = useCallback((orderNumber: string) => {
    setSelectedOrderNumber(orderNumber);
    setCurrentPage('orders');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const signInWithGoogle = async () => {
    await signInWithPopup(auth, googleProvider);
    showToast('Signed in successfully.', 'success');
  };

  const signInEmail = async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, email.trim(), password);
    showToast('Signed in successfully.', 'success');
  };

  const signUpEmail = async (name: string, email: string, password: string) => {
    const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
    if (name.trim()) {
      await updateProfile(cred.user, { displayName: name.trim() });
    }
    showToast('Account created successfully.', 'success');
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email.trim());
    showToast('Password reset email sent. Check your inbox.', 'success');
  };

  const signOut = async () => {
    await firebaseSignOut(auth);
    if (currentPage === 'admin') setCurrentPage('home');
    showToast('Signed out.', 'info');
  };

  const addToCart = useCallback(
    (product: Product, quantity = 1) => {
      if (!product.available || (product.trackStock && product.stock <= 0)) {
        showToast('This item is currently out of stock.', 'error');
        return;
      }
      setCart((prev) => {
        const existing = prev.find((i) => i.product.id === product.id);
        if (existing) {
          const nextQty = product.trackStock
            ? Math.min(product.stock, existing.quantity + quantity)
            : existing.quantity + quantity;
          return prev.map((i) =>
            i.product.id === product.id ? { ...i, product, quantity: nextQty } : i
          );
        }
        return [...prev, { product, quantity }];
      });
      showToast(`Added "${product.title}" to cart.`, 'success');
    },
    [showToast]
  );

  const updateCartQty = useCallback((productId: string, quantity: number) => {
    if (quantity <= 0) {
      setCart((prev) => prev.filter((i) => i.product.id !== productId));
      return;
    }
    setCart((prev) =>
      prev.map((i) => (i.product.id === productId ? { ...i, quantity } : i))
    );
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setCart((prev) => prev.filter((i) => i.product.id !== productId));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const toggleWishlist = async (productId: string) => {
    if (!user) {
      showToast('Sign in to save items to your Wishlist.', 'info');
      setCurrentPage('profile');
      return;
    }
    const ref = doc(db, 'users', user.uid, 'wishlist', productId);
    try {
      if (wishlistIds.includes(productId)) {
        await deleteDoc(ref);
        showToast('Removed from Wishlist.', 'info');
      } else {
        await setDoc(ref, { productId, addedAt: serverTimestamp() });
        showToast('Saved to Wishlist.', 'success');
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}/wishlist/${productId}`);
    }
  };

  const toggleCompare = useCallback(
    (productId: string) => {
      setCompareIds((prev) => {
        if (prev.includes(productId)) {
          return prev.filter((id) => id !== productId);
        }
        if (prev.length >= 3) {
          showToast('You can compare up to 3 products at once.', 'info');
          return prev;
        }
        return [...prev, productId];
      });
    },
    [showToast]
  );

  const clearCompare = useCallback(() => setCompareIds([]), []);

  const recordSearchQuery = useCallback((q: string) => {
    const clean = q.trim();
    if (!clean) return;
    setSearchHistory((prev) => {
      const next = [clean, ...prev.filter((item) => item.toLowerCase() !== clean.toLowerCase())].slice(0, 5);
      try {
        localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  }, []);

  const markNotificationRead = async (notificationId: string) => {
    if (!user) return;
    try {
      await setDoc(
        doc(db, 'notifications', notificationId),
        { read: true },
        { merge: true }
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `notifications/${notificationId}`);
    }
  };

  const markAllNotificationsRead = async () => {
    if (!user) return;
    const unread = notifications.filter((n) => !n.read);
    if (unread.length === 0) return;
    try {
      const batch = writeBatch(db);
      for (const n of unread) {
        batch.update(doc(db, 'notifications', n.id), { read: true });
      }
      await batch.commit();
      showToast('All notifications marked as read.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'notifications');
    }
  };

  const saveFcmToken = async (token: string | null, enabled: boolean) => {
    if (!user) return;
    try {
      const ref = doc(db, 'users', user.uid);
      const payload: Record<string, unknown> = {
        uid: user.uid,
        email: (user.email || 'user@princegoldsocialhub.com').slice(0, 160),
        notificationsEnabled: enabled,
        updatedAt: serverTimestamp(),
      };
      if (token) {
        payload.fcmTokens = arrayUnion(token);
      }
      await setDoc(ref, payload, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  return (
    <AppContext.Provider
      value={{
        user,
        authReady,
        isAdmin,
        userProfile,
        storeConfig,
        categories,
        products,
        productsLoading,
        customerOrders,
        allOrders,
        customerPayments,
        allPayments,
        notifications,
        unreadCount,
        wishlistIds,
        faqs,
        policies,
        cart,
        compareIds,
        searchHistory,
        paymentGatewayStatus,
        currentPage,
        setCurrentPage,
        selectedProductId,
        openProductDetail,
        selectedOrderNumber,
        openOrderTracking,
        catalogGroupFilter,
        setCatalogGroupFilter,
        adminTab,
        setAdminTab,
        feedbackModalOpen,
        setFeedbackModalOpen,
        compareModalOpen,
        setCompareModalOpen,
        pushModalOpen,
        setPushModalOpen,
        toast,
        showToast,
        signInWithGoogle,
        signInEmail,
        signUpEmail,
        resetPassword,
        signOut,
        addToCart,
        updateCartQty,
        removeFromCart,
        clearCart,
        toggleWishlist,
        toggleCompare,
        clearCompare,
        recordSearchQuery,
        markNotificationRead,
        markAllNotificationsRead,
        saveFcmToken,
        refreshPaymentStatus,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
