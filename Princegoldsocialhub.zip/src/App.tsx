import React from 'react';
import { AppProvider, useApp } from './contexts/AppContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Layout } from './components/Layout';
import { FeedbackModal } from './components/FeedbackModal';
import { ProductComparisonModal } from './components/ProductComparisonModal';
import { PushPermissionModal } from './components/PushPermissionModal';
import { HomePage } from './pages/HomePage';
import { CatalogPage } from './pages/CatalogPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrdersPage } from './pages/OrdersPage';
import { TransactionsPage } from './pages/TransactionsPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { ProfileHelpPage } from './pages/ProfileHelpPage';
import { AdminPage } from './pages/AdminPage';

const PageRouter: React.FC = () => {
  const { currentPage } = useApp();

  switch (currentPage) {
    case 'home':
      return <HomePage />;
    case 'catalog':
      return <CatalogPage />;
    case 'product':
      return <ProductDetailPage />;
    case 'checkout':
      return <CheckoutPage />;
    case 'orders':
      return <OrdersPage />;
    case 'transactions':
      return <TransactionsPage />;
    case 'notifications':
      return <NotificationsPage />;
    case 'profile':
      return <ProfileHelpPage />;
    case 'admin':
      return <AdminPage />;
    default:
      return <HomePage />;
  }
};

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <Layout>
          <PageRouter />
        </Layout>
        <FeedbackModal />
        <ProductComparisonModal />
        <PushPermissionModal />
      </AppProvider>
    </ErrorBoundary>
  );
}
