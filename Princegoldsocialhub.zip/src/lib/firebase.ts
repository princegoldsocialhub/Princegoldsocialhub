import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import { getMessaging, getToken, isSupported, onMessage, MessagePayload } from 'firebase/messaging';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export const ADMIN_EMAIL = 'tomisin582@gmail.com';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid ?? null,
      email: auth.currentUser?.email ?? null,
      emailVerified: auth.currentUser?.emailVerified ?? null,
      isAnonymous: auth.currentUser?.isAnonymous ?? null,
      tenantId: auth.currentUser?.tenantId ?? null,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Firestore is offline. Please check your Firebase configuration.');
      return false;
    }
    return true;
  }
}

export async function initializeFCMAndGetToken(): Promise<{
  token: string | null;
  status: 'granted' | 'vapid_missing' | 'unsupported' | 'denied';
  message: string;
}> {
  try {
    const supported = await isSupported();
    if (!supported || typeof Notification === 'undefined') {
      return {
        token: null,
        status: 'unsupported',
        message: 'Push notifications are not supported in this browser context. In-app real-time alerts remain active.',
      };
    }

    const permission = await Notification.requestPermission();
    if (permission !== 'granted') {
      return {
        token: null,
        status: 'denied',
        message: 'Notification permission was dismissed or blocked in browser settings.',
      };
    }

    const vapidKey = import.meta.env.VITE_FIREBASE_VAPID_KEY as string | undefined;
    if (!vapidKey || !vapidKey.trim()) {
      return {
        token: null,
        status: 'vapid_missing',
        message:
          'Browser permission granted! Set VITE_FIREBASE_VAPID_KEY in environment variables from Firebase Console -> Cloud Messaging -> Web Push certificates to register FCM device tokens. Real-time Firestore alerts are active.',
      };
    }

    let swReg: ServiceWorkerRegistration | undefined;
    if ('serviceWorker' in navigator) {
      swReg = await navigator.serviceWorker.register('/firebase-messaging-sw.js');
    }

    const messaging = getMessaging(app);
    const token = await getToken(messaging, {
      vapidKey: vapidKey.trim(),
      serviceWorkerRegistration: swReg,
    });

    if (!token) {
      return {
        token: null,
        status: 'vapid_missing',
        message: 'Unable to retrieve FCM registration token. Verify your VAPID key configuration.',
      };
    }

    return {
      token,
      status: 'granted',
      message: 'Push notifications enabled and device token linked to your account.',
    };
  } catch (err) {
    return {
      token: null,
      status: 'unsupported',
      message: err instanceof Error ? err.message : 'Unable to initialize Firebase Cloud Messaging.',
    };
  }
}

export async function subscribeForegroundFCM(
  callback: (payload: MessagePayload) => void
): Promise<() => void> {
  try {
    const supported = await isSupported();
    if (!supported) return () => {};
    const messaging = getMessaging(app);
    return onMessage(messaging, callback);
  } catch {
    return () => {};
  }
}
