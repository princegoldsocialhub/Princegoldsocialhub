import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { AuditFieldDiff } from '../types';

export function computeFieldDiffs(
  before: Record<string, unknown>,
  after: Record<string, unknown>,
  fields: string[]
): AuditFieldDiff[] {
  const diffs: AuditFieldDiff[] = [];
  for (const field of fields) {
    const oldVal = before[field];
    const newVal = after[field];
    const oldStr = oldVal === undefined || oldVal === null ? '—' : String(oldVal);
    const newStr = newVal === undefined || newVal === null ? '—' : String(newVal);
    if (oldStr !== newStr) {
      diffs.push({
        field,
        oldValue: oldStr.slice(0, 120),
        newValue: newStr.slice(0, 120),
      });
    }
  }
  return diffs.slice(0, 30);
}

export async function logAuditEvent(params: {
  actionType: string;
  entityType: string;
  entityId: string;
  entityLabel: string;
  changes?: AuditFieldDiff[];
  summary: string;
}): Promise<void> {
  const user = auth.currentUser;
  if (!user) return;
  try {
    await addDoc(collection(db, 'audit_logs'), {
      actionType: params.actionType.slice(0, 40),
      entityType: params.entityType.slice(0, 40),
      entityId: params.entityId.slice(0, 128),
      entityLabel: params.entityLabel.slice(0, 160),
      actorEmail: (user.email || 'admin').slice(0, 160),
      actorUid: user.uid.slice(0, 128),
      changes: (params.changes || []).slice(0, 30),
      summary: params.summary.slice(0, 400),
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, 'audit_logs');
  }
}

export async function createOrderStatusNotification(params: {
  userId: string;
  orderId: string;
  orderNumber: string;
  newStatus: string;
  note?: string;
}): Promise<void> {
  if (!params.userId) return;
  try {
    await addDoc(collection(db, 'notifications'), {
      userId: params.userId.slice(0, 128),
      orderId: params.orderId.slice(0, 128),
      orderNumber: params.orderNumber.slice(0, 40),
      title: `Order ${params.orderNumber} is now ${params.newStatus}`.slice(0, 140),
      body: (params.note
        ? `Status updated to ${params.newStatus}: ${params.note}`
        : `Your Princegoldsocialhub order ${params.orderNumber} status changed to ${params.newStatus}.`
      ).slice(0, 400),
      status: params.newStatus.slice(0, 40),
      read: false,
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, 'notifications');
  }
}
