import { Category, FaqItem, OrderStatus, PolicyItem, StoreConfig } from '../types';

export const SKU_REGEX = /^[A-Za-z0-9_-]{1,64}$/;

export const DEFAULT_STORE_CONFIG: StoreConfig = {
  storeName: 'Princegoldsocialhub',
  logoUrl: '',
  welcomeTitle: 'Welcome to Princegoldsocialhub',
  welcomeSubtitle:
    'Your trusted digital commerce hub for legitimate social media growth services and lawfully provisioned business phone numbers.',
  trustBannerText: 'Verified Digital Delivery · Transparent Order Tracking · Server-Verified Checkout',
  announcementEnabled: true,
  announcementText:
    'Welcome to Princegoldsocialhub! Track every order in real time and enable alerts for instant fulfillment updates.',
  announcementVersion: 'v1',
  currencyCode: 'NGN',
  currencySymbol: '₦',
  supportEmail: 'support@princegoldsocialhub.com',
  supportPhone: '+234 800 000 0000',
  supportWhatsapp: 'https://wa.me/2348000000000',
  lowStockThreshold: 5,
  lowStockEmailEnabled: true,
  lowStockAlertEmail: 'tomisin582@gmail.com',
  lowStockEmailSubject: '[Princegoldsocialhub] Low Stock Alert: {{sku}}',
  lowStockEmailBody:
    'Hello Admin,\n\nInventory for {{title}} (SKU: {{sku}}) has dropped to {{stock}} units, which is below your configured threshold of {{threshold}} units.\n\nPlease review stock in the Admin Catalog.',
  packingSlipLogoUrl: '',
  packingSlipHeaderAddress: 'Princegoldsocialhub Digital & Telecom Operations\nLagos, Nigeria\nsupport@princegoldsocialhub.com',
  packingSlipFooterText:
    'Thank you for choosing Princegoldsocialhub. Retain your Order ID for real-time tracking and support.',
};

export const DEFAULT_CATEGORIES: Omit<Category, 'updatedAt'>[] = [
  {
    id: 'social-media-services',
    name: 'Social Media Services',
    slug: 'social-media-services',
    description:
      'Authorized content creation, brand design, campaign management, and social growth consulting.',
    group: 'social_media',
    enabled: true,
    sortOrder: 1,
  },
  {
    id: 'phone-number-services',
    name: 'Phone Number Services',
    slug: 'phone-number-services',
    description:
      'Lawfully provisioned business lines, virtual communication numbers, call forwarding, and eSIM plans.',
    group: 'phone_services',
    enabled: true,
    sortOrder: 2,
  },
  {
    id: 'custom-packages',
    name: 'Custom Packages',
    slug: 'custom-packages',
    description: 'Tailored agency bundles combining brand marketing and dedicated communication lines.',
    group: 'custom_packages',
    enabled: true,
    sortOrder: 3,
  },
];

export const DEFAULT_FAQS: FaqItem[] = [
  {
    id: 'faq-1',
    question: 'How do I track my Princegoldsocialhub order?',
    answer:
      'Every purchase receives a unique Order ID (such as PGH-20261120-1042). Open Orders & Tracking and enter your Order ID or view your order history when signed in to see real-time progress and timestamps.',
    sortOrder: 1,
  },
  {
    id: 'faq-2',
    question: 'Are social media services compliant with platform rules?',
    answer:
      'Yes. Princegoldsocialhub provides legitimate content production, creative design, ad campaign setup, and organic growth strategy. We never sell stolen credentials, unauthorized account transfers, or password-sharing access.',
    sortOrder: 2,
  },
  {
    id: 'faq-3',
    question: 'How are phone number products provisioned?',
    answer:
      'All phone numbers and eSIM products are lawfully provisioned for standard business and personal communication. We do not offer OTP interception, verification bypass, or temporary rental for bypassing identity checks.',
    sortOrder: 3,
  },
];

export const DEFAULT_POLICIES: PolicyItem[] = [
  {
    id: 'policy-lawful-use',
    title: 'Acceptable & Lawful Use Policy',
    content:
      'Princegoldsocialhub strictly provides authorized social media marketing, creative design, and lawfully provisioned communication numbers. Services must never be used for unauthorized account access, identity verification bypass, spam, or unlawful activity.',
    sortOrder: 1,
  },
  {
    id: 'policy-refunds',
    title: 'Payments & Refund Policy',
    content:
      'All live payments are processed through official hosted payment providers (Paystack or Flutterwave) and verified server-side. Card details are never stored on our servers. Verified refunds are reflected in order status and transaction logs.',
    sortOrder: 2,
  },
  {
    id: 'policy-privacy',
    title: 'Privacy & Data Protection',
    content:
      'Customer contact information is used strictly for order fulfillment, tracking notifications, and customer support. Order tracking lookup uses non-PII status projections so personal details remain private.',
    sortOrder: 3,
  },
];

export function formatCurrency(amount: number, symbol = '₦'): string {
  const safe = Number.isFinite(amount) ? amount : 0;
  return `${symbol}${safe.toLocaleString('en-NG', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function toDateObj(ts: unknown): Date {
  if (!ts) return new Date();
  if (ts instanceof Date) return ts;
  if (typeof ts === 'string' || typeof ts === 'number') return new Date(ts);
  if (typeof ts === 'object' && ts !== null && 'toDate' in ts && typeof (ts as { toDate: () => Date }).toDate === 'function') {
    return (ts as { toDate: () => Date }).toDate();
  }
  if (typeof ts === 'object' && ts !== null && 'seconds' in ts) {
    return new Date(((ts as { seconds: number }).seconds || 0) * 1000);
  }
  return new Date();
}

export function formatDateTime(ts: unknown): string {
  const d = toDateObj(ts);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

export function calculateEstimatedDeliveryDate(
  createdAt: unknown,
  status: OrderStatus,
  hasPhysicalItems: boolean
): string {
  if (status === 'Completed') return 'Delivered';
  if (status === 'Cancelled' || status === 'Refunded') return 'Not Applicable';
  const base = toDateObj(createdAt);
  const daysToAdd = hasPhysicalItems
    ? status === 'Shipped'
      ? 2
      : 4
    : status === 'Processing'
    ? 1
    : 2;
  const est = new Date(base.getTime() + daysToAdd * 24 * 60 * 60 * 1000);
  return est.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function downloadCsvFile(filename: string, headers: string[], rows: (string | number | boolean)[][]): void {
  const escapeCell = (val: string | number | boolean) => {
    const str = String(val ?? '');
    if (/[",\n\r]/.test(str)) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  const csvContent = [
    headers.map(escapeCell).join(','),
    ...rows.map((r) => r.map(escapeCell).join(',')),
  ].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
