import express, { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { initializeApp, getApps, getApp } from 'firebase-admin/app';
import { getAuth, DecodedIdToken } from 'firebase-admin/auth';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const configPath = path.resolve(__dirname, 'firebase-applet-config.json');
const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8')) as {
  projectId: string;
  firestoreDatabaseId?: string;
};

const adminApp = getApps().length
  ? getApp()
  : initializeApp({ projectId: firebaseConfig.projectId });
const adminAuth = getAuth(adminApp);

const ADMIN_EMAIL = 'tomisin582@gmail.com';
const PORT = 3000;

interface AuthedRequest extends Request {
  user?: DecodedIdToken;
  idToken?: string;
}

interface WebhookEventRecord {
  id: string;
  provider: 'paystack' | 'flutterwave';
  event: string;
  reference: string;
  amount: number;
  currency: string;
  status: string;
  verifiedSignature: boolean;
  receivedAt: string;
}

const recentWebhookEvents: WebhookEventRecord[] = [];

async function verifyFirebaseToken(req: AuthedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Missing Authorization Bearer token.' });
    return;
  }
  const idToken = authHeader.slice(7).trim();
  try {
    const decoded = await adminAuth.verifyIdToken(idToken);
    req.user = decoded;
    req.idToken = idToken;
    next();
  } catch (err) {
    res.status(401).json({
      error: 'Invalid or expired authentication token.',
      details: err instanceof Error ? err.message : String(err),
    });
  }
}

function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction) {
  if (!req.user) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  if (req.user.email !== ADMIN_EMAIL || req.user.email_verified !== true) {
    res.status(403).json({ error: 'Forbidden: Approved verified admin account required.' });
    return;
  }
  next();
}

async function startServer() {
  const app = express();

  // Capture raw body for Paystack / Flutterwave webhook signature verification
  app.use(
    express.json({
      limit: '1mb',
      verify: (req: Request & { rawBody?: Buffer }, _res, buf) => {
        req.rawBody = buf;
      },
    })
  );

  // Health endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'Princegoldsocialhub' });
  });

  // Payment configuration status (NEVER exposes secret keys)
  app.get('/api/payments/status', (_req, res) => {
    const paystackConfigured = Boolean(process.env.PAYSTACK_SECRET_KEY && process.env.PAYSTACK_SECRET_KEY.trim());
    const flutterwaveConfigured = Boolean(process.env.FLUTTERWAVE_SECRET_KEY && process.env.FLUTTERWAVE_SECRET_KEY.trim());
    const paystackMode = process.env.PAYSTACK_SECRET_KEY?.startsWith('sk_live_') ? 'live' : paystackConfigured ? 'test' : 'unconfigured';
    const flutterwaveMode = process.env.FLUTTERWAVE_SECRET_KEY?.startsWith('FLWSECK-') ? 'live' : flutterwaveConfigured ? 'test' : 'unconfigured';

    res.json({
      paystackConfigured,
      flutterwaveConfigured,
      paystackMode,
      flutterwaveMode,
      anyLiveOrTestConfigured: paystackConfigured || flutterwaveConfigured,
      emailTransportConfigured: Boolean(process.env.RESEND_API_KEY || process.env.SMTP_HOST),
    });
  });

  // Initialize hosted payment checkout (Paystack or Flutterwave)
  app.post('/api/payments/initialize', verifyFirebaseToken, async (req: AuthedRequest, res) => {
    const { provider, email, amount, currency, orderNumber, orderId, callbackUrl } = req.body as {
      provider?: 'paystack' | 'flutterwave';
      email?: string;
      amount?: number;
      currency?: string;
      orderNumber?: string;
      orderId?: string;
      callbackUrl?: string;
    };

    if (!provider || !email || typeof amount !== 'number' || amount <= 0 || !orderNumber) {
      res.status(400).json({ error: 'Invalid payment initialization payload.' });
      return;
    }

    const reference = `${orderNumber}-${Date.now()}`;

    if (provider === 'paystack') {
      const secret = process.env.PAYSTACK_SECRET_KEY?.trim();
      if (!secret) {
        res.status(200).json({
          configured: false,
          provider: 'paystack',
          reference,
          message: 'PAYSTACK_SECRET_KEY is not configured in server environment secrets.',
        });
        return;
      }

      try {
        const resp = await fetch('https://api.paystack.co/transaction/initialize', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${secret}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email,
            amount: Math.round(amount * 100), // Paystack uses minor units (kobo/cents)
            currency: currency || 'NGN',
            reference,
            callback_url: callbackUrl || process.env.APP_URL || undefined,
            metadata: { orderId, orderNumber, userId: req.user?.uid },
          }),
        });
        const data = (await resp.json()) as {
          status?: boolean;
          message?: string;
          data?: { authorization_url?: string; reference?: string };
        };
        if (!resp.ok || !data.status || !data.data?.authorization_url) {
          res.status(502).json({ error: data.message || 'Paystack initialization failed.' });
          return;
        }
        res.json({
          configured: true,
          provider: 'paystack',
          authorizationUrl: data.data.authorization_url,
          reference: data.data.reference || reference,
        });
        return;
      } catch (err) {
        res.status(502).json({ error: err instanceof Error ? err.message : 'Paystack request error.' });
        return;
      }
    }

    if (provider === 'flutterwave') {
      const secret = process.env.FLUTTERWAVE_SECRET_KEY?.trim();
      if (!secret) {
        res.status(200).json({
          configured: false,
          provider: 'flutterwave',
          reference,
          message: 'FLUTTERWAVE_SECRET_KEY is not configured in server environment secrets.',
        });
        return;
      }

      try {
        const resp = await fetch('https://api.flutterwave.com/v3/payments', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${secret}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            tx_ref: reference,
            amount,
            currency: currency || 'NGN',
            redirect_url: callbackUrl || process.env.APP_URL || 'https://example.com',
            customer: { email },
            meta: { orderId, orderNumber, userId: req.user?.uid },
            customizations: {
              title: 'Princegoldsocialhub',
              description: `Order ${orderNumber}`,
            },
          }),
        });
        const data = (await resp.json()) as {
          status?: string;
          message?: string;
          data?: { link?: string };
        };
        if (!resp.ok || data.status !== 'success' || !data.data?.link) {
          res.status(502).json({ error: data.message || 'Flutterwave initialization failed.' });
          return;
        }
        res.json({
          configured: true,
          provider: 'flutterwave',
          authorizationUrl: data.data.link,
          reference,
        });
        return;
      } catch (err) {
        res.status(502).json({ error: err instanceof Error ? err.message : 'Flutterwave request error.' });
        return;
      }
    }

    res.status(400).json({ error: 'Unsupported payment provider.' });
  });

  // Server-side verification with Paystack or Flutterwave API
  app.post('/api/payments/verify', verifyFirebaseToken, async (req: AuthedRequest, res) => {
    const { provider, reference, expectedAmount } = req.body as {
      provider?: 'paystack' | 'flutterwave';
      reference?: string;
      expectedAmount?: number;
    };

    if (!provider || !reference) {
      res.status(400).json({ error: 'Provider and reference are required.' });
      return;
    }

    if (provider === 'paystack') {
      const secret = process.env.PAYSTACK_SECRET_KEY?.trim();
      if (!secret) {
        res.status(400).json({ verified: false, configured: false, error: 'PAYSTACK_SECRET_KEY is not configured.' });
        return;
      }
      try {
        const resp = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
          headers: { Authorization: `Bearer ${secret}` },
        });
        const payload = (await resp.json()) as {
          status?: boolean;
          message?: string;
          data?: { status?: string; amount?: number; currency?: string; reference?: string };
        };
        if (!resp.ok || !payload.status || payload.data?.status !== 'success') {
          res.status(400).json({
            verified: false,
            configured: true,
            status: payload.data?.status || 'failed',
            error: payload.message || 'Payment not verified by Paystack.',
          });
          return;
        }
        const paidAmount = (payload.data.amount || 0) / 100;
        if (typeof expectedAmount === 'number' && paidAmount < expectedAmount) {
          res.status(400).json({ verified: false, error: 'Paid amount is less than expected order total.' });
          return;
        }
        res.json({
          verified: true,
          configured: true,
          provider: 'paystack',
          reference: payload.data.reference,
          amount: paidAmount,
          currency: payload.data.currency,
        });
        return;
      } catch (err) {
        res.status(502).json({ verified: false, error: err instanceof Error ? err.message : 'Paystack verify failed.' });
        return;
      }
    }

    if (provider === 'flutterwave') {
      const secret = process.env.FLUTTERWAVE_SECRET_KEY?.trim();
      if (!secret) {
        res.status(400).json({ verified: false, configured: false, error: 'FLUTTERWAVE_SECRET_KEY is not configured.' });
        return;
      }
      try {
        const resp = await fetch(
          `https://api.flutterwave.com/v3/transactions/verify_by_reference?tx_ref=${encodeURIComponent(reference)}`,
          { headers: { Authorization: `Bearer ${secret}` } }
        );
        const payload = (await resp.json()) as {
          status?: string;
          message?: string;
          data?: { status?: string; amount?: number; currency?: string; tx_ref?: string };
        };
        if (!resp.ok || payload.status !== 'success' || payload.data?.status !== 'successful') {
          res.status(400).json({
            verified: false,
            configured: true,
            status: payload.data?.status || 'failed',
            error: payload.message || 'Payment not verified by Flutterwave.',
          });
          return;
        }
        const paidAmount = payload.data.amount || 0;
        if (typeof expectedAmount === 'number' && paidAmount < expectedAmount) {
          res.status(400).json({ verified: false, error: 'Paid amount is less than expected order total.' });
          return;
        }
        res.json({
          verified: true,
          configured: true,
          provider: 'flutterwave',
          reference: payload.data.tx_ref,
          amount: paidAmount,
          currency: payload.data.currency,
        });
        return;
      } catch (err) {
        res.status(502).json({ verified: false, error: err instanceof Error ? err.message : 'Flutterwave verify failed.' });
        return;
      }
    }

    res.status(400).json({ error: 'Unsupported payment provider.' });
  });

  // Signed webhook endpoint for Paystack & Flutterwave
  app.post('/api/payments/webhook', (req: Request & { rawBody?: Buffer }, res) => {
    const paystackSig = req.headers['x-paystack-signature'] as string | undefined;
    const flutterwaveHash = req.headers['verif-hash'] as string | undefined;

    if (paystackSig) {
      const secret = (process.env.PAYSTACK_WEBHOOK_SECRET || process.env.PAYSTACK_SECRET_KEY || '').trim();
      if (!secret || !req.rawBody) {
        res.status(400).send('Webhook secret not configured.');
        return;
      }
      const computed = crypto.createHmac('sha512', secret).update(req.rawBody).digest('hex');
      if (computed !== paystackSig) {
        res.status(401).send('Invalid Paystack signature.');
        return;
      }
      const body = req.body as {
        event?: string;
        data?: { reference?: string; amount?: number; currency?: string; status?: string };
      };
      recentWebhookEvents.unshift({
        id: `wh-${Date.now()}`,
        provider: 'paystack',
        event: body.event || 'unknown',
        reference: body.data?.reference || '',
        amount: (body.data?.amount || 0) / 100,
        currency: body.data?.currency || 'NGN',
        status: body.data?.status || 'unknown',
        verifiedSignature: true,
        receivedAt: new Date().toISOString(),
      });
      if (recentWebhookEvents.length > 50) recentWebhookEvents.pop();
      res.status(200).send('OK');
      return;
    }

    if (flutterwaveHash) {
      const secretHash = (process.env.FLUTTERWAVE_WEBHOOK_HASH || '').trim();
      if (!secretHash || flutterwaveHash !== secretHash) {
        res.status(401).send('Invalid Flutterwave webhook hash.');
        return;
      }
      const body = req.body as {
        event?: string;
        data?: { tx_ref?: string; amount?: number; currency?: string; status?: string };
      };
      recentWebhookEvents.unshift({
        id: `wh-${Date.now()}`,
        provider: 'flutterwave',
        event: body.event || 'charge.completed',
        reference: body.data?.tx_ref || '',
        amount: body.data?.amount || 0,
        currency: body.data?.currency || 'NGN',
        status: body.data?.status || 'unknown',
        verifiedSignature: true,
        receivedAt: new Date().toISOString(),
      });
      if (recentWebhookEvents.length > 50) recentWebhookEvents.pop();
      res.status(200).send('OK');
      return;
    }

    res.status(400).send('Missing provider signature header.');
  });

  // Admin: inspect verified webhook logs
  app.get('/api/admin/webhook-events', verifyFirebaseToken, requireAdmin, (_req, res) => {
    res.json({ events: recentWebhookEvents });
  });

  // Admin: server-side SKU uniqueness validation against Firestore sku_index
  app.post('/api/admin/validate-sku', verifyFirebaseToken, requireAdmin, async (req: AuthedRequest, res) => {
    const { sku, excludeProductId } = req.body as { sku?: string; excludeProductId?: string };
    if (!sku || typeof sku !== 'string') {
      res.status(400).json({ unique: false, error: 'SKU is required.' });
      return;
    }
    const cleanSku = sku.trim();
    if (!/^[A-Za-z0-9_-]{1,64}$/.test(cleanSku)) {
      res.status(400).json({
        unique: false,
        error: 'SKU must be 1-64 characters using only letters, numbers, hyphens, or underscores.',
      });
      return;
    }

    const skuUpper = cleanSku.toUpperCase();
    const dbId = firebaseConfig.firestoreDatabaseId || '(default)';
    const url = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${encodeURIComponent(dbId)}/documents/sku_index/${encodeURIComponent(skuUpper)}`;

    try {
      const resp = await fetch(url, {
        headers: { Authorization: `Bearer ${req.idToken}` },
      });
      if (resp.status === 404) {
        res.json({ unique: true, normalizedSku: skuUpper });
        return;
      }
      if (!resp.ok) {
        const text = await resp.text();
        res.status(502).json({ unique: false, error: `Firestore SKU lookup failed (${resp.status}): ${text}` });
        return;
      }
      const docData = (await resp.json()) as {
        fields?: { productId?: { stringValue?: string }; sku?: { stringValue?: string } };
      };
      const existingProductId = docData.fields?.productId?.stringValue;
      if (excludeProductId && existingProductId === excludeProductId) {
        res.json({ unique: true, normalizedSku: skuUpper });
        return;
      }
      res.status(409).json({
        unique: false,
        normalizedSku: skuUpper,
        conflictProductId: existingProductId,
        error: `Inventory SKU "${cleanSku}" is already assigned to another catalog product.`,
      });
    } catch (err) {
      res.status(500).json({ unique: false, error: err instanceof Error ? err.message : 'Server SKU validation error.' });
    }
  });

  // Admin: Send Test Low-Stock Email Alert
  app.post('/api/admin/send-test-email', verifyFirebaseToken, requireAdmin, async (req: AuthedRequest, res) => {
    const { toEmail, subject, body, threshold } = req.body as {
      toEmail?: string;
      subject?: string;
      body?: string;
      threshold?: number;
    };

    if (!toEmail || !subject || !body) {
      res.status(400).json({ error: 'Recipient email, subject, and body are required.' });
      return;
    }

    const resendKey = process.env.RESEND_API_KEY?.trim();
    if (resendKey) {
      try {
        const resp = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${resendKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            from: process.env.EMAIL_FROM || 'alerts@princegoldsocialhub.com',
            to: [toEmail],
            subject,
            text: body,
          }),
        });
        if (!resp.ok) {
          const errText = await resp.text();
          res.status(502).json({ sent: false, error: `Email provider error: ${errText}` });
          return;
        }
        res.json({
          sent: true,
          mode: 'live',
          message: `Test low-stock email sent to ${toEmail}.`,
          sentAt: new Date().toISOString(),
        });
        return;
      } catch (err) {
        res.status(502).json({ sent: false, error: err instanceof Error ? err.message : 'Email send error.' });
        return;
      }
    }

    // Simulated verification response when no external SMTP/Resend secret is configured
    res.json({
      sent: true,
      mode: 'simulated',
      message: `Simulated test email verified for ${toEmail} (Threshold: ${threshold ?? 5} units). Configure RESEND_API_KEY in server secrets for live SMTP delivery.`,
      preview: { toEmail, subject, body },
      sentAt: new Date().toISOString(),
    });
  });

  // Vite dev middleware or production static assets
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Princegoldsocialhub server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
